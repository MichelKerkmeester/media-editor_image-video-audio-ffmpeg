---
title: "benchmark/gates: rule parity across the seven declared pairs"
description: "Reads the shared parity declaration and holds a named Media Editor rule to the same phrase count on both sides of every pair that teaches it."
trigger_phrases:
  - "rule parity"
  - "declared pairs"
  - "phrase count mismatch"
---

# benchmark/gates: rule parity across the seven declared pairs

---

## 1. OVERVIEW

`benchmark/gates/` holds one check: whether a rule this system states holds the same verbatim phrase count on both sides of every declared skill-to-mirror pair that teaches it. The wrappers in `benchmark/parity/` exec into the shared `z — Claude Project Sync Loop`, which checks document inventory (the knowledge root exists, holds only markdown, carries the pairs the shared declaration names). Neither that gate nor anything else in this system reads what a document actually says, so a rule can be tightened in a skill source and left stale in its Project mirror with every existing check still green.

Current state:

- `rule_parity.py` reads this system's seven declared pairs from `z — Claude Project Sync Loop/systems.py`, the fleet's one shared declaration, rather than a locally built map
- It opens that file for reading only, with bytecode caching disabled first, and never writes to it
- Six rules are named today, each with the verbatim phrase (or phrases) that carry it and a floor for how many of the seven pairs teach it as measured against the live tree
- Measured when this check was written, all seven pairs hold byte-identical content on both sides, so the check starts from a green baseline it earns by comparison, not one it assumes

---

## 2. FILES

| File | Responsibility |
|---|---|
| `rule_parity.py` | CLI script. Reads the seven declared pairs, counts each named rule's phrases on both sides of every pair, enforces the floor, exits 1 on any finding |

---

## 3. THE SIX NAMED RULES

| Rule | Taught by (of 7 pairs) | Carried in |
|---|---|---|
| ffmpeg precondition gates every operation | 5 | mcp-imagician, mcp-video-audio, hls-video-conversion, interactive-intelligence, media-framework |
| no format or filter promised before a build check | 2 | mcp-imagician, mcp-video-audio |
| no horizontal dividers in a reply | 1 | interactive-intelligence |
| one comprehensive question, then wait | 1 | interactive-intelligence |
| the export destination convention | 2 | mcp-imagician, mcp-video-audio |
| core punctuation hard blockers (em dash, semicolon) | 2 | hvr-core, human-voice-rules |

The two Human Voice pairs never teach the five operational rules above, and the five operational documents never teach the punctuation rule. That is the expected shape, not a gap: a pair where neither side carries a phrase does not teach that rule.

---

## 4. RUN

From the system directory:

```bash
python3 benchmark/gates/rule_parity.py
```

Expected result: a `pairs: 7 of 7 declared pairs compared` line, one line per rule naming how many pairs teach it against its floor, then `PASSED 6 rules hold on both sides of every pair that teaches them`. Exit 0.

On a finding: the same lines, then `FAILED N rule parity finding(s)` and a dashed list naming the rule, the exact phrase, and the count on each side. Exit 1.

---

## 5. EXIT CODES

| Exit | Meaning |
|---|---|
| 0 | every rule holds an equal phrase count on both sides of every pair that teaches it, and every rule met its floor |
| 1 | at least one phrase count differed across a pair, or a rule fell below its declared floor |
| 2 | the shared declaration could not be read, `media-editor` is not declared in it, or it declares no pairs |

---

## 6. PROVEN RED

Confirmed by deleting the sentence `If the check fails, stop and give install guidance before any operation.` from only the Project mirror of the MCP Imagician pair (the skill source kept it). The run named the exact phrase, the 1x/0x count split, the source file and its mirror, and returned exit 1. Restoring the sentence returned the run to `PASSED` and exit 0. The edit was made and reverted on the real declared pair, backed up first to a path outside this system's tree, never on a copy.

---

## 7. RELATED

- [`../parity/README.md`](../parity/README.md), the document-inventory wrappers this check does not duplicate
- [`../../../z — Claude Project Sync Loop/systems.py`](../../../z%20—%20Claude%20Project%20Sync%20Loop/systems.py), the shared declaration this check reads and never writes
- [`../grader/README.md`](../grader/README.md), the checks that read a finished report rather than the declared pairs
