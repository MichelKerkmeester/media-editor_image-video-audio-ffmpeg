# Route Contract (executable)

Deterministic characterization of how the Barter Media Editor routes a
request to a mode, binds a tool and decides whether to ask one
comprehensive question, so routing behavior is testable without invoking
a model. The skill and project kernels are written against this contract;
claude.ai still interprets prose stochastically, so live adherence testing
remains mandatory.

## Files

- `route_contract.py` — the deterministic router (exact tokens, word-boundary
  keywords, one primary mode, tool binding, disambiguation, resources, schema).
- `fixtures.json` — the expected route objects (test oracle).
- `run_fixtures.sh` — gate runner; exits 0 only when all fixtures pass.

## Run

```bash
bash run_fixtures.sh
# or directly:
python3 route_contract.py fixtures.json
# or inspect a single request:
python3 route_contract.py "$audio from this video file"
```

## Route object

Every request resolves to one stable object:

```json
{
  "mode": "AUDIO",
  "tool": "video-audio",
  "fallback": "ffmpeg",
  "source": "command",
  "needs_disambiguation": false,
  "resources": [
    "references/media-framework.md",
    "references/hvr-core.md",
    "references/mcp-video-audio.md"
  ]
}
```

The schema rejects unknown or duplicate fields, so the manifest cannot
drift silently from the contract.

## Decision rules (durable rationale)

- **Exact tokens**: only a complete `$token` selects a mode. `$image`,
  `$img`, `$video`, `$vid`, `$audio`, `$aud`, `$hls`, `$repair`, `$r`,
  `$interactive` and `$int` are matched as whole tokens, never as
  substrings, so a longer word can never carry a bare alias into a mode.
- **One primary mode, command wins**: an explicit command beats every
  natural-language signal, so `$audio from this video file` binds AUDIO,
  not VIDEO. Without a command, the highest word-boundary keyword score
  wins and no second mode loads a second resource pack.
- **Word-boundary keywords**: `photo` matches "compress this photo" but
  never "photography"; `stream`-family routing needs `streaming`,
  `adaptive` or `hls`, so an incidental "video" does not steal an HLS
  request.
- **Disambiguation gate**: a request with no command and no keyword hit
  routes to INTERACTIVE with `needs_disambiguation=true`, so the router
  asks one comprehensive question instead of inventing the media type.
- **Tool binding**: IMAGE binds Imagician, VIDEO/AUDIO bind Video-Audio,
  HLS and Repair bind FFmpeg/auto. Image, video and audio declare a
  Terminal FFmpeg fallback; HLS and Repair declare none. Live tool
  verification is a runtime concern and is intentionally not simulated
  here; this contract fixes only the routing decision.
- **Runtime discovery + guarded loading**: every routing call resolves
  resource names against the live `references/*.md` and `assets/*.md`
  inventory (discover, existence-check, dedupe). A renamed or deleted
  reference degrades to a smaller resource set instead of a dead path or
  crash. Missing bases contribute nothing without failing.
```
