---
title: "Media Editor - Integrations - FFmpeg Image Operations - v0.211"
description: "FFmpeg and ffprobe commands, format support, operation recipes and quality guidance for image processing operations."
version: "0.211"
contextType: reference
importance_tier: high
trigger_phrases:
  - "ffmpeg image"
  - "image resize convert compress"
  - "webp avif jpeg png"
  - "image operation commands"
  - "ffprobe image metadata"
---

# Media Editor - Integrations - FFmpeg Image Operations - v0.211

Technical reference for image processing with locally installed FFmpeg and ffprobe.

---

## 1. Overview

### Purpose

Defines the FFmpeg and ffprobe commands for image processing. It is the technical reference for resize, convert, crop, compress, rotate, flip and metadata operations.

### When to use

- Loaded on demand for any image processing operation
- Looking up FFmpeg image commands, format support and quality settings
- Applying quality optimization, resize and crop strategy and transforms

### Precondition

When the Media Editor tools are connected, use them: they bring their own ffmpeg, and `media_health` reports what it can do. Otherwise use FFmpeg on the path, and when neither answers, give the exact command as advice and say that nothing ran. Check for FFmpeg once per session:

```bash
ffmpeg -version
```

`ffprobe` ships with FFmpeg and covers metadata reads. The local route needs no server, no login and no network. If neither the tools nor the check answers, give the command as advice with install guidance and run nothing.

---

## 2. Tool overview

FFmpeg decodes, filters and re-encodes images with the same command shape as video: an input, one option set, and an output.

- Read properties with `ffprobe`
- Convert, resize, crop, rotate, flip and compress with `ffmpeg`
- Batch work with a shell loop over the files, one ffmpeg invocation each
- Write results to `media files/export/[###] - [description]/` in the runtime. A Media Editor tool writes its own `NNN - description/` folder and returns the path, and that folder is the export

Encoder availability varies by build. Check the encoders before promising a format:

```bash
ffmpeg -encoders | grep -E "mjpeg|png|libsvtav1|libwebp"
```

The check matters most for WebP and AVIF output, which many builds carry but plain builds may not.

---

## 3. Core capabilities

- **Resize:** change dimensions with `scale`
- **Convert:** change format with the codec for the target
- **Crop:** extract a region with `crop`
- **Compress:** trade quality for size with the encoder quality option
- **Rotate:** quarter turns with `transpose`
- **Flip:** mirror with `hflip` and `vflip`
- **Metadata:** read dimensions, format and pixel format with `ffprobe`
- **Batch:** loop over a folder with one ffmpeg command per file

### Processing order

1. Check the route: the Media Editor tools when connected, otherwise FFmpeg on the path
2. Crop first to remove unwanted areas
3. Resize next
4. Rotate or flip
5. Convert format
6. Compress as the final step

---

## 4. Format support

- **JPEG:** input and output, no transparency, universal support
- **PNG:** input and output, transparency, lossless
- **WebP:** input always. Output only when the build includes a WebP encoder
- **AVIF:** input and output when the build includes an AV1 encoder
- **GIF, BMP and TIFF:** input and output on most builds
- **SVG:** neither input nor output on a plain build

An encoder check decides the promise. Do not promise WebP or AVIF output before `ffmpeg -encoders` shows the matching encoder.

---

## 5. Operation recipes

### Resize

```bash
ffmpeg -i INPUT.jpg -vf scale=1920:-1 OUTPUT.jpg
```

`scale=1920:-1` sets the width and derives the height while preserving the aspect ratio. Use `-2` instead of `-1` when the output encoder needs even dimensions.

### Convert

```bash
ffmpeg -i INPUT.png -q:v 3 OUTPUT.jpg
ffmpeg -i INPUT.png -compression_level 6 OUTPUT.png
ffmpeg -i INPUT.png -c:v libsvtav1 -crf 30 OUTPUT.avif
```

JPEG uses `-q:v` on a scale of 2 to 31 where lower is better. PNG uses `-compression_level` from 0 to 9. AVIF uses an AV1 encoder such as `libsvtav1` with `-crf`.

### Crop

```bash
ffmpeg -i INPUT.jpg -vf "crop=800:600:100:50" OUTPUT.jpg
```

The four values are width, height, x and y.

### Compress

```bash
ffmpeg -i INPUT.jpg -q:v 6 OUTPUT.jpg
```

Combine with `scale` when the use case allows a smaller frame:

```bash
ffmpeg -i INPUT.jpg -vf scale=1600:-1 -q:v 6 OUTPUT.jpg
```

### Rotate and flip

```bash
ffmpeg -i INPUT.jpg -vf "transpose=1" OUTPUT.jpg
ffmpeg -i INPUT.jpg -vf hflip OUTPUT.jpg
```

`transpose=1` rotates 90 degrees clockwise, `transpose=2` counterclockwise, and two passes give 180 degrees. `hflip` mirrors horizontally and `vflip` mirrors vertically.

### Metadata

```bash
ffprobe -v error -show_entries stream=width,height,codec_name,pix_fmt -of default=noprint_wrappers=1 INPUT.jpg
```

### Batch

```bash
mkdir -p "media files/export/001 - resized"
for file in *.jpg; do
  ffmpeg -i "$file" -vf scale=1600:-1 "media files/export/001 - resized/$file"
done
```

### EXIF orientation

FFmpeg reads the EXIF orientation flag and rotates the frame by default. Add `-noautorotate` to switch that off, or apply `transpose` explicitly when the source carries an orientation the target should not inherit.

---

## 6. Quality optimization

| Use case | Setting | Note |
| --- | --- | --- |
| Archive | JPEG `-q:v 2`, PNG `-compression_level 9` | Largest file, highest fidelity |
| Print and professional | JPEG `-q:v 2` to `-q:v 4` | High quality |
| Web display | WebP or AVIF when the encoder is present, JPEG `-q:v 5` otherwise | Balance of size and quality |
| Size priority | JPEG `-q:v 8` to `-q:v 12` | Visible loss on close inspection |

Format guidance:
- Photos: JPEG `-q:v 3` to `-q:v 5`, AVIF `-crf 28` to `-crf 32`
- Graphics and screenshots: PNG with `-compression_level 9`
- Web: WebP when the build supports it, AVIF for smaller files, JPEG as the universal fallback

---

## 7. Resize strategy

- Proportional resize: `scale=1920:-1` or `scale=-1:1080`
- Fixed width: `scale=1920:-1`
- Max dimensions: `scale='min(1920,iw)':-1`
- Fit inside a square with padding:

```bash
ffmpeg -i INPUT.jpg -vf "scale=1080:1080:force_original_aspect_ratio=decrease,pad=1080:1080:(ow-iw)/2:(oh-ih)/2" OUTPUT.jpg
```

Common targets:
- Thumbnail: `scale=300:300:force_original_aspect_ratio=increase,crop=300:300`
- Web hero: `scale=1920:-1`
- Instagram square: `scale=1080:1080:force_original_aspect_ratio=decrease,pad=1080:1080:(ow-iw)/2:(oh-ih)/2`
- Vertical story: `scale=1080:1920:force_original_aspect_ratio=decrease,pad=1080:1920:(ow-iw)/2:(oh-ih)/2`

---

## 8. Limitations

- Can do: resize, convert, crop, compress, rotate, flip, metadata and batch loops
- Cannot do: generation, composition, text rendering on images, vector input such as SVG
- WebP output needs a build with a WebP encoder, AVIF output needs an AV1 encoder
- One ffmpeg process per file. Batch work is a shell loop, not a single atomic call
- Keep enough free disk space for the output before starting a large batch

---

*This reference covers image processing with installed FFmpeg. For the MEDIA thinking method, see the MEDIA Framework. For conversation flow and error handling, see Interactive Intelligence.*
