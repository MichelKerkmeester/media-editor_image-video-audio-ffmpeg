---
title: "Media Editor - Integrations - FFmpeg Video Audio - v0.212"
description: "FFmpeg and ffprobe commands, operation recipes, codec and format guidance for video and audio processing operations."
version: "0.212"
contextType: reference
importance_tier: high
trigger_phrases:
  - "ffmpeg video audio"
  - "transcode trim concatenate"
  - "extract audio remove silence"
  - "video operation commands"
  - "ffprobe media metadata"
---

# Media Editor - Integrations - FFmpeg Video Audio - v0.212

Technical reference for video and audio processing with locally installed FFmpeg and ffprobe.

---

## 1. Overview

### Purpose

Defines the FFmpeg and ffprobe commands for video and audio work. It is the technical reference for conversion, trimming, concatenation, speed changes, resolution and aspect ratio, codecs, overlays, audio extraction, normalization and silence removal.

### When to use

- Loaded on demand for any video or audio processing operation
- Looking up FFmpeg commands, codecs, formats and limits
- Applying conversion, editing, audio processing and quality guidance

### Precondition

When the Media Editor tools are connected, use them: they bring their own ffmpeg, and `media_health` reports what it can do. Otherwise use FFmpeg on the path, and when neither answers, give the exact command as advice and say that nothing ran. Check for FFmpeg once per session:

```bash
ffmpeg -version
```

`ffprobe` ships with FFmpeg and covers inspection. The local route needs no server, no login and no network. If neither the tools nor the check answers, give the command as advice with install guidance and run nothing.

---

## 2. Tool overview

FFmpeg handles video and audio in one command. The input, the codec and filter options, and the output format decide the result.

- Inspect the source with `ffprobe`
- Convert, trim, concatenate, resize, re-encode and extract with `ffmpeg`
- Audio work is the same tool with `-vn` to drop video or `-af` to filter audio
- Write results to `media files/export/[###] - [description]/` in the runtime. A Media Editor tool writes its own `NNN - description/` folder and returns the path, and that folder is the export

Encoder availability varies by build. Check the common encoders before promising a format:

```bash
ffmpeg -encoders | grep -E "libx264|libx265|libvpx|aac|libmp3lame"
```

---

## 3. Core capabilities

- **Convert:** change container and codec
- **Trim:** extract a time range
- **Concatenate:** join clips in order
- **Speed:** slow motion or timelapse
- **Resolution:** set width and height
- **Aspect ratio:** fit and pad to a target frame
- **Codec and bitrate:** choose the encoder and the size ceiling
- **Frame rate:** resample or reduce
- **Fades:** video and audio fade in and out
- **Image overlay:** watermark or logo
- **Audio:** extract, convert, normalize and remove silence
- **Inspect:** read streams, duration and format with `ffprobe`
- **HLS:** adaptive streaming uses the HLS conversion asset

Build-dependent work: text burn-in and subtitle burn-in need the `drawtext`, `subtitles` or `ass` filters, which some builds omit. Check before promising them:

```bash
ffmpeg -filters | grep -E "drawtext|subtitles|ass "
```

---

## 4. Video operations

### Format conversion

```bash
ffmpeg -i INPUT.mov OUTPUT.mp4
```

The plain command picks sensible defaults for the container. For explicit control:

```bash
ffmpeg -i INPUT.mov -c:v libx264 -crf 23 -preset medium -c:a aac -b:a 128k OUTPUT.mp4
```

### Trim

```bash
ffmpeg -ss 00:00:30 -to 00:02:00 -i INPUT.mp4 -c copy OUTPUT.mp4
```

`-c copy` is fast and cuts at the nearest keyframe. Drop `-c copy` for a frame-accurate cut at the cost of a re-encode.

### Concatenate

```bash
printf "file '%s'\n" clip-1.mp4 clip-2.mp4 > list.txt
ffmpeg -f concat -safe 0 -i list.txt -c copy OUTPUT.mp4
```

All clips need the same codecs, frame size and frame rate for `-c copy`. Re-encode when they differ.

### Speed

```bash
ffmpeg -i INPUT.mp4 -filter:v "setpts=0.5*PTS" -filter:a "atempo=2.0" OUTPUT.mp4
```

`setpts=0.5*PTS` doubles speed and `setpts=2.0*PTS` halves it. `atempo` accepts 0.5 to 2.0 per instance, so chain it for stronger changes, for example `atempo=2.0,atempo=2.0` for four times.

### Resolution and aspect ratio

```bash
ffmpeg -i INPUT.mp4 -vf scale=1280:720 -c:a copy OUTPUT.mp4
ffmpeg -i INPUT.mp4 -vf "scale=1080:1080:force_original_aspect_ratio=decrease,pad=1080:1080:(ow-iw)/2:(oh-ih)/2" -c:a copy OUTPUT.mp4
```

| Ratio | Use case | Common resolutions |
| --- | --- | --- |
| 16:9 | Standard video, YouTube and TV | 1920x1080, 1280x720 |
| 1:1 | Social media square | 1080x1080, 720x720 |
| 9:16 | Vertical video, Stories and TikTok | 1080x1920, 720x1280 |
| 21:9 | Cinematic ultrawide | 2560x1080, 3440x1440 |

### Codec, bitrate and frame rate

```bash
ffmpeg -i INPUT.mp4 -c:v libx264 -crf 23 -preset medium -c:a aac -b:a 128k OUTPUT.mp4
ffmpeg -i INPUT.mp4 -c:v libx265 -crf 28 -c:a aac OUTPUT.mp4
ffmpeg -i INPUT.mp4 -c:v libvpx-vp9 -crf 32 -b:v 0 -c:a libopus OUTPUT.webm
ffmpeg -i INPUT.mp4 -b:v 5M OUTPUT.mp4
ffmpeg -i INPUT.mp4 -r 30 -c:a copy OUTPUT.mp4
```

---

## 5. Audio operations

```bash
ffmpeg -i INPUT.mp4 -vn -c:a libmp3lame -b:a 192k OUTPUT.mp3
ffmpeg -i INPUT.mp4 -vn -c:a copy OUTPUT.m4a
ffmpeg -i INPUT.wav -c:a aac -b:a 192k OUTPUT.m4a
ffmpeg -i INPUT.mp4 -vn -af loudnorm OUTPUT.wav
ffmpeg -i INPUT.mp4 -af "silenceremove=stop_periods=-1:stop_duration=0.5:stop_threshold=-40dB" -vn OUTPUT.wav
```

- `-vn` drops the video stream
- `-c:a copy` keeps the original audio without re-encoding
- `loudnorm` applies EBU R128 loudness normalization in one pass
- `silenceremove` removes silence above the threshold and for longer than the duration

### Audio quality guidelines

| Preset | Bitrate | Use case | Quality |
| --- | --- | --- | --- |
| Voice only | 96k | Speech and podcasts | Acceptable for voice |
| Standard | 128k | General audio | Good for most uses |
| Music streaming | 192k | Music, good quality | High quality audio |
| High quality | 256k | High quality music | Very high quality |
| Maximum | 320k | Archival and production | Maximum quality |

Sample rates: 22.05 kHz for minimal voice, 44.1 kHz for CD quality, 48 kHz for professional work. Channels: 1 for mono voice, 2 for stereo music and video.

---

## 6. Fades and overlays

```bash
ffmpeg -i INPUT.mp4 -vf "fade=t=in:st=0:d=1" -c:a copy OUTPUT.mp4
ffmpeg -i INPUT.mp4 -af "afade=t=in:st=0:d=1" -vn OUTPUT.wav
ffmpeg -i INPUT.mp4 -i logo.png -filter_complex "[1:v]scale=120:-1[logo];[0:v][logo]overlay=20:20" -c:a copy OUTPUT.mp4
ffmpeg -i CLIP-A.mp4 -i CLIP-B.mp4 -filter_complex "[0:v][1:v]xfade=transition=fade:duration=1:offset=4" -c:a copy OUTPUT.mp4
```

The overlay position is x and y from the top left corner. A watermark usually sits at `20:20` for the top left or `main_w-overlay_w-20:20` for the top right. `xfade` needs both clips at the same frame size and pixel format, so scale them to match first.

---

## 7. Format support

**Video:**
- MP4 (H.264, H.265, AAC and MP3): universal compatibility
- MOV (H.264, ProRes, AAC and PCM): Apple ecosystem
- AVI: legacy systems
- MKV: maximum flexibility
- WebM (VP8, VP9 and Opus): web streaming

**Audio:**
- MP3: lossy, universal playback
- WAV (PCM): lossless, editing and production
- AAC: lossy, modern devices
- FLAC: lossless, archival
- OGG (Vorbis): lossy, open source

The container must accept the chosen streams. MP4 does not carry VP9 or Opus reliably, so WebM is the container for that pair.

---

## 8. Codec specifications

**Video codecs:**
- H.264 (libx264): universal compatibility, good compression, fast. Default choice
- H.265 (libx265): modern devices, about half the size of H.264 at the same quality, slower. Size optimization
- VP9 (libvpx-vp9): web browsers, good compression, slow. Web streaming and WebM
- ProRes: professional editing, minimal compression, very fast. Production workflow

**Audio codecs:**
- AAC: modern standard, excellent quality at low bitrates. Default choice
- MP3 (libmp3lame): universal compatibility, good quality
- PCM: uncompressed, perfect quality. Editing and production
- FLAC: lossless, perfect quality. Archival
- Opus (libopus): modern, excellent quality. Streaming efficiency

---

## 9. Performance and limitations

| File size | Trim | Convert | Compress |
| --- | --- | --- | --- |
| Under 100MB | 1-5s | 5-15s | 10-30s |
| 100MB to 1GB | 5-20s | 30-120s | 60-300s |
| Over 1GB | 20-60s | 2-10min | 5-20min |

- Required: the Media Editor tools or FFmpeg on the path, sufficient disk space, read and write permission on the working folders
- Large files take minutes. Tell the user the expected time and suggest splitting when that is acceptable
- Can do: format conversion, transcoding, trimming, concatenation, resolution and aspect changes, fades, image overlays, audio extraction, audio conversion, normalization and silence removal
- Cannot do: AI content generation, complex non-linear editing, real-time processing, direct upload to platforms
- Text burn-in and subtitle burn-in depend on optional filters. Confirm the filter exists before promising the result
- `-c copy` keeps quality and speed but cuts at keyframes and cannot change the encoding

---

*This reference covers video and audio processing with installed FFmpeg. For adaptive streaming recipes, see the HLS Video Conversion asset. For the MEDIA thinking method, see the MEDIA Framework. For conversation flow and error handling, see Interactive Intelligence.*
