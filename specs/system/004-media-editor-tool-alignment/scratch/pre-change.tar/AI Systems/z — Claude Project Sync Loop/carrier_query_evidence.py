#!/usr/bin/env python3
# ───────────────────────────────────────────────────────────────
# COMPONENT: CARRIER QUERY EVIDENCE
# ───────────────────────────────────────────────────────────────
"""Evidence that the carrier query catches what it claims to catch.

Four replays run the current query against a historical tree written out by
`git archive`, never by checking out, so each is judged as it actually stood
at that commit rather than as it reads today. A replay is red only when
`carrier_query.py walk` itself exits non-zero on that archived tree: a
disposition of `finding`, `unmapped` or `deferred` somewhere in the run. A
mirror the walk names but does not block on, `routed-to-human`, is reported
beside the exit as a surfaced site, never in place of it. A green replay is
held to its recorded surfaced carrier set as well, because an empty walk is
green too and a control that reads only the colour cannot tell one from a
routing that stopped working. The current-tree
check requires the live walk to block on exactly the five recorded finding
mirrors, and reports the HubSpot save defect and any expired review record
beside that set. Two independence
tests probe the checker's own prohibitions directly: that the expected value
it computes never follows the mirror bytes it judges, and that the transform
split cannot launder a real finding by relabelling one class as safe. A
discovery check runs the discovery pass over an undeclared file and an
excepted file in a scratch tree, so a pass that stopped reporting real gaps
is red inside this suite rather than only at the CLI. A synthetic
adapted-pairs check proves a declared omission routes while an undeclared
addition beside it still blocks, including one whose text repeats a
sentence of the declared line, and that an omission row which outlives
its reason or whose line sits inside a longer mirror line is a parity
finding, as is one that returns with only a presentation difference or
with a declared link written as its Project title, while a line adapted in
one sentence with its others kept still holds.

Every check here redirects the query's file-reading roots to a temporary
tree and its state directory to a scratch one, so a run of this tool never
writes a record into the tracked episode state and never mutates a file
outside a temporary directory it removes when it is done. Git commands still
reach the real commit history through `GIT_DIR`, since a range like
`3dea597^..3dea597` names commits the archived tree itself carries no memory
of.

Usage:
    python3 carrier_query_evidence.py

Exit codes:
    0  every check, including the standalone unit check, came out as built
    1  at least one did not
"""

# ───────────────────────────────────────────────────────────────
# 1. IMPORTS AND RECORDED EXPECTATIONS
# ───────────────────────────────────────────────────────────────

from __future__ import annotations

import contextlib
import io
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
sys.path.insert(0, str(HERE))
import carrier_query as cq  # noqa: E402  the import follows the sys.path change
import episode_control as ec  # noqa: E402

LIVE_REPO_ROOT = cq.REPO_ROOT
LIVE_SYSTEMS_ROOT = cq.SYSTEMS_ROOT
LIVE_KNOWLEDGE_ROOT = cq.KNOWLEDGE_ROOT
LIVE_STATE_DIR = cq.STATE_DIR
LIVE_TRANSFORMS_FILE = cq.TRANSFORMS_FILE

HUBSPOT_REPLAY_RANGE = "70dbc0b^..70dbc0b"
COPYWRITER_REPLAY_RANGE = "1b149e8^..1b149e8"
DEAL_TEMPLATES_REPLAY_RANGE = "3dea597^..3dea597"
FLEET_REPLAY_RANGE = "beb18dd^..beb18dd"
INDEPENDENCE_PROBE_RANGE = FLEET_REPLAY_RANGE
MUTANT_PROBE_RANGE = FLEET_REPLAY_RANGE
# The fleet replay moved off beb18dd: 8749384 repaired the stale sentence it
# pinned, on both sides, so that range still goes red but on sites its label
# never claimed. A replay pinned to a defect that gets fixed stops proving
# its contract without anything turning red, so it is re-pinned to the
# conciseness mirrors at d726aaa5, a defect that is meant to stay.
CONCISENESS_REPLAY_RANGE = "d726aaa5^..d726aaa5"
# The live worktree's own HEAD, read before `GIT_DIR` points every later git
# call at the shared object database, whose HEAD is the main worktree's. The
# current-tree check judges the live mirrors against this commit, never
# against whatever tree the main worktree happens to hold. The base side is a
# fixed commit rather than a moving branch tip, because a push that moved a
# branch emptied the range without one byte of the tree changing and the
# check then read the legitimate empty walk as a failure. 3dea597 is the
# pinned commit the Deal Templates replay already trusts, and it still
# produces the recorded carriers this check asserts.
LIVE_HEAD = ec.git_text(LIVE_REPO_ROOT, "rev-parse", "HEAD^{commit}")
CURRENT_TREE_RANGE = f"3dea597..{LIVE_HEAD}"

# Each replay records the blocking site set its own recorded finding names,
# beside the colour, so a walk that returns the wrong carriers fails even
# when its blocked boolean happens to hold. A site is (system, pair, mirror).
# A green replay records the surfaced carrier identities its own recorded
# finding names as well, because a control that asserts only the absence of
# blocking sites passes on a walk that returned nothing at all, and a
# routing rule removed outright would go unseen. Each expected identity is
# the (system, pair, mirror) triple resolved through the same declaration
# the walk reads, printed by the run that confirmed it.
# The surfaced sets below are each green replay's own run printed whole and
# read against what that replay is meant to show, not copied from a report.
# A green replay's set is what proves its routing still runs: every identity
# is a (system, pair, mirror) triple resolved through the same declaration
# the walk reads, and a walk that returned nothing would miss all of them. A
# red replay keeps its blocking set as the contract, because its colour is
# already the finding.
#
# Barter - Blog Posts was retired on 2026-09-20 and left the declaration, so
# a replay no longer walks it and no set below names its carriers.
#
# The HubSpot replay's surfaced carriers. The range's own validators, depth
# framework and interactive mode route to their mirrors, and every other site
# is a shared reference the same range's pointers reached. Nothing blocks,
# because the recorded finding is that the surviving content is reworded.
EXPECTED_SURFACED_HUBSPOT = (
    ("barter-copywriter", "assets/artifact-template.md",
     "AI Systems/Barter - Copywriter/claude project/knowledge/Copywriter - Assets - Artifact Template - v0.205.md"),
    ("barter-copywriter", "references/brand-extensions.md",
     "AI Systems/Barter - Copywriter/claude project/knowledge/Copywriter - Context - Brand Extensions - v0.104.md"),
    ("barter-copywriter", "references/frameworks.md",
     "AI Systems/Barter - Copywriter/claude project/knowledge/Copywriter - Context - Frameworks - v0.115.md"),
    ("barter-copywriter", "references/interactive-mode.md",
     "AI Systems/Barter - Copywriter/claude project/knowledge/Copywriter - System - Interactive Mode - v0.704.md"),
    ("barter-copywriter", "references/standards.md",
     "AI Systems/Barter - Copywriter/claude project/knowledge/Copywriter - Context - Standards - v0.132.md"),
    ("barter-deal-templates", "references/brand/extensions-on-demand.md",
     "AI Systems/Barter - Deal Templates/claude project/knowledge/Barter deals - Context - Brand Extensions - On Demand - v0.110.md"),
    ("barter-deal-templates", "references/interactive-mode.md",
     "AI Systems/Barter - Deal Templates/claude project/knowledge/Barter deals - System - Interactive Mode - v0.227.md"),
    ("barter-deal-templates", "references/rules/standards.md",
     "AI Systems/Barter - Deal Templates/claude project/knowledge/Barter deals - Rules - Standards - v0.135.md"),
    ("media-editor", "assets/hls-video-conversion.md",
     "AI Systems/Media Editor/claude project/knowledge/Media Editor - Reference - HLS Video Conversion - v0.111.md"),
    ("media-editor", "references/interactive-intelligence.md",
     "AI Systems/Media Editor/claude project/knowledge/Media Editor - System - Interactive Intelligence - v0.220.md"),
    ("media-editor", "references/mcp-imagician.md",
     "AI Systems/Media Editor/claude project/knowledge/Media Editor - Integrations - MCP Imagician - v0.211.md"),
    ("media-editor", "references/mcp-video-audio.md",
     "AI Systems/Media Editor/claude project/knowledge/Media Editor - Integrations - MCP Video Audio - v0.212.md"),
    ("media-editor", "references/media-framework.md",
     "AI Systems/Media Editor/claude project/knowledge/Media Editor - Thinking - MEDIA Framework - v0.233.md"),
    ("product-owner", "assets/interactive-response-templates.md",
     "AI Systems/Product Owner/claude project/knowledge/Product Owner - Assets - Interactive Response Templates - v0.103.md"),
    ("product-owner", "references/bug-mode.md",
     "AI Systems/Product Owner/claude project/knowledge/Product Owner - Templates - Bug Mode - v0.205.md"),
    ("product-owner", "references/doc-mode.md",
     "AI Systems/Product Owner/claude project/knowledge/Product Owner - Templates - Doc Mode - v0.112.md"),
    ("product-owner", "references/interactive-mode.md",
     "AI Systems/Product Owner/claude project/knowledge/Product Owner - System - Interactive Mode - v0.408.md"),
    ("product-owner", "references/quality-scoring.md",
     "AI Systems/Product Owner/claude project/knowledge/Product Owner - Rules - Quality Scoring - v0.101.md"),
    ("product-owner", "references/story-mode.md",
     "AI Systems/Product Owner/claude project/knowledge/Product Owner - Templates - Story Mode - v0.405.md"),
    ("product-owner", "references/task-mode.md",
     "AI Systems/Product Owner/claude project/knowledge/Product Owner - Templates - Task Mode - v0.308.md"),
    ("prompt-improver", "references/depth-framework.md",
     "AI Systems/Prompt Improver/claude project/knowledge/Prompt Improver - DEPTH Thinking Framework - v0.200.md"),
    ("prompt-improver", "references/interactive-mode.md",
     "AI Systems/Prompt Improver/claude project/knowledge/Prompt Improver - Interactive Mode - v0.700.md"),
    ("sales-direct-communication", "assets/response-templates-en.md",
     "AI Systems/Sales - Direct Communication/claude project/knowledge/Sales Direct Communication - Voice - Response Templates - EN - v0.128.md"),
    ("sales-direct-communication", "assets/response-templates-nl.md",
     "AI Systems/Sales - Direct Communication/claude project/knowledge/Sales Direct Communication - Voice - Response Templates - NL - v0.127.md"),
    ("sales-direct-communication", "references/depth-framework.md",
     "AI Systems/Sales - Direct Communication/claude project/knowledge/Sales Direct Communication - Thinking - DEPTH Framework - v0.102.md"),
    ("sales-direct-communication", "references/flight-manual.md",
     "AI Systems/Sales - Direct Communication/claude project/knowledge/Sales Direct Communication - System - Flight Manual - v0.107.md"),
    ("sales-direct-communication", "references/interactive-mode.md",
     "AI Systems/Sales - Direct Communication/claude project/knowledge/Sales Direct Communication - System - Interactive Mode - v0.105.md"),
    ("sales-direct-communication", "references/quality-validators.md",
     "AI Systems/Sales - Direct Communication/claude project/knowledge/Sales Direct Communication - Rules - Quality Validators - v0.103.md"),
    ("sales-hubspot-automation", "assets/existing-automations.md",
     "AI Systems/Sales - HubSpot & Automation/claude project/knowledge/Sales HubSpot Automation - Reference - Existing Automations - v0.101.md"),
    ("sales-hubspot-automation", "assets/interactive-response-templates.md",
     "AI Systems/Sales - HubSpot & Automation/claude project/knowledge/Sales HubSpot Automation - Assets - Interactive Response Templates - v0.100.md"),
    ("sales-hubspot-automation", "assets/script-patterns-library.md",
     "AI Systems/Sales - HubSpot & Automation/claude project/knowledge/Sales HubSpot Automation - Reference - Script Patterns Library - v0.101.md"),
    ("sales-hubspot-automation", "assets/step-templates-en.md",
     "AI Systems/Sales - HubSpot & Automation/claude project/knowledge/Sales HubSpot Automation - Voice - Step Templates - EN - v0.114.md"),
    ("sales-hubspot-automation", "assets/step-templates-nl.md",
     "AI Systems/Sales - HubSpot & Automation/claude project/knowledge/Sales HubSpot Automation - Voice - Step Templates - NL - v0.114.md"),
    ("sales-hubspot-automation", "references/automation-patterns.md",
     "AI Systems/Sales - HubSpot & Automation/claude project/knowledge/Sales HubSpot Automation - Context - Automation Patterns - v0.100.md"),
    ("sales-hubspot-automation", "references/brand-extensions.md",
     "AI Systems/Sales - HubSpot & Automation/claude project/knowledge/Sales HubSpot Automation - Context - Brand Extensions - v0.100.md"),
    ("sales-hubspot-automation", "references/brand.md",
     "AI Systems/Sales - HubSpot & Automation/claude project/knowledge/Sales HubSpot Automation - Context - Brand - v0.133.md"),
    ("sales-hubspot-automation", "references/canonical-stats-registry.md",
     "AI Systems/Sales - HubSpot & Automation/claude project/knowledge/Sales HubSpot Automation - Context - Canonical Stats Registry - v0.135.md"),
    ("sales-hubspot-automation", "references/code-standards.md",
     "AI Systems/Sales - HubSpot & Automation/claude project/knowledge/Sales HubSpot Automation - Rules - Code Standards - v0.100.md"),
    ("sales-hubspot-automation", "references/depth-framework.md",
     "AI Systems/Sales - HubSpot & Automation/claude project/knowledge/Sales HubSpot Automation - Thinking - DEPTH Framework - v0.104.md"),
    ("sales-hubspot-automation", "references/gas-api-cookbook.md",
     "AI Systems/Sales - HubSpot & Automation/claude project/knowledge/Sales HubSpot Automation - Reference - GAS API Cookbook - v0.100.md"),
    ("sales-hubspot-automation", "references/hubspot-reference.md",
     "AI Systems/Sales - HubSpot & Automation/claude project/knowledge/Sales HubSpot Automation - Context - HubSpot Reference - v0.100.md"),
    ("sales-hubspot-automation", "references/human-voice-rules-en.md",
     "AI Systems/Sales - HubSpot & Automation/claude project/knowledge/Sales HubSpot Automation - Rules - Human Voice - EN - v0.210.md"),
    ("sales-hubspot-automation", "references/human-voice-rules-nl.md",
     "AI Systems/Sales - HubSpot & Automation/claude project/knowledge/Sales HubSpot Automation - Rules - Human Voice - NL - v0.220.md"),
    ("sales-hubspot-automation", "references/hvr-core.md",
     "AI Systems/Sales - HubSpot & Automation/claude project/knowledge/Sales HubSpot Automation - Rules - Human Voice Core - v0.100.md"),
    ("sales-hubspot-automation", "references/industry.md",
     "AI Systems/Sales - HubSpot & Automation/claude project/knowledge/Sales HubSpot Automation - Context - Industry - v0.130.md"),
    ("sales-hubspot-automation", "references/interactive-mode.md",
     "AI Systems/Sales - HubSpot & Automation/claude project/knowledge/Sales HubSpot Automation - System - Interactive Mode - v0.106.md"),
    ("sales-hubspot-automation", "references/market.md",
     "AI Systems/Sales - HubSpot & Automation/claude project/knowledge/Sales HubSpot Automation - Context - Market - v0.134.md"),
    ("sales-hubspot-automation", "references/platform-knowledge.md",
     "AI Systems/Sales - HubSpot & Automation/claude project/knowledge/Sales HubSpot Automation - Context - Platform Knowledge - v0.123.md"),
    ("sales-hubspot-automation", "references/quality-validators.md",
     "AI Systems/Sales - HubSpot & Automation/claude project/knowledge/Sales HubSpot Automation - Rules - Quality Validators - v0.102.md"),
    ("sales-hubspot-automation", "references/safety-validators.md",
     "AI Systems/Sales - HubSpot & Automation/claude project/knowledge/Sales HubSpot Automation - Rules - Safety Validators - v0.101.md"),
    ("sales-hubspot-automation", "references/sales-tooling.md",
     "AI Systems/Sales - HubSpot & Automation/claude project/knowledge/Sales HubSpot Automation - Context - Sales Tooling - v0.100.md"),
    ("sales-hubspot-automation", "references/sequence-copy-style-en.md",
     "AI Systems/Sales - HubSpot & Automation/claude project/knowledge/Sales HubSpot Automation - Voice - Sequence Copy Style - EN - v0.123.md"),
    ("sales-hubspot-automation", "references/sequence-copy-style-nl.md",
     "AI Systems/Sales - HubSpot & Automation/claude project/knowledge/Sales HubSpot Automation - Voice - Sequence Copy Style - NL - v0.123.md"),
    ("sales-hubspot-automation", "references/sequence-playbook.md",
     "AI Systems/Sales - HubSpot & Automation/claude project/knowledge/Sales HubSpot Automation - Context - Sequence Playbook - v0.102.md"),
    ("sales-hubspot-automation", "references/sequence-standards.md",
     "AI Systems/Sales - HubSpot & Automation/claude project/knowledge/Sales HubSpot Automation - Rules - Sequence Standards - v0.101.md"),
)

# The Copywriter replay's surfaced carriers, printed by the run and confirmed
# the same way: the range's MEQT scoring, interactive mode and standards route
# to their mirrors, the rest are shared references. Nothing blocks, for the
# same reworded-survivor reason.
EXPECTED_SURFACED_COPYWRITER = (
    ("barter-copywriter", "assets/artifact-template.md",
     "AI Systems/Barter - Copywriter/claude project/knowledge/Copywriter - Assets - Artifact Template - v0.205.md"),
    ("barter-copywriter", "assets/brand-examples.md",
     "AI Systems/Barter - Copywriter/claude project/knowledge/Copywriter - Assets - Brand Examples - v0.100.md"),
    ("barter-copywriter", "references/brand-extensions.md",
     "AI Systems/Barter - Copywriter/claude project/knowledge/Copywriter - Context - Brand Extensions - v0.104.md"),
    ("barter-copywriter", "references/brand-kernel.md",
     "AI Systems/Barter - Copywriter/claude project/knowledge/Copywriter - Context - Brand Kernel - v0.101.md"),
    ("barter-copywriter", "references/brand.md",
     "AI Systems/Barter - Copywriter/claude project/knowledge/Copywriter - Context - Brand - v0.133.md"),
    ("barter-copywriter", "references/canonical-stats-registry.md",
     "AI Systems/Barter - Copywriter/claude project/knowledge/Copywriter - Context - Canonical Stats Registry - v0.135.md"),
    ("barter-copywriter", "references/conciseness-rationale.md",
     "AI Systems/Barter - Copywriter/claude project/knowledge/Copywriter - Rules - Conciseness - On Demand Rationale - v0.100.md"),
    ("barter-copywriter", "references/conciseness.md",
     "AI Systems/Barter - Copywriter/claude project/knowledge/Copywriter - Rules - Conciseness - v0.100.md"),
    ("barter-copywriter", "references/frameworks-library.md",
     "AI Systems/Barter - Copywriter/claude project/knowledge/Copywriter - Context - Frameworks - On Demand Library - v0.102.md"),
    ("barter-copywriter", "references/frameworks.md",
     "AI Systems/Barter - Copywriter/claude project/knowledge/Copywriter - Context - Frameworks - v0.115.md"),
    ("barter-copywriter", "references/human-voice-rules.md",
     "AI Systems/Barter - Copywriter/claude project/knowledge/Copywriter - Rules - Human Voice - EN - v0.210.md"),
    ("barter-copywriter", "references/hvr-core.md",
     "AI Systems/Barter - Copywriter/claude project/knowledge/Copywriter - Rules - Human Voice Core - v0.100.md"),
    ("barter-copywriter", "references/industry.md",
     "AI Systems/Barter - Copywriter/claude project/knowledge/Copywriter - Context - Industry - v0.130.md"),
    ("barter-copywriter", "references/interactive-mode.md",
     "AI Systems/Barter - Copywriter/claude project/knowledge/Copywriter - System - Interactive Mode - v0.704.md"),
    ("barter-copywriter", "references/market.md",
     "AI Systems/Barter - Copywriter/claude project/knowledge/Copywriter - Context - Market - v0.134.md"),
    ("barter-copywriter", "references/meqt-scoring.md",
     "AI Systems/Barter - Copywriter/claude project/knowledge/Copywriter - System - MEQT Scoring - v0.305.md"),
    ("barter-copywriter", "references/platform-knowledge.md",
     "AI Systems/Barter - Copywriter/claude project/knowledge/Copywriter - Context - Platform Knowledge - v0.123.md"),
    ("barter-copywriter", "references/standards.md",
     "AI Systems/Barter - Copywriter/claude project/knowledge/Copywriter - Context - Standards - v0.132.md"),
    ("barter-deal-templates", "references/brand/extensions-on-demand.md",
     "AI Systems/Barter - Deal Templates/claude project/knowledge/Barter deals - Context - Brand Extensions - On Demand - v0.110.md"),
    ("barter-deal-templates", "references/interactive-mode.md",
     "AI Systems/Barter - Deal Templates/claude project/knowledge/Barter deals - System - Interactive Mode - v0.227.md"),
    ("barter-deal-templates", "references/rules/standards.md",
     "AI Systems/Barter - Deal Templates/claude project/knowledge/Barter deals - Rules - Standards - v0.135.md"),
    ("media-editor", "assets/hls-video-conversion.md",
     "AI Systems/Media Editor/claude project/knowledge/Media Editor - Reference - HLS Video Conversion - v0.111.md"),
    ("product-owner", "assets/interactive-response-templates.md",
     "AI Systems/Product Owner/claude project/knowledge/Product Owner - Assets - Interactive Response Templates - v0.103.md"),
    ("product-owner", "references/bug-mode.md",
     "AI Systems/Product Owner/claude project/knowledge/Product Owner - Templates - Bug Mode - v0.205.md"),
    ("product-owner", "references/doc-mode.md",
     "AI Systems/Product Owner/claude project/knowledge/Product Owner - Templates - Doc Mode - v0.112.md"),
    ("product-owner", "references/interactive-mode.md",
     "AI Systems/Product Owner/claude project/knowledge/Product Owner - System - Interactive Mode - v0.408.md"),
    ("product-owner", "references/quality-scoring.md",
     "AI Systems/Product Owner/claude project/knowledge/Product Owner - Rules - Quality Scoring - v0.101.md"),
    ("product-owner", "references/story-mode.md",
     "AI Systems/Product Owner/claude project/knowledge/Product Owner - Templates - Story Mode - v0.405.md"),
    ("product-owner", "references/task-mode.md",
     "AI Systems/Product Owner/claude project/knowledge/Product Owner - Templates - Task Mode - v0.308.md"),
    ("prompt-improver", "references/interactive-mode.md",
     "AI Systems/Prompt Improver/claude project/knowledge/Prompt Improver - Interactive Mode - v0.700.md"),
    ("sales-direct-communication", "references/depth-framework.md",
     "AI Systems/Sales - Direct Communication/claude project/knowledge/Sales Direct Communication - Thinking - DEPTH Framework - v0.102.md"),
    ("sales-direct-communication", "references/flight-manual.md",
     "AI Systems/Sales - Direct Communication/claude project/knowledge/Sales Direct Communication - System - Flight Manual - v0.107.md"),
    ("sales-direct-communication", "references/interactive-mode.md",
     "AI Systems/Sales - Direct Communication/claude project/knowledge/Sales Direct Communication - System - Interactive Mode - v0.105.md"),
    ("sales-hubspot-automation", "references/code-standards.md",
     "AI Systems/Sales - HubSpot & Automation/claude project/knowledge/Sales HubSpot Automation - Rules - Code Standards - v0.100.md"),
    ("sales-hubspot-automation", "references/depth-framework.md",
     "AI Systems/Sales - HubSpot & Automation/claude project/knowledge/Sales HubSpot Automation - Thinking - DEPTH Framework - v0.104.md"),
    ("sales-hubspot-automation", "references/interactive-mode.md",
     "AI Systems/Sales - HubSpot & Automation/claude project/knowledge/Sales HubSpot Automation - System - Interactive Mode - v0.106.md"),
    ("sales-hubspot-automation", "references/quality-validators.md",
     "AI Systems/Sales - HubSpot & Automation/claude project/knowledge/Sales HubSpot Automation - Rules - Quality Validators - v0.102.md"),
    ("sales-hubspot-automation", "references/safety-validators.md",
     "AI Systems/Sales - HubSpot & Automation/claude project/knowledge/Sales HubSpot Automation - Rules - Safety Validators - v0.101.md"),
)

REPLAYS = [
    ("deal-templates: two-variation rule stated three ways", DEAL_TEMPLATES_REPLAY_RANGE, True,
     "the range stays blocked: the dropped tier and the stale sentences are still present",
     (("barter-deal-templates", "assets/templates/artifact.md",
       "AI Systems/Barter - Deal Templates/claude project/knowledge/"
       "Barter deals - Assets - Artifact Template - v0.120.md"),),
     ()),
    ("hubspot: three removed score totals survived", HUBSPOT_REPLAY_RANGE, False,
     "the surviving content is reworded; whether two differently worded sentences state one "
     "rule is out of this phase's scope",
     (),
     EXPECTED_SURFACED_HUBSPOT),
    ("copywriter: floors-are-the-gate did not reach the prose", COPYWRITER_REPLAY_RANGE, False,
     "the surviving content is reworded; whether two differently worded sentences state one "
     "rule is out of this phase's scope",
     (),
     EXPECTED_SURFACED_COPYWRITER),
    ("fleet: the rest of the qualifying batch moved out of the eight kernels",
     CONCISENESS_REPLAY_RANGE, True,
     "the range stays blocked: a sentence removed from its authority survives in mirrors "
     "reached through a shared reference",
     (("barter-copywriter", "references/conciseness.md",
       "AI Systems/Barter - Copywriter/claude project/knowledge/"
       "Copywriter - Rules - Conciseness - v0.100.md"),
      ("barter-copywriter", "references/meqt-scoring.md",
       "AI Systems/Barter - Copywriter/claude project/knowledge/"
       "Copywriter - System - MEQT Scoring - v0.305.md"),
      ("barter-deal-templates", "assets/templates/artifact.md",
       "AI Systems/Barter - Deal Templates/claude project/knowledge/"
       "Barter deals - Assets - Artifact Template - v0.120.md"),
      ("barter-deal-templates", "references/interactive-mode.md",
       "AI Systems/Barter - Deal Templates/claude project/knowledge/"
       "Barter deals - System - Interactive Mode - v0.227.md"),
      ("barter-deal-templates", "references/rules/conciseness.md",
       "AI Systems/Barter - Deal Templates/claude project/knowledge/"
       "Barter deals - Rules - Conciseness - v0.100.md"),
      ("barter-deal-templates", "references/rules/deal-scoring.md",
       "AI Systems/Barter - Deal Templates/claude project/knowledge/"
       "Barter deals - System - DEAL Scoring - v0.103.md"),
      ("barter-deal-templates", "references/rules/standards.md",
       "AI Systems/Barter - Deal Templates/claude project/knowledge/"
       "Barter deals - Rules - Standards - v0.135.md"),
      ("media-editor", "references/mcp-imagician.md",
       "AI Systems/Media Editor/claude project/knowledge/"
       "Media Editor - Integrations - MCP Imagician - v0.211.md"),
      ("product-owner", "references/conciseness.md",
       "AI Systems/Product Owner/claude project/knowledge/"
       "Product Owner - Rules - Conciseness - v0.100.md"),
      # Not the label's defect. The 2026-09-26 ClickUp template change
      # reworded the Product Owner kernel's rule 16 residency statement from
      # "build checklists" to "build steps" on both sides, and a replay reads
      # the archived kernel under today's declaration, so the row no longer
      # matches the line this range moved and the move reads as a routed
      # addition. Recorded rather than left to turn the replay red on a site
      # no mirror can fix.
      ("product-owner", "references/quality-scoring.md",
       "AI Systems/Product Owner/claude project/knowledge/"
       "Product Owner - Rules - Quality Scoring - v0.101.md"),
      ("sales-direct-communication", "references/depth-framework.md",
       "AI Systems/Sales - Direct Communication/claude project/knowledge/"
       "Sales Direct Communication - Thinking - DEPTH Framework - v0.102.md"),
      ("sales-direct-communication", "references/quality-validators.md",
       "AI Systems/Sales - Direct Communication/claude project/knowledge/"
       "Sales Direct Communication - Rules - Quality Validators - v0.103.md"),),
     ()),
]


# ───────────────────────────────────────────────────────────────
# 2. ARCHIVE AND REDIRECTION
# ───────────────────────────────────────────────────────────────

def git_common_dir(repo: Path) -> Path:
    """The shared object database's own directory, so a git command run
    against an unrelated working directory can still resolve this
    repository's commits by name.
    """
    text = ec.git_text(repo, "rev-parse", "--git-common-dir")
    return (repo / text).resolve()


GIT_DIR = git_common_dir(LIVE_REPO_ROOT)
os.environ["GIT_DIR"] = str(GIT_DIR)


def archive_tree(commit: str) -> Path:
    """One historical commit's tree, written out with `git archive` piped to
    `tar -x`, into a fresh temporary directory. Never a checkout.
    """
    temp = Path(tempfile.mkdtemp(prefix="carrier-evidence-")).resolve()
    archive = subprocess.Popen(
        ["git", "archive", commit], cwd=str(LIVE_REPO_ROOT), stdout=subprocess.PIPE,
    )
    extract = subprocess.run(["tar", "-x", "-C", str(temp)], stdin=archive.stdout)
    archive.stdout.close()
    archive.wait()
    if archive.returncode != 0 or extract.returncode != 0:
        shutil.rmtree(temp, ignore_errors=True)
        raise RuntimeError(f"git archive {commit} | tar -x failed")
    return temp


MIRROR_VERSION_SUFFIX = re.compile(r"(.*) - v[\d.]+\.md$")


def reconcile_mirror_versions(temp: Path) -> list:
    """Today's declared mirror filename carries today's version suffix, and
    an older commit's tree carries whatever suffix that document wore then.
    When the declared name is absent, the one file in the same directory
    that matches on everything but the suffix is the same document under
    its old name, and is copied in under the declared name so a replay
    reads it rather than reporting a layout mismatch that is not the
    recorded defect.
    """
    notes = []
    for decl in cq.SYSTEMS.values():
        knowledge_dir = temp / "AI Systems" / decl["system_dir"] / "claude project" / "knowledge"
        if not knowledge_dir.is_dir():
            continue
        on_disk = {path.name for path in knowledge_dir.iterdir() if path.is_file()}
        for mirror_name in decl["pairs"]:
            if mirror_name in on_disk:
                continue
            declared_match = MIRROR_VERSION_SUFFIX.match(mirror_name)
            if not declared_match:
                continue
            prefix = declared_match.group(1)
            candidates = [
                name for name in on_disk
                if (m := MIRROR_VERSION_SUFFIX.match(name)) and m.group(1) == prefix
            ]
            if len(candidates) == 1:
                shutil.copyfile(knowledge_dir / candidates[0], knowledge_dir / mirror_name)
                notes.append(f"{decl['system_dir']}: read {candidates[0]!r} as {mirror_name!r}")
    return notes


def redirect(temp: Path, transforms_file: Path = None) -> None:
    """Point the query's file-reading roots at a temporary tree and a
    scratch state directory. The live declaration and, unless overridden,
    the live transform table stay in force, since a replay judges a
    historical tree by today's rules, not by rules that did not exist yet.
    """
    cq.REPO_ROOT = temp
    cq.SYSTEMS_ROOT = temp / "AI Systems"
    cq.KNOWLEDGE_ROOT = cq.SYSTEMS_ROOT / "z — Knowledge"
    cq.STATE_DIR = temp / "state"
    cq.TRANSFORMS_FILE = transforms_file or LIVE_TRANSFORMS_FILE


def restore() -> None:
    cq.REPO_ROOT = LIVE_REPO_ROOT
    cq.SYSTEMS_ROOT = LIVE_SYSTEMS_ROOT
    cq.KNOWLEDGE_ROOT = LIVE_KNOWLEDGE_ROOT
    cq.STATE_DIR = LIVE_STATE_DIR
    cq.TRANSFORMS_FILE = LIVE_TRANSFORMS_FILE


# ───────────────────────────────────────────────────────────────
# 3. SITE EXTRACTION
# ───────────────────────────────────────────────────────────────

def blocking_sites_of(walk_result: dict) -> list:
    """Every mirror the walk's own strict exit code blocks on: system, pair,
    mirror and the reason. This is the set a CI gate reads.
    """
    return [
        {"system": m["system"], "pair": m["pair"], "mirror": m["mirror"], "reason": m["reason"]}
        for m in walk_result["mirrors"]
        if m["disposition"] in cq.BLOCKING_DISPOSITIONS
    ]


def blocking_site_keys(sites: list) -> set:
    """The (system, pair, mirror) identity of each blocking site, the part
    of a walk's answer a boolean never shows.
    """
    return {(site["system"], site["pair"], site["mirror"]) for site in sites}


def surfaced_sites_of(walk_result: dict) -> list:
    """Every mirror the walk named anything about, blocking or routed to a
    human. transforms.md's own standard is that routing to a human is not a
    silent pass, so a replay's sites are named against that wider standard.
    """
    return [
        {"system": m["system"], "pair": m["pair"], "mirror": m["mirror"],
         "disposition": m["disposition"], "reason": m["reason"]}
        for m in walk_result["mirrors"]
        if m["disposition"] not in ("conform", "skipped-unchanged")
    ]


def live_items_of(walk_result: dict) -> list:
    """Every mirror the walk named without blocking on it: a routed-to-human
    item still surfaced, never silently dropped from a clean run.
    """
    return [
        {"system": m["system"], "pair": m["pair"], "mirror": m["mirror"],
         "disposition": m["disposition"], "reason": m["reason"]}
        for m in walk_result["mirrors"]
        if m["disposition"] not in ("conform", "skipped-unchanged")
        and m["disposition"] not in cq.BLOCKING_DISPOSITIONS
    ]


def walk_command(rev_range: str):
    """The real `carrier_query.py walk` entry point under the redirected
    roots, its exit code and the JSON it printed. A replay must read the
    command a CI gate runs, not a boolean the checker recomputed beside it,
    so a main() that stopped returning 1 on a blocked walk fails here.
    """
    printed = io.StringIO()
    with contextlib.redirect_stdout(printed):
        exit_code = cq.main(["carrier_query.py", "walk", "--range", rev_range])
    return exit_code, json.loads(printed.getvalue())


def discover_command():
    """The real `carrier_query.py discover` entry point under the redirected
    roots, its exit code and the JSON it printed, for the same reason
    `walk_command` reads the real exit: a main() that always returned 0
    would otherwise leave the discovery controls passing.
    """
    printed = io.StringIO()
    with contextlib.redirect_stdout(printed):
        exit_code = cq.main(["carrier_query.py", "discover"])
    return exit_code, json.loads(printed.getvalue())


def pairs_postdating(temp: Path) -> set:
    """Declared pairs whose source and mirror are both absent from an archived
    tree, so the pair was added after the commit being replayed.

    A replay judges a historical tree with today's declaration, which is what
    lets the current query be tested against what it would have caught. A pair
    added since then has no files in that tree, comes back `unmapped` on
    "declared mirror path is not on disk", and turns a replay red for a rule
    written after the commit it judges. That is the replay holding a tree to a
    future, not a defect the commit carried.

    Both sides must be absent. A source present with its mirror gone is the
    real missing-mirror defect and still blocks, which is the whole point of
    the `unmapped` disposition and is not what this removes.
    """
    absent = set()
    for system_id, decl in cq.SYSTEMS.items():
        system_dir = temp / "AI Systems" / decl["system_dir"]
        skill_root = system_dir / decl["skill_dir"]
        knowledge = system_dir / "claude project" / "knowledge"
        for mirror_name, skill_rel in decl["pairs"].items():
            if not (skill_root / skill_rel).exists() and not (knowledge / mirror_name).exists():
                absent.add((system_id, skill_rel))
    return absent


# ───────────────────────────────────────────────────────────────
# 4. REPLAYS
# ───────────────────────────────────────────────────────────────

def run_replay(
    label: str, rev_range: str, expect_blocked: bool, reason: str = "", expect_blocking: tuple = (),
    expect_surfaced: tuple = (),
) -> dict:
    # A green replay with no recorded surfaced set is the fail-open shape this
    # control exists to close: an empty walk would satisfy it. Such a control
    # is reported as a check that cannot run rather than allowed to pass, the
    # same way an empty result is a failure everywhere else in this suite.
    if not expect_blocked and not expect_surfaced:
        return {
            "label": label, "kind": "replay", "range": rev_range,
            "exit_code": None,
            "blocked": None, "expect_blocked": expect_blocked, "reason": (
                "the green control carries no expected surfaced carrier set, so an empty walk "
                "would pass it unchecked"
            ),
            "sites": [], "blocking_sites": [],
            "expected_blocking_sites": [], "unexpected_blocking_sites": [],
            "missing_blocking_sites": [], "colour_ok": False, "surfaced_ok": False,
            "expected_surfaced_sites": [], "missing_surfaced_sites": [],
            "unexpected_surfaced_sites": [], "live_items": [], "counts": {}, "ok": False,
        }
    resolved = ec.resolve_range(LIVE_REPO_ROOT, rev_range)
    temp = archive_tree(resolved["head"])
    try:
        reconciled = reconcile_mirror_versions(temp)
        redirect(temp)
        exit_code, result = walk_command(rev_range)
        postdating = pairs_postdating(temp)
    finally:
        restore()
        shutil.rmtree(temp, ignore_errors=True)
    # Red means the query's own exit, the one `main()` returns to the shell
    # and a CI gate reads: `blocked` is true only when some mirror came back
    # `finding`, `unmapped` or `deferred`. Every other surfaced site, a
    # `routed-to-human` mirror among them, is named beside the exit so a
    # reader can see what the run said, but it never stands in for the exit.
    # The colour alone does not prove the run named the recorded carriers, so
    # the blocking site set is compared as well. A green replay is worse: an
    # empty walk is green too, so its recorded surfaced set is compared, and
    # a walk that routed nothing fails on the identities it did not name.
    went_red = exit_code != 0
    sites = [s for s in surfaced_sites_of(result)
             if (s["system"], s["pair"]) not in postdating]
    blocking = [s for s in blocking_sites_of(result)
                if (s["system"], s["pair"]) not in postdating]
    excluded = sorted(
        (s["system"], s["pair"]) for s in blocking_sites_of(result)
        if (s["system"], s["pair"]) in postdating
    )
    observed = blocking_site_keys(blocking)
    expected = {tuple(site) for site in expect_blocking}
    unexpected = sorted(observed - expected)
    missing = sorted(expected - observed)
    surfaced_observed = {(site["system"], site["pair"], site["mirror"]) for site in sites}
    surfaced_expected = {tuple(site) for site in expect_surfaced}
    surfaced_missing = sorted(surfaced_expected - surfaced_observed)
    surfaced_unexpected = sorted(surfaced_observed - surfaced_expected) if expect_surfaced else []
    colour_ok = went_red == expect_blocked
    surfaced_ok = not surfaced_expected or (not surfaced_missing and not surfaced_unexpected)
    ok = colour_ok and not unexpected and not missing and surfaced_ok
    return {
        "label": label, "kind": "replay", "range": rev_range,
        "pairs_postdating_this_commit": excluded,
        "exit_code": exit_code,
        "blocked": went_red, "expect_blocked": expect_blocked, "reason": reason,
        "sites": sites, "blocking_sites": blocking,
        "expected_blocking_sites": sorted(expected),
        "unexpected_blocking_sites": unexpected,
        "missing_blocking_sites": missing,
        "expected_surfaced_sites": sorted(surfaced_expected),
        "missing_surfaced_sites": surfaced_missing,
        "unexpected_surfaced_sites": surfaced_unexpected,
        "surfaced_ok": surfaced_ok,
        "colour_ok": colour_ok,
        "live_items": live_items_of(result),
        "counts": result["counts"], "reconciled": reconciled, "ok": ok,
    }


# ───────────────────────────────────────────────────────────────
# 5. DEFECT AND EXPIRY PROBES
# ───────────────────────────────────────────────────────────────

HUBSPOT_DEFECT_SYSTEM = "sales-hubspot-automation"
HUBSPOT_DEFECT_PAIR = "references/interactive-mode.md"
HUBSPOT_DEFECT_TEXT = "Save to export/ BEFORE showing user (BLOCKING requirement)"


def find_line(path: Path, needle: str):
    for index, line in enumerate(path.read_text(encoding="utf-8", errors="replace").splitlines(), start=1):
        if needle in line:
            return index
    return None


def hubspot_save_defect() -> dict:
    """The first known live item: a Project mirror cannot itself write to a
    filesystem `export/` folder, so this line names a save step no Project
    session can carry out. Named directly by text and line, not only by the
    pair the walk routes, so a reader sees the defect itself, not just its
    address.
    """
    pair_lookup = {(ref.system_id, ref.skill_rel): ref for ref in cq.iter_pairs()}
    ref = pair_lookup.get((HUBSPOT_DEFECT_SYSTEM, HUBSPOT_DEFECT_PAIR))
    if ref is None or not ref.source.is_file() or not ref.mirror.is_file():
        return {"present": False}
    skill_line = find_line(ref.source, HUBSPOT_DEFECT_TEXT)
    mirror_line = find_line(ref.mirror, HUBSPOT_DEFECT_TEXT)
    return {
        "present": skill_line is not None or mirror_line is not None,
        "system": HUBSPOT_DEFECT_SYSTEM, "pair": HUBSPOT_DEFECT_PAIR,
        "skill_path": cq.lexical_relative(ref.source), "skill_line": skill_line,
        "mirror_path": cq.lexical_relative(ref.mirror), "mirror_line": mirror_line,
    }


def latest_commit_for_path(repo: Path, path: str):
    return ec.git_text(repo, "log", "-1", "--format=%H", "--", path, required=False) or None


def commit_is_older(repo: Path, older: str, newer: str) -> bool:
    if not older or not newer or older == newer:
        return False
    proc = ec.git(repo, "merge-base", "--is-ancestor", older, newer)
    return proc.returncode == 0


def expired_review_records(repo: Path) -> list:
    """The second known live item: a `reviewed_pairs` record whose confirmed
    commit predates a later commit to the same source. The record answered
    for a version of the source that has since moved, so the pair is live
    again whether or not the walk's own routing happens to touch it.
    """
    found = []
    for system_id, decl in sorted(cq.SYSTEMS.items()):
        skill_root = cq.SYSTEMS_ROOT / decl["system_dir"] / decl["skill_dir"]
        for skill_rel, review in decl.get("reviewed_pairs", {}).items():
            source_path = cq.lexical_relative(skill_root / skill_rel)
            at_commit = ec.git_text(repo, "rev-parse", f"{review['at']}^{{commit}}", required=False)
            latest = latest_commit_for_path(repo, source_path)
            if at_commit and latest and commit_is_older(repo, at_commit, latest):
                found.append({
                    "system": system_id, "pair": skill_rel, "source": source_path,
                    "reviewed_at": review["at"], "reviewed_commit": at_commit,
                    "latest_commit": latest,
                })
    return found


# ───────────────────────────────────────────────────────────────
# 6. CURRENT TREE CHECK
# ───────────────────────────────────────────────────────────────
# The finding each expected blocking identity names, the system, the pair
# and the full mirror path written out rather than resolved through the
# declaration the check reads. A pair that stops resolving is a failure of
# this check, never a smaller expectation, so the fixed triples are the
# contract and the declaration is only checked against them.
#
# Every identity below is recorded as a still-live carrier, never taken from
# a walk's own output. The Deal Templates Standards finding is absent because
# the record closes it at 7606325 and a walk over today's tree cannot
# reproduce a drift that no longer exists. That drift's permanent truth is
# asserted by the Deal Templates replay above, which walks the archived tree
# where it was live.
#
# The three conciseness mirrors: the Copywriter kernel statement carrying the
# export purity enumeration is recorded as moved to MEQT Scoring, and the
# statement records that the Rules - Conciseness document states the same
# enumeration fleet-wide. The mirrors keep the sentence, and no row with one
# of them as its home can excuse it.
#
# The Sales Direct DEPTH mirror: the kernel's DEPTH process table is recorded
# as moved into this mirror, and the removed harmonise row is the part of
# that table the moved statement does not carry.
#
# The Sales HubSpot Interactive Mode mirror: the recorded real routed
# finding, still carrying the blocking save line the Sales Direct authority
# replaced with render-before-respond.
CURRENT_TREE_BLOCKING_PAIRS = (
    ("barter-copywriter", "references/conciseness.md",
     "AI Systems/Barter - Copywriter/claude project/knowledge/"
     "Copywriter - Rules - Conciseness - v0.100.md"),
    ("barter-deal-templates", "references/rules/conciseness.md",
     "AI Systems/Barter - Deal Templates/claude project/knowledge/"
     "Barter deals - Rules - Conciseness - v0.100.md"),
    ("product-owner", "references/conciseness.md",
     "AI Systems/Product Owner/claude project/knowledge/"
     "Product Owner - Rules - Conciseness - v0.100.md"),
    ("sales-direct-communication", "references/depth-framework.md",
     "AI Systems/Sales - Direct Communication/claude project/knowledge/"
     "Sales Direct Communication - Thinking - DEPTH Framework - v0.102.md"),
    ("sales-hubspot-automation", "references/interactive-mode.md",
     "AI Systems/Sales - HubSpot & Automation/claude project/knowledge/"
     "Sales HubSpot Automation - System - Interactive Mode - v0.106.md"),
)

ROUTED_REASON_PREFIX = "routed by a shared reference at "


def own_authority_blocking_sites_of(walk_result: dict) -> list:
    """Blocking sites a pair's own authority comparison produced, as opposed
    to a shared reference that merely reaches the pair. The routed kind is
    surfaced by the multi-path check as well, and the current-tree check
    reports those beside the own kind rather than counting them among the
    declared mirrors the live walk is known to block on.
    """
    return [
        site for site in blocking_sites_of(walk_result)
        if not site["reason"].startswith(ROUTED_REASON_PREFIX)
    ]


def expected_current_tree_mirrors() -> set:
    """The fixed (system, pair, mirror) identities the live walk is expected
    to block on: the carriers the residency moves left behind and the one
    pre-move finding. The paths are literals, never resolved through the
    declaration under test, so the expectation cannot shrink when a pair
    stops resolving.
    """
    return set(CURRENT_TREE_BLOCKING_PAIRS)


def unresolved_current_tree_pairs() -> list:
    """Every expected identity the declaration no longer resolves to its
    fixed mirror path. The expectation is not derived from the declaration,
    so this names a vanished or re-pointed pair instead of letting it fall
    out of the expected set.
    """
    by_identity = {(ref.system_id, ref.skill_rel): ref for ref in cq.iter_pairs()}
    unresolved = []
    for system_id, skill_rel, mirror in CURRENT_TREE_BLOCKING_PAIRS:
        ref = by_identity.get((system_id, skill_rel))
        if ref is None or cq.lexical_relative(ref.mirror) != mirror:
            unresolved.append((system_id, skill_rel, mirror))
    return unresolved


def run_current_tree(rev_range: str = CURRENT_TREE_RANGE) -> dict:
    """The live worktree, walked with its own roots and a scratch state
    directory, must block on exactly the declared finding mirrors, own and
    routed alike. A clean exit, or a blocking set with any other member or
    any missing member, fails the check. The own and routed breakdowns are
    kept beside the whole set, and the HubSpot save defect and any expired
    review record are still named.
    """
    temp = Path(tempfile.mkdtemp(prefix="carrier-evidence-state-"))
    try:
        cq.STATE_DIR = temp
        exit_code, result = walk_command(rev_range)
    finally:
        cq.STATE_DIR = LIVE_STATE_DIR
        shutil.rmtree(temp, ignore_errors=True)
    blocking = blocking_sites_of(result)
    own_blocking = own_authority_blocking_sites_of(result)
    observed = {(site["system"], site["pair"], site["mirror"]) for site in blocking}
    expected = expected_current_tree_mirrors()
    unresolved = unresolved_current_tree_pairs()
    unexpected = sorted(observed - expected)
    missing = sorted(expected - observed)
    ok = (result["blocked"] is True and exit_code != 0
          and not unexpected and not missing and not unresolved)
    return {
        "label": "current tree", "kind": "current", "range": rev_range,
        "exit_code": exit_code,
        "blocked": result["blocked"], "expect_blocked": True,
        "sites": blocking, "live_items": live_items_of(result),
        "counts": result["counts"], "ok": ok,
        "own_blocking_sites": own_blocking,
        "routed_blocking_sites": [
            site for site in blocking if site["reason"].startswith(ROUTED_REASON_PREFIX)
        ],
        "expected_blocking_mirrors": sorted(expected),
        "unexpected_blocking_mirrors": unexpected,
        "missing_blocking_mirrors": missing,
        "unresolved_expected_pairs": unresolved,
        "hubspot_save_defect": hubspot_save_defect(),
        "expired_review_records": expired_review_records(LIVE_REPO_ROOT),
    }


# ───────────────────────────────────────────────────────────────
# 7. INDEPENDENCE TEST
# ───────────────────────────────────────────────────────────────

def run_independence_test(rev_range: str = INDEPENDENCE_PROBE_RANGE) -> dict:
    """Change a mirror document's bytes in a temp copy and show the expected
    value computed for its pair does not move, since a checker whose
    expectation follows the mirror it judges certifies itself instead of
    checking anything.
    """
    resolved = ec.resolve_range(LIVE_REPO_ROOT, rev_range)
    temp = archive_tree(resolved["head"])
    try:
        reconcile_mirror_versions(temp)
        redirect(temp)
        pair_lookup = {(ref.system_id, ref.skill_rel): ref for ref in cq.iter_pairs()}
        indexes = {
            "bindings": cq.bindings(), "pointers": cq.pointers(), "fanout": cq.fanout(),
            "duplicates": cq.duplicates(), "tokens": cq.tokens(rev_range),
        }
        transform_kinds = cq.load_transforms(cq.TRANSFORMS_FILE)
        hits = cq.touched_pairs(resolved, indexes, pair_lookup, transform_kinds)
        probe = None
        for key in sorted(hits):
            ref = hits[key]["ref"]
            choices = cq.authority_path_choices(ref, hits[key]["authority_paths"])
            if choices and ref.mirror.is_file():
                probe = (ref, choices[0][0])
                break
        if probe is None:
            return {"label": "independence", "kind": "independence", "range": rev_range,
                     "ok": False, "reason": "no touched pair with a readable mirror to probe"}
        ref, authority_path = probe
        before = cq.expected_from_commit(cq.REPO_ROOT, resolved, authority_path, indexes["tokens"], transform_kinds)
        before_key = ec.content_key(before)
        original = ref.mirror.read_bytes()
        ref.mirror.write_bytes(original + b"\nindependence probe text, never read as authority\n")
        after = cq.expected_from_commit(cq.REPO_ROOT, resolved, authority_path, indexes["tokens"], transform_kinds)
        after_key = ec.content_key(after)
        pair, mirror = ref.skill_rel, cq.lexical_relative(ref.mirror)
    finally:
        restore()
        shutil.rmtree(temp, ignore_errors=True)
    return {
        "label": "independence", "kind": "independence", "range": rev_range,
        "pair": pair, "mirror": mirror, "authority_path": authority_path,
        "before_key": before_key, "after_key": after_key, "ok": before_key == after_key,
    }


# ───────────────────────────────────────────────────────────────
# 8. MUTANT TEST
# ───────────────────────────────────────────────────────────────

def range_diff_classes(repo: Path, resolved: dict) -> set:
    """Every transform class any file changed in the range carries, read
    through the same per-file classifier the checker uses. A range's diff is
    the whole commit, not one authority's slice of it, so a class the range
    uses can have landed in any changed file.
    """
    changed = [
        path for path in
        ec.git_text(repo, "diff", "--name-only", "-z", resolved["base"], resolved["head"]).split("\0")
        if path
    ]
    classes = set()
    for path in changed:
        diff_text = ec.git_text(
            repo, "diff", "--unified=0", resolved["base"], resolved["head"], "--", path, required=False,
        )
        classes.update(cq.classify_diff(diff_text)["classes"])
    return classes


def table_rows(text: str) -> list:
    """Every readable data row of the transform table, in its own row order,
    each carrying the Kind and Status cell the parser read from that shape.

    The parser refuses a row that is not four cells rather than reading it,
    so this helper never has to decide which cell a status came from.
    """
    rows = []
    for line in text.splitlines():
        row = cq.parse_transform_row(line)
        if row and row["readable"]:
            rows.append(row)
    return rows


def semantic_classes(text: str) -> list:
    """Every class the checker treats as semantic, in the table's row order.

    A row is semantic when its Kind column says so, and also when its Status
    column does not open with a confirmed token. The table states that rule in
    its own prose: a row still awaiting is read as semantic whatever its Kind
    says, so an unconfirmed presentation label grants no automatic conform.
    """
    return [
        row["class"] for row in table_rows(text)
        if row["kind"] == "semantic" or not row["confirmed"]
    ]


def confirmed_presentation_classes(text: str) -> list:
    """The transform table's confirmed presentation classes, in its own row order."""
    return [
        row["class"] for row in table_rows(text)
        if row["kind"] == "presentation" and row["confirmed"]
    ]


def confirmed_kind_classes(text: str, kind: str) -> list:
    """The confirmed classes whose own Kind column reads the named kind.

    The fallback candidate for the mutant test is chosen from here, by the
    Kind the row actually declares, never from the semantic set, because a
    row can sit in the semantic set by its Status alone while its Kind says
    presentation, and flipping that row's Kind would change nothing at all.
    """
    return [
        row["class"] for row in table_rows(text)
        if row["kind"] == kind and row["confirmed"]
    ]


def flip_class_to_presentation(text: str, class_name: str):
    """One named semantic row's Kind rewritten to presentation, so a mutant
    table can be tried against a range that actually uses that class.
    """
    return _replace_row_kind(text, class_name, "semantic", "presentation")


def flip_class_to_semantic(text: str, class_name: str):
    """One named presentation row's Kind rewritten to semantic, so a mutant
    table can be tried against a range that actually uses that class.
    """
    return _replace_row_kind(text, class_name, "presentation", "semantic")


def _replace_row_kind(text: str, class_name: str, old_kind: str, new_kind: str):
    """One data row's Kind cell rewritten in place, matched by the class cell
    and the exact Kind cell the parser read, so no other row moves.
    """
    lines = text.splitlines(keepends=True)
    for index, line in enumerate(lines):
        row = cq.parse_transform_row(line)
        if row and row["readable"] and row["class"] == class_name and row["kind"] == old_kind:
            lines[index] = line.replace(f"| {old_kind} |", f"| {new_kind} |", 1)
            return "".join(lines)
    return None


def run_mutant_test(rev_range: str = MUTANT_PROBE_RANGE) -> dict:
    """Run the same archived range twice, once with the transform table as
    declared and once with one confirmed class flipped, and require a
    blocking site the declared run does not have. A range that blocks on the
    same set both times proves nothing about the split, because its blockers
    are reasons the flipped class never touched.

    A confirmed presentation class the range actually uses is flipped to
    semantic, so the mutated table can gain a missing-addition finding the
    declared table folds away. When the range uses no confirmed presentation
    class, a class the range uses whose own Kind reads semantic is flipped to
    presentation instead, and the check still reads the gained side: a
    mutation that only removes a blocking site has not shown the split doing
    new work. Chosen by the Kind cell, never by the semantic set alone, so a
    presentation row parked in that set by its Status is not mistaken for a
    semantic row the flip could move. When no class can be flipped the check
    reports that it could not run rather than raising.
    """
    resolved = ec.resolve_range(LIVE_REPO_ROOT, rev_range)
    range_classes = range_diff_classes(LIVE_REPO_ROOT, resolved)
    table_text = LIVE_TRANSFORMS_FILE.read_text(encoding="utf-8")
    # A table the parser refused is not a table this check can mutate: the
    # refused rows name themselves here, and the check reports that it could
    # not run rather than picking a class from a table it could not read.
    refusals = list(cq.load_transforms(LIVE_TRANSFORMS_FILE).get(cq.TRANSFORM_REFUSALS, ()))
    if refusals:
        return {
            "label": "declaration altered copy", "kind": "mutant", "range": rev_range,
            "flipped_class": None, "flip_to": None, "range_classes": sorted(range_classes),
            "blocked": None, "expect_blocked": True,
            "reason": "the transform table carries row(s) the parser refused: " + "; ".join(refusals),
            "ok": False,
        }
    presentation = [name for name in confirmed_presentation_classes(table_text) if name in range_classes]
    # The fallback is a class the range uses whose own Kind cell reads
    # semantic, not merely a class the semantic set holds: a row parked there
    # by its Status has a Kind of presentation already, and flipping that Kind
    # would write a table identical to the one it replaced.
    semantic = [name for name in confirmed_kind_classes(table_text, "semantic") if name in range_classes]
    if presentation:
        flipped_class, flip_to = presentation[0], "semantic"
    elif semantic:
        flipped_class, flip_to = semantic[0], "presentation"
    else:
        return {
            "label": "declaration altered copy", "kind": "mutant", "range": rev_range,
            "flipped_class": None, "flip_to": None, "range_classes": sorted(range_classes),
            "blocked": None, "expect_blocked": True, "reason": (
                "the range's diff carries no confirmed transform class to flip"
            ),
            "ok": False,
        }
    mutated_text = (
        flip_class_to_semantic(table_text, flipped_class)
        if flip_to == "semantic"
        else flip_class_to_presentation(table_text, flipped_class)
    )
    if mutated_text is None:
        # A candidate the flipper could not write is a check that cannot run,
        # reported as itself with the class and Kind it tried to move rather
        # than a crash after the archive was built.
        return {
            "label": "declaration altered copy", "kind": "mutant", "range": rev_range,
            "flipped_class": flipped_class, "flip_to": flip_to,
            "range_classes": sorted(range_classes), "blocked": None, "expect_blocked": True,
            "reason": (
                f"the flipper found no row whose class is {flipped_class!r} and whose Kind reads "
                f"the kind being flipped, so no altered table could be written"
            ),
            "ok": False,
        }
    temp = archive_tree(resolved["head"])
    try:
        reconciled = reconcile_mirror_versions(temp)
        redirect(temp)
        declared = cq.walk(rev_range)
        mutant_file = temp / "transforms.mutant.md"
        mutant_file.write_text(mutated_text, encoding="utf-8")
        redirect(temp, transforms_file=mutant_file)
        flipped = cq.walk(rev_range)
    finally:
        restore()
        shutil.rmtree(temp, ignore_errors=True)
    declared_mirrors = {site["mirror"] for site in blocking_sites_of(declared)}
    flipped_mirrors = {site["mirror"] for site in blocking_sites_of(flipped)}
    gained = sorted(flipped_mirrors - declared_mirrors)
    lost = sorted(declared_mirrors - flipped_mirrors)
    return {
        "label": "declaration altered copy", "kind": "mutant", "range": rev_range,
        "flipped_class": flipped_class, "flip_to": flip_to, "range_classes": sorted(range_classes),
        "blocked": flipped["blocked"], "expect_blocked": True,
        "sites": surfaced_sites_of(flipped),
        "blocking_sites": blocking_sites_of(flipped), "reconciled": reconciled,
        "declared_blocked": declared["blocked"],
        "declared_blocking_mirrors": sorted(declared_mirrors),
        "flipped_blocking_mirrors": sorted(flipped_mirrors),
        "gained_blocking_mirrors": gained,
        "lost_blocking_mirrors": lost,
        "ok": bool(gained),
    }


# ───────────────────────────────────────────────────────────────
# 9. DISCOVERY CHECK
# ───────────────────────────────────────────────────────────────

def discovery_gap_probe(temp: Path, exceptions_file: Path, relative: str) -> dict:
    """One temp tree walked by the real discovery pass, with the exception
    list under test, returning the paths it reported as unnamed.
    """
    target = temp / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text("# Probe document\n\nOne line, so the file is real.\n", encoding="utf-8")
    saved = (cq.REPO_ROOT, cq.SYSTEMS_ROOT, cq.KNOWLEDGE_ROOT, cq.DISCOVER_EXCEPTIONS_FILE)
    cq.REPO_ROOT = temp
    cq.SYSTEMS_ROOT = temp / "AI Systems"
    cq.KNOWLEDGE_ROOT = cq.SYSTEMS_ROOT / "z — Knowledge"
    cq.DISCOVER_EXCEPTIONS_FILE = exceptions_file
    try:
        exit_code, result = discover_command()
    finally:
        (cq.REPO_ROOT, cq.SYSTEMS_ROOT, cq.KNOWLEDGE_ROOT, cq.DISCOVER_EXCEPTIONS_FILE) = saved
    return {"count": result["count"], "unnamed": result["unnamed"], "probe": relative,
            "exit_code": exit_code}


def run_discovery_check() -> dict:
    """Discovery's own controls, one undeclared file and one excepted file,
    each walked in a temp tree by the real pass, with the live tree's own
    result reported beside them.

    The undeclared control must come back red: the file sits at a path the
    declaration does not name and no exception matches it, so the pass
    reports it and exits 1. A loader that accepted every glob would have
    reported nothing there. The exception control must come back green: the
    same shape of file sits under a permitted benchmark glob and is excepted
    by name, so the pass reports nothing. A loader that refused every entry
    would have reported the file anyway. The live run is printed unchanged,
    because a real gap is what the pass exists to report and its count is
    evidence rather than a verdict on the pass.
    """
    undeclared_temp = Path(tempfile.mkdtemp(prefix="carrier-evidence-discovery-"))
    declared_temp = Path(tempfile.mkdtemp(prefix="carrier-evidence-discovery-"))
    try:
        no_exceptions = undeclared_temp / "exceptions-none.md"
        no_exceptions.write_text("```\n```\n", encoding="utf-8")
        benchmark_exceptions = declared_temp / "exceptions-benchmark.md"
        benchmark_exceptions.write_text(
            "```\n**/benchmark/**/*.md  # benchmark notes and fixtures\n```\n", encoding="utf-8")
        undeclared = discovery_gap_probe(
            undeclared_temp, no_exceptions, "AI Systems/Probe System/unlisted-note.md")
        excepted = discovery_gap_probe(
            declared_temp, benchmark_exceptions, "AI Systems/Probe System/benchmark/notes.md")
        undeclared_red = (
            undeclared["probe"] in undeclared["unnamed"] and undeclared["exit_code"] == 1)
        excepted_green = (
            excepted["probe"] not in excepted["unnamed"] and excepted["exit_code"] == 0)
        live_exit, live = discover_command()
        return {
            "label": "discovery: an undeclared file is red, an excepted file is green",
            "kind": "discovery",
            "undeclared_control": undeclared,
            "excepted_control": excepted,
            "undeclared_red": undeclared_red, "excepted_green": excepted_green,
            "live_count": live["count"], "live_exceptions_applied": live["exceptions_applied"],
            "live_exit": live_exit,
            "ok": undeclared_red and excepted_green,
        }
    finally:
        shutil.rmtree(undeclared_temp, ignore_errors=True)
        shutil.rmtree(declared_temp, ignore_errors=True)


# ───────────────────────────────────────────────────────────────
# 10. ADAPTED PAIRS CHECK
# ───────────────────────────────────────────────────────────────

def load_gate_module():
    """Execute the shared gate's source text into a namespace, the way
    `residency_check.py` reads it, so the parity check it owns runs against
    the same bytes a wrapper would read.
    """
    path = HERE / "validate_parity.py"
    namespace = {"__file__": str(path), "__name__": "validate_parity"}
    exec(compile(path.read_text(encoding="utf-8"), str(path), "exec"), namespace)
    return namespace


def adapted_expected(added: list) -> dict:
    """The expected value the mirror comparison reads, shaped the way
    `expected_from_commit` returns it, with only the added-line signal the
    probe needs populated. The probe feeds whole added lines, and the
    sentence signal is read from them through the same extraction the real
    expected value uses, because the exemption judges the lines a diff
    carried, not sentences on their own.
    """
    diff_text = "".join(f"+{line}\n" for line in added)
    return {
        "diff_text": diff_text,
        "moved_tokens": [], "removed_tokens": [], "added_tokens": [],
        "removed_sentences": [],
        "added_sentences": cq.extract_sentences(diff_text, "+"),
        "removed_sentence_contexts": {},
        "diff_classes": {"classes": [], "unclassified": []},
    }


MOVED_PROBE_DECLARED = (
    "Word ceilings are hard: Most authentic 90-130, Most concise 50-70, revise before export."
)
MOVED_PROBE_UNDECLARED = (
    "Word floors are hard: Most authentic 60 at least, Most concise 30 at least, every time."
)


def run_moved_token_probe(transform_kinds: dict) -> tuple:
    """The moved-token path under `adapted_pairs`, called on the real
    comparison. A token whose new line is a declared omission must route
    naming that line, and the same shape on a line the declaration does not
    name must still block, so the exemption stays precise to the declared line.
    """
    system_id = "moved-token-probe"
    skill_rel = "assets/template.md"
    cq.SYSTEMS[system_id] = {
        "system_dir": "Moved Token Probe",
        "skill_dir": "sk-probe",
        "display_name": "Moved Token Probe",
        "pairs": {"Probe - Template - v0.100.md": skill_rel},
        "unmirrored_sources": {},
        "adapted_pairs": {
            skill_rel: {"why": "export has no meaning inside a Project",
                        "omits": (MOVED_PROBE_DECLARED,)},
        },
        "residency": [],
    }
    mirror_bytes = b"# Probe mirror\n\nWord ceilings are hard, revise before delivery.\n"
    try:
        ref = cq.PairRef(
            system_id=system_id, display_name="Moved Token Probe", skill_rel=skill_rel,
            mirror_name="Probe - Template - v0.100.md",
            source=Path("AI Systems/Moved Token Probe/sk-probe") / skill_rel,
            mirror=Path("AI Systems/Moved Token Probe/claude project/knowledge/"
                        "Probe - Template - v0.100.md"),
        )
        authority_path = f"AI Systems/Moved Token Probe/sk-probe/{skill_rel}"

        def moved(line: str) -> dict:
            expected = adapted_expected([])
            expected["moved_tokens"] = [{
                "label": "most authentic", "before": "80-120", "after": "90-130",
                "before_line": line.replace("90-130", "80-120"), "after_line": line,
            }]
            return expected

        declared = cq.compare_expected_observed(
            moved(MOVED_PROBE_DECLARED), mirror_bytes, transform_kinds,
            ref=ref, authority_path=authority_path)
        undeclared = cq.compare_expected_observed(
            moved(MOVED_PROBE_UNDECLARED.replace("60", "90-130")), mirror_bytes,
            transform_kinds, ref=ref, authority_path=authority_path)
    finally:
        del cq.SYSTEMS[system_id]
    return declared[0], declared[1], undeclared[0], undeclared[1]


def run_symlink_authority_probe() -> tuple:
    """Which own authority a pair gets when its source is a symlink to a card
    the range did not touch, against a regular file at the same path. The
    link's diff is only the target path, so the symlink must give no own
    authority, while the regular file keeps its source authority.
    """
    temp = Path(tempfile.mkdtemp(prefix="carrier-evidence-symlink-"))
    try:
        card = temp / "AI Systems" / "z — Knowledge" / "Rules - Probe Card - v0.100.md"
        card.parent.mkdir(parents=True)
        card.write_text("# Rules - Probe Card - v0.100\n\nOne rule.\n", encoding="utf-8")
        source = temp / "AI Systems" / "Symlink Probe" / "sk-probe" / "references" / "card.md"
        source.parent.mkdir(parents=True)
        source.symlink_to(os.path.relpath(card, source.parent))
        mirror = temp / "AI Systems" / "Symlink Probe" / "claude project" / "knowledge" / "Probe.md"
        redirect(temp)
        cq.SYSTEMS["symlink-probe"] = {
            "system_dir": "Symlink Probe", "skill_dir": "sk-probe", "display_name": "Symlink Probe",
            "pairs": {"Probe.md": "references/card.md"}, "unmirrored_sources": {}, "residency": [],
        }
        try:
            ref = cq.PairRef(
                system_id="symlink-probe", display_name="Symlink Probe",
                skill_rel="references/card.md", mirror_name="Probe.md",
                source=source, mirror=mirror)
            source_rel = cq.lexical_relative(source)
            symlink_choices = cq.authority_path_choices(ref, {source_rel})
            source.unlink()
            source.write_text("# Card\n\nOne rule.\n", encoding="utf-8")
            regular_choices = cq.authority_path_choices(ref, {source_rel})
        finally:
            del cq.SYSTEMS["symlink-probe"]
            restore()
    finally:
        shutil.rmtree(temp, ignore_errors=True)
    return symlink_choices, regular_choices


def run_adapted_pairs_check() -> dict:
    """The `adapted_pairs` declaration's contracts, exercised directly.

    A synthetic system is injected into the loaded declaration and the real
    comparison is called on it: a missing addition matching a declared
    omission must route, an undeclared addition beside it must still block
    naming only itself, and an undeclared added line whose text repeats one
    sentence of a declared two-sentence line must still block, because the
    exemption covers the declared line itself and not a sentence of it
    arriving on another line. The gate's own check then runs over a scratch
    system, where a row that still describes its pair must pass, a row
    naming a line the source dropped must come back a finding, and a row
    whose omitted line sits inside a longer mirror line must come back a
    finding. A declared two-sentence line whose mirror keeps one sentence and
    rewrites the other must still hold, because the kept sentence is not the
    omission coming back.
    """
    system_id = "adapted-pairs-probe"
    skill_rel = "references/rules.md"
    omitted_line = "8. Show the full sequence in chat before export."
    two_sentence_omitted = (
        "Rule one of the pair is dropped on purpose. "
        "Rule two of the pair is dropped on purpose."
    )
    collision_line = "Rule two of the pair is dropped on purpose."
    undeclared_line = "9. Post the rendered sequence without any review."
    mirror_bytes = (
        b"# Probe mirror\n\n"
        b"8. Hand back an export-equivalent path in place of the rendered sequence.\n"
    )
    transform_kinds = cq.load_transforms(cq.TRANSFORMS_FILE)
    cq.SYSTEMS[system_id] = {
        "system_dir": "Adapted Pairs Probe",
        "skill_dir": "sk-probe",
        "display_name": "Adapted Pairs Probe",
        "pairs": {"Probe - Rules - v0.100.md": skill_rel},
        "unmirrored_sources": {},
        "adapted_pairs": {
            skill_rel: {
                "why": "the source's export step has no meaning inside a Project",
                "omits": (omitted_line, two_sentence_omitted),
            },
        },
        "residency": [],
    }
    try:
        ref = cq.PairRef(
            system_id=system_id,
            display_name="Adapted Pairs Probe",
            skill_rel=skill_rel,
            mirror_name="Probe - Rules - v0.100.md",
            source=Path("AI Systems/Adapted Pairs Probe/sk-probe") / skill_rel,
            mirror=Path(
                "AI Systems/Adapted Pairs Probe/claude project/knowledge/"
                "Probe - Rules - v0.100.md"
            ),
        )
        authority_path = f"AI Systems/Adapted Pairs Probe/sk-probe/{skill_rel}"
        omitted = list(cq.sentences_of(omitted_line))
        undeclared = list(cq.sentences_of(undeclared_line))
        collision = list(cq.sentences_of(collision_line))
        routed, routed_reason = cq.compare_expected_observed(
            adapted_expected([omitted_line]), mirror_bytes, transform_kinds,
            ref=ref, authority_path=authority_path)
        blocked, blocked_reason = cq.compare_expected_observed(
            adapted_expected([omitted_line, undeclared_line]), mirror_bytes,
            transform_kinds, ref=ref, authority_path=authority_path)
        collided, collided_reason = cq.compare_expected_observed(
            adapted_expected([collision_line]), mirror_bytes, transform_kinds,
            ref=ref, authority_path=authority_path)
    finally:
        del cq.SYSTEMS[system_id]

    temp = Path(tempfile.mkdtemp(prefix="carrier-evidence-adapted-"))
    saved_git_dir = os.environ.pop("GIT_DIR", None)
    try:
        gate = load_gate_module()
    finally:
        if saved_git_dir is not None:
            os.environ["GIT_DIR"] = saved_git_dir
    try:
        system = temp / "Adapted Pairs Probe"
        source = system / "sk-probe" / skill_rel
        mirror = system / "claude project" / "knowledge" / "Probe - Rules - v0.100.md"
        source.parent.mkdir(parents=True)
        mirror.parent.mkdir(parents=True)
        source.write_text(
            "# Rules\n\n7. Keep the sequence short.\n" + omitted_line + "\n",
            encoding="utf-8")
        mirror.write_text(mirror_bytes.decode("utf-8"), encoding="utf-8")
        pairs = [(source, mirror, skill_rel)]
        decl = {
            "skill_dir": "sk-probe",
            "pairs": {"Probe - Rules - v0.100.md": skill_rel},
            "adapted_pairs": {
                skill_rel: {"why": "a recorded decision", "omits": (omitted_line,)},
            },
        }
        saved_root = gate["SYSTEMS_ROOT"]
        gate["SYSTEMS_ROOT"] = temp
        try:
            held_findings, held_notes = [], []
            gate["check_adapted_pairs"](system, pairs, decl, held_findings, held_notes)
            stale_decl = {
                **decl,
                "adapted_pairs": {
                    skill_rel: {
                        "why": "a recorded decision",
                        "omits": ("8. Send the sequence before anyone reads it.",),
                    },
                },
            }
            stale_findings, stale_notes = [], []
            gate["check_adapted_pairs"](
                system, pairs, stale_decl, stale_findings, stale_notes)
            mirror.write_text(
                "# Probe mirror\n\n"
                "8. Hand back an export-equivalent path in place of the rendered sequence.\n"
                "Check the draft once before anything leaves. "
                "Show the full sequence in chat before export.\n",
                encoding="utf-8")
            embedded_findings, embedded_notes = [], []
            gate["check_adapted_pairs"](
                system, pairs, decl, embedded_findings, embedded_notes)
            source.write_text(
                "# Rules\n\n7. Keep the sequence short.\n" + two_sentence_omitted + "\n",
                encoding="utf-8")
            mirror.write_text(
                "# Probe mirror\n\n"
                "Rule one of the pair is adapted for a Project. "
                "Rule two of the pair is dropped on purpose.\n",
                encoding="utf-8")
            partial_decl = {
                **decl,
                "adapted_pairs": {
                    skill_rel: {"why": "a recorded decision", "omits": (two_sentence_omitted,)},
                },
            }
            partial_findings, partial_notes = [], []
            gate["check_adapted_pairs"](
                system, pairs, partial_decl, partial_findings, partial_notes)
            presented_line = (
                "Alpha beta gamma delta epsilon one. Zeta eta theta iota kappa two."
            )
            source.write_text(
                "# Rules\n\n7. Keep the sequence short.\n" + presented_line + "\n",
                encoding="utf-8")
            mirror.write_text(
                "# Probe mirror\n\n"
                "Alpha beta gamma delta epsilon one.\n"
                "Zeta eta theta iota kappa two!\n",
                encoding="utf-8")
            presented_decl = {
                **decl,
                "adapted_pairs": {
                    skill_rel: {"why": "a recorded decision", "omits": (presented_line,)},
                },
            }
            presented_findings, presented_notes = [], []
            gate["check_adapted_pairs"](
                system, pairs, presented_decl, presented_findings, presented_notes)
            # A declared line carrying a link to a declared pair, returned in
            # the mirror as that pair's Project title. The scratch pair sits in
            # a folder the walk names inside the Copywriter skill, so the link
            # resolves through the live declaration, and the title comes from
            # the walk itself so a version bump never strands the probe.
            linked_ref = next(
                ref for ref in cq.iter_pairs()
                if ref.system_id == "barter-copywriter"
                and ref.skill_rel == "references/brand-extensions.md"
            )
            linked_line = (
                "See [Brand](references/brand-extensions.md) for the tone rules "
                "and the voice examples."
            )
            linked_system = temp / "Barter - Copywriter"
            linked_source = linked_system / "sk-barter-copywriter" / "probe-links.md"
            linked_mirror = (
                linked_system / "claude project" / "knowledge" / "Probe - Links - v0.100.md"
            )
            linked_source.parent.mkdir(parents=True)
            linked_mirror.parent.mkdir(parents=True)
            linked_source.write_text("# Links\n\n" + linked_line + "\n", encoding="utf-8")
            linked_mirror.write_text(
                "# Probe mirror\n\n"
                f"See {cq.mirror_title(linked_ref)} for the tone rules and the voice examples.\n",
                encoding="utf-8")
            linked_decl = {
                "skill_dir": "sk-barter-copywriter",
                "pairs": {"Probe - Links - v0.100.md": "probe-links.md"},
                "adapted_pairs": {
                    "probe-links.md": {"why": "a recorded decision", "omits": (linked_line,)},
                },
            }
            linked_findings, linked_notes = [], []
            gate["check_adapted_pairs"](
                linked_system, [(linked_source, linked_mirror, "probe-links.md")],
                linked_decl, linked_findings, linked_notes)
        finally:
            gate["SYSTEMS_ROOT"] = saved_root
    finally:
        shutil.rmtree(temp, ignore_errors=True)

    moved_declared, moved_declared_reason, moved_undeclared, moved_undeclared_reason = (
        run_moved_token_probe(transform_kinds))
    symlink_choices, regular_choices = run_symlink_authority_probe()

    probes = [
        {
            "name": "declared omission routes",
            "ok": routed == "routed-to-human" and omitted_line in routed_reason,
            "detail": f"disposition {routed}: {routed_reason}",
        },
        {
            "name": "undeclared addition still blocks",
            "ok": (
                blocked == "finding"
                and undeclared[0] in blocked_reason
                and omitted[0] not in blocked_reason
            ),
            "detail": f"disposition {blocked}: {blocked_reason}",
        },
        {
            "name": "undeclared line repeating a declared sentence still blocks",
            "ok": collided == "finding" and collision[0] in collided_reason,
            "detail": f"disposition {collided}: {collided_reason}",
        },
        {
            "name": "stale omission row is a parity finding",
            "ok": not held_findings and any(skill_rel in f for f in stale_findings),
            "detail": (
                f"held row findings: {held_findings or 'none'}; "
                f"stale row findings: {stale_findings or 'none'}"
            ),
        },
        {
            "name": "omitted line inside a longer mirror line is a parity finding",
            "ok": any(skill_rel in f for f in embedded_findings),
            "detail": f"embedded-row findings: {embedded_findings or 'none'}",
        },
        {
            "name": "a line adapted in one sentence, its others kept, still holds",
            "ok": not partial_findings,
            "detail": f"partial-row findings: {partial_findings or 'none'}",
        },
        {
            "name": "a line back with only a presentation difference is a parity finding",
            "ok": any(skill_rel in f for f in presented_findings),
            "detail": f"presentation-row findings: {presented_findings or 'none'}",
        },
        {
            "name": "a declared link line back as its Project title is a parity finding",
            "ok": any("probe-links.md" in f for f in linked_findings),
            "detail": f"linked-row findings: {linked_findings or 'none'}",
        },
        {
            "name": "a moved token on a declared line routes, an undeclared one still blocks",
            "ok": (
                moved_declared == "routed-to-human"
                and MOVED_PROBE_DECLARED in moved_declared_reason
                and moved_undeclared == "finding"
            ),
            "detail": (
                f"declared: {moved_declared}: {moved_declared_reason}; "
                f"undeclared: {moved_undeclared}: {moved_undeclared_reason}"
            ),
        },
        {
            "name": "a symlinked source's link text is never its own authority",
            "ok": symlink_choices == [] and [kind for _, kind in regular_choices] == ["source"],
            "detail": f"symlink choices: {symlink_choices}; regular-file choices: {regular_choices}",
        },
    ]
    ok = all(probe["ok"] for probe in probes)
    return {
        "label": "adapted pairs: a declared omission routes, an undeclared addition "
                 "or a sentence repeated on an undeclared line blocks, a stale or "
                 "re-entered row is a parity finding",
        "kind": "adapted",
        "exit_code": 0 if ok else 1,
        "probes": probes,
        "ok": ok,
    }


# ───────────────────────────────────────────────────────────────
# 11. UNIT CHECK
# ───────────────────────────────────────────────────────────────

def unit_check_thousands_separator() -> dict:
    """A temp copy where 15.000+ changed to 20.000+ must be reported as a
    moved token, the exact class of change the extended numeric pattern in
    `carrier_query.py` exists to stop letting through unseen.
    """
    temp = Path(tempfile.mkdtemp(prefix="carrier-evidence-unit-"))
    try:
        before_file, after_file = temp / "before.md", temp / "after.md"
        before_file.write_text("Reach 15.000+ creators this quarter.\n", encoding="utf-8")
        after_file.write_text("Reach 20.000+ creators this quarter.\n", encoding="utf-8")
        diff_text = subprocess.run(
            ["git", "diff", "--no-index", "--unified=0", str(before_file), str(after_file)],
            capture_output=True, text=True,
        ).stdout
        paired = cq.pair_tokens(cq.extract_tokens(diff_text, "-"), cq.extract_tokens(diff_text, "+"))
        ok = any(m["before"] == "15.000+" and m["after"] == "20.000+" for m in paired["moved"])
        return {"label": "unit: 15.000+ moving to 20.000+ is reported", "moved": paired["moved"], "ok": ok}
    finally:
        shutil.rmtree(temp, ignore_errors=True)


# ───────────────────────────────────────────────────────────────
# 12. REPORTING AND CLI
# ───────────────────────────────────────────────────────────────

def print_sites(rows: list) -> None:
    for row in rows:
        print(f"      {row['system']} / {row['pair']}")
        print(f"        mirror: {row['mirror']}")
        print(f"        reason: {row['reason']}")


def print_check(index: int, result: dict) -> None:
    exit_code = result.get("exit_code")
    if exit_code is None:
        exit_code = 1 if result.get("blocked") else 0
    if result["kind"] in ("independence", "discovery"):
        exit_code = 0 if result["ok"] else 1
    print(f"[{index}] {result['label']}")
    if "range" in result:
        print(f"    range: {result['range']}")
    if result.get("reconciled"):
        print("    version-suffix filenames read under today's declared name:")
        for note in result["reconciled"]:
            print(f"      {note}")
    if result.get("pairs_postdating_this_commit"):
        print("    declared pairs the replayed commit predates, not held against it:")
        for system_id, pair in result["pairs_postdating_this_commit"]:
            print(f"      {system_id} / {pair}")
    if result["kind"] in ("replay", "current", "mutant"):
        if result.get("reason"):
            print(f"    expectation: {result['reason']}")
        if result.get("flipped_class"):
            print(f"    flipped class: {result['flipped_class']} -> {result.get('flip_to')}")
        if result.get("range_classes"):
            print(f"    range diff classes: {', '.join(result['range_classes'])}")
        if "gained_blocking_mirrors" in result:
            print("    blocking mirrors gained with the flipped class:")
            for mirror in result["gained_blocking_mirrors"]:
                print(f"      {mirror}")
            if not result["gained_blocking_mirrors"]:
                print("      none")
            if result.get("lost_blocking_mirrors"):
                print("    blocking mirrors lost with the flipped class:")
                for mirror in result["lost_blocking_mirrors"]:
                    print(f"      {mirror}")
        if "expected_blocking_sites" in result:
            print("    expected blocking sites:")
            for system, pair, mirror in result["expected_blocking_sites"]:
                print(f"      {system} / {pair} -> {mirror}")
            if result["unexpected_blocking_sites"]:
                print("    unexpected blocking sites:")
                for system, pair, mirror in result["unexpected_blocking_sites"]:
                    print(f"      {system} / {pair} -> {mirror}")
            if result["missing_blocking_sites"]:
                print("    missing blocking sites:")
                for system, pair, mirror in result["missing_blocking_sites"]:
                    print(f"      {system} / {pair} -> {mirror}")
        if "expected_surfaced_sites" in result:
            print(f"    expected surfaced carrier identities: {len(result['expected_surfaced_sites'])}"
                  f"  surfaced: {len(result['sites'])}  match: {result['surfaced_ok']}")
            if result["missing_surfaced_sites"]:
                print("    green control missing surfaced carriers:")
                for system, pair, mirror in result["missing_surfaced_sites"]:
                    print(f"      {system} / {pair} -> {mirror}")
            if result["unexpected_surfaced_sites"]:
                print("    green control surfaced carriers it did not expect:")
                for system, pair, mirror in result["unexpected_surfaced_sites"]:
                    print(f"      {system} / {pair} -> {mirror}")
        if "expected_blocking_mirrors" in result:
            print("    expected own-authority blocking identities:")
            for system, pair, mirror in result["expected_blocking_mirrors"]:
                print(f"      {system} / {pair} -> {mirror}")
            if result["unexpected_blocking_mirrors"]:
                print("    unexpected own-authority blocking identities:")
                for system, pair, mirror in result["unexpected_blocking_mirrors"]:
                    print(f"      {system} / {pair} -> {mirror}")
            if result["missing_blocking_mirrors"]:
                print("    missing own-authority blocking identities:")
                for system, pair, mirror in result["missing_blocking_mirrors"]:
                    print(f"      {system} / {pair} -> {mirror}")
            if result.get("unresolved_expected_pairs"):
                print("    expected identities the declaration no longer resolves:")
                for system, pair, mirror in result["unresolved_expected_pairs"]:
                    print(f"      {system} / {pair} -> {mirror}")
            if result.get("routed_blocking_sites"):
                print("    routed blocking sites (surfaced beside the declared set):")
                print_sites(result["routed_blocking_sites"])
        print(f"    blocked: {result['blocked']}  expect_blocked: {result['expect_blocked']}"
              f"  colour: {'PASS' if result.get('colour_ok', True) else 'FAIL'}  exit: {exit_code}")
        if result.get("blocking_sites"):
            print("    blocking sites (the exit's own reason):")
            print_sites(result["blocking_sites"])
        if result.get("sites"):
            print("    all surfaced sites:")
            print_sites(result["sites"])
        if result.get("live_items"):
            print("    live items (non-blocking):")
            for item in result["live_items"]:
                print(f"      {item['system']} / {item['pair']} -> {item['disposition']}: {item['reason']}")
        if "hubspot_save_defect" in result:
            defect = result["hubspot_save_defect"]
            print("    known live item, HubSpot save defect:")
            if defect.get("present"):
                print(f"      {defect['skill_path']}:{defect['skill_line']}")
                print(f"      {defect['mirror_path']}:{defect['mirror_line']}")
            else:
                print("      not present in this tree")
        if "expired_review_records" in result:
            print("    known live item, expired review records:")
            if result["expired_review_records"]:
                for record in result["expired_review_records"]:
                    print(f"      {record['system']} / {record['pair']}: reviewed at "
                          f"{record['reviewed_commit'][:8]}, source now at {record['latest_commit'][:8]}")
            else:
                print("      none")
    elif result["kind"] == "discovery":
        undeclared = result["undeclared_control"]
        excepted = result["excepted_control"]
        print("    undeclared-file control (must be red):")
        print(f"      {undeclared['probe']}")
        print(f"      found in the unnamed set: {result['undeclared_red']}"
              f"  count: {undeclared['count']}")
        print("    exception-file control (must be green):")
        print(f"      {excepted['probe']}")
        print(f"      absent from the unnamed set: {result['excepted_green']}"
              f"  count: {excepted['count']}")
        print(f"    live tree, reported unchanged: {result['live_count']} unnamed document(s),"
              f" {result['live_exceptions_applied']} exception(s) applied, exit {result['live_exit']}")
    elif result["kind"] == "independence":
        if result["ok"] or "before_key" in result:
            print(f"    probe pair: {result.get('pair')}  mirror: {result.get('mirror')}")
            print(f"    expected value key before mutation: {result.get('before_key')}")
            print(f"    expected value key after mutation:  {result.get('after_key')}")
        else:
            print(f"    reason: {result.get('reason')}")
        print(f"    exit: {exit_code}")
    elif result["kind"] == "adapted":
        for probe in result["probes"]:
            print(f"    {probe['name']}: {'PASS' if probe['ok'] else 'FAIL'}")
            print(f"      {probe['detail']}")
        print(f"    exit: {exit_code}")
    print(f"    seconds: {result.get('seconds', 0.0):.1f}")
    print("    PASS" if result["ok"] else "    FAIL")
    print()


def timed(fn) -> dict:
    """Run one check and attach its wall-clock seconds to the result."""
    start = time.monotonic()
    result = fn()
    result["seconds"] = time.monotonic() - start
    return result


def main() -> int:
    unit = timed(unit_check_thousands_separator)
    print("Unit check")
    print(f"  {unit['label']}: {'PASS' if unit['ok'] else 'FAIL'}")
    print(f"  moved token(s): {unit['moved']}")
    print(f"  seconds: {unit['seconds']:.1f}")
    print()

    checks = []
    for label, rev_range, expect_blocked, reason, expect_blocking, expect_surfaced in REPLAYS:
        checks.append(
            timed(lambda: run_replay(
                label, rev_range, expect_blocked, reason, expect_blocking, expect_surfaced)))
    checks.append(timed(run_current_tree))
    checks.append(timed(run_independence_test))
    checks.append(timed(run_mutant_test))
    checks.append(timed(run_discovery_check))
    checks.append(timed(run_adapted_pairs_check))

    print("Nine checks")
    for index, result in enumerate(checks, start=1):
        print_check(index, result)

    print("Table")
    header = f"{'#':<3}{'check':<60}{'range':<22}{'exit':<6}{'seconds':<10}{'result'}"
    print(header)
    print("-" * len(header))
    for index, result in enumerate(checks, start=1):
        exit_code = result.get("exit_code")
        if exit_code is None:
            exit_code = 1 if result.get("blocked") else 0
        if result["kind"] in ("independence", "discovery"):
            exit_code = 0 if result["ok"] else 1
        verdict = "PASS" if result["ok"] else "FAIL"
        print(f"{index:<3}{result['label']:<60}{result.get('range', ''):<22}"
              f"{exit_code:<6}{result.get('seconds', 0.0):<10.1f}{verdict}")

    all_ok = unit["ok"] and all(result["ok"] for result in checks)
    print()
    print("all checks PASS" if all_ok else "at least one check FAILED")
    return 0 if all_ok else 1


if __name__ == "__main__":
    sys.exit(main())
