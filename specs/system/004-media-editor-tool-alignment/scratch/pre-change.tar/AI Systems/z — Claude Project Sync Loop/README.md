---
title: "Claude Project Sync Loop: shared parity and output format checks"
description: "One folder holding the two check halves of the skill to Claude Project sync loop: the parity gate with its declaration, carrier query, records and episode control plane, and the shared output format validator with its registry, fixtures and reference comparison."
trigger_phrases:
  - "parity gate"
  - "output format gate"
  - "episode control plane"
  - "carrier query"
  - "format validator fixtures"
---

# Claude Project Sync Loop: shared parity and output format checks

---

## 1. OVERVIEW

This folder, `z — Claude Project Sync Loop/`, owns the checks that keep a hand-authored Claude Project package honest against its skill sources and the checks that keep a system's produced output in the house format. The parity half holds the declaration every check reads, the shared gate, the carrier query, the reading records and the episode control plane that runs one unit of sync work in agents outside the live tree. The format half holds the shared validator, the registry that names each covered system, the fixture corpus that pins the validator's mechanics and the comparison that holds the shared core to the reference implementation.

Current state:

- Pairs are declared in `systems.py`, never derived, so a silent non-match cannot pass
- A system that also ships as its own repository carries its shared cards as regular-file copies, which `systems.py` declares as `vendored_shared_copies`. Every check treats a declared copy as it treats a symlink into `z — Knowledge/`, and the gate holds the copy to its card byte for byte
- The parity gate and the residency check refuse a declaration whose working copy differs from its committed revision
- `systems.cjs` names four format systems, `product-owner`, `barter-copywriter`, `barter-deal-templates` and `sales-direct-communication`, and resolves each id to its roots, cards, enforcement set and contracts
- The Human Voice blocker list is read out of the always-loaded card at run time rather than retyped, and a guard fails the run when a blocking term is absent from the always-loaded conciseness layer
- `run_fixtures.sh` runs a system entry script over the shared fixture corpus and asserts each case's exit status, required output and forbidden output
- `reference-parity.cjs` holds the shared core to the reference implementation's exact exit status, stdout and stderr over three cases
- Rule content parity stays a hand-reading task: the gate compares a pair for staleness and `pair_divergence.py` compares matched anchors for wording
- The retired sync compiler never runs, these checks replaced it

---

## 2. ARCHITECTURE

```text
╭───────────────────────────────────────────────────────────────────╮
│                     CLAUDE PROJECT SYNC LOOP                      │
╰───────────────────────────────────────────────────────────────────╯

┌──────────────────┐      ┌──────────────────────┐      ┌──────────────┐
│ Parity wrappers  │ ───▶ │ Shared parity gate   │ ───▶ │ Declaration  │
│ benchmark/parity │      │ validate_parity.py   │      │ systems.py   │
│ benchmark/gates  │      │ write_receipt.py     │      │ read as text │
│                  │      │ write_review.py      │      │              │
└────────┬─────────┘      └──────────┬───────────┘      └──────┬───────┘
         │                           │                         │
         │                           ▼                         │
         │            ┌─────────────────────────┐               │
         │            │ Evidence                │◀──────────────┘
         │            │ skill sources, mirrors, │
         │            │ SYNC.md notes, git      │
         │            └─────────────────────────┘
         ▼
┌──────────────────┐      ┌──────────────────────┐      ┌──────────────┐
│ Orchestrators    │ ───▶ │ Control plane        │ ───▶ │ Worktrees    │
│ agents, people   │      │ episode_control.py   │      │ under /tmp   │
└──────────────────┘      └──────────┬───────────┘      └──────────────┘
                                     │
                                     ▼
                      ┌─────────────────────────┐
                      │ Tracked episode record  │
                      └─────────────────────────┘

┌──────────────────┐      ┌──────────────────────┐      ┌──────────────┐
│ Format entries   │ ───▶ │ Shared validator     │ ───▶ │ Registry     │
│ benchmark/format │      │ validate-output-     │      │ systems.cjs  │
│                  │      │ format.cjs           │      │              │
└──────────────────┘      └──────────┬───────────┘      └──────────────┘
                                     │
                                     ▼
                      ┌─────────────────────────┐
                      │ fixtures/, the source   │
                      │ perimeter, deliverables │
                      └─────────────────────────┘
```

---

## 3. PACKAGE TOPOLOGY

The parity half is self-contained. The format half also reads each covered system's instruction surface and `benchmark/format/` entry scripts outside the folder. The folder's inputs are the declaration, files on disk, git history and its own records.

Allowed dependency direction:

```text
each system's benchmark/parity wrappers → validate_parity.py → systems.py
each system's benchmark/gates tools → systems.py
episode_selftest.py → episode_control.py → systems.py
reading_brief.py → carrier_query.py (loaded from source text)
residency_check.py → validate_parity.py (loaded from source text)
prove_review_expiry.py → validate_parity.py (run as a subprocess)
prove_nested_history.py → validate_parity.py (imported, checks called directly)
prove_kernel_restore.py → validate_parity.py (imported, check called directly)
write_receipt.py → the gate's key helpers and receipt checker
write_review.py → write_receipt.py (append, lock, write) and the gate's review check
prove_kernel_review.py → validate_parity.py (imported) and write_review.py (run as a subprocess)
system entry script → validate-output-format.cjs → systems.cjs
run_fixtures.sh → entry script
reference-parity.cjs → reference validator and shared core
```

Disallowed dependency direction:

```text
any module → cached bytecode of the declaration (it is executed, never imported)
validate_parity.py → generated claude project/ files as sources of truth
validate-output-format.cjs → a system entry script (the entry requires the core, never the reverse)
anything → the retired sync compiler
```

The declaration is never imported. `load_declaration()` reads it as source text and executes it, because an import can answer from bytecode cached by path and by a modification time truncated to the second.

---

## 4. DIRECTORY TREE

```text
z — Claude Project Sync Loop/
+-- validate_parity.py        # The shared parity gate, seven checks plus --receipts and --reviews
+-- systems.py                # The parity declaration, pairs written down rather than derived
+-- episode_control.py        # The four verbs, the differ, worktrees, content keys
+-- episode_selftest.py       # One acceptance test per control-plane mechanism
+-- prove_review_expiry.py    # The green, red, green proof of the recorded review key
+-- prove_nested_history.py   # Proof the history checks read the fleet repo past a nested one
+-- prove_kernel_restore.py   # Proof the kernel-bump check tells a restore from an edit
+-- prove_kernel_review.py    # Proof the review check counts only a current, declared review
+-- write_receipt.py          # Renders and verifies one dated receipt line
+-- write_review.py           # Renders and verifies one dated kernel review line
+-- carrier_query.py          # Which mirrors carry a changed source's rules
+-- carrier_query_evidence.py # Evidence the carrier query catches what it claims
+-- reading_brief.py          # The authorities a change touches and its findings
+-- verdict_store.py          # The recorded reading answers and the unchanged-tuple replay
+-- run_episode.sh            # The reading episode, by range or by replay
+-- residency_check.py        # Section ownership, moved statements, no rule lost
+-- pair_divergence.py        # Where a declared pair states one rule two ways
+-- residency_report.py       # Regenerates the residency record or proves it current
+-- record_claims.py          # The packet record's numbers, recomputed from the tree
+-- run_residency.sh          # Per system wrapper for the residency check
+-- run_packaging.sh          # Runs one packaging in isolation or refuses
+-- check_criteria.sh         # Every completion criterion run as one command
+-- verification_backlog.py   # Open findings read from the records
+-- markdown_read.py          # The fence, table and region rules the record checks share
+-- repoint_rename.py         # Repoints live references across wrapped declaration literals
+-- reference_sites.py        # Lists every site a knowledge document rename must repoint
+-- resync_statement.py       # Rewrites a declared residency statement and recomputes its key
+-- transforms.md             # The six transform classes the carrier query reads
+-- discover_exceptions.md    # The globs that mark a document class as a deliberate exception
+-- runtime-register.md       # One row per claim the fleet makes about the runtime
+-- validate-output-format.cjs # The shared output format validator and CLI entry
+-- systems.cjs               # The format registry, path resolution and policy per system
+-- reference-parity.cjs      # Shared core against the reference validator, three cases
+-- run_fixtures.sh           # Fixture runner for validator mechanics
+-- fixtures/                 # 36 Markdown inputs, violations and near misses
+-- benchmark/                # A recorded manual testing playbook run
+-- episodes/                 # Episode record directory
+-- feature-catalog/          # The feature inventory and current-reality reference
+-- manual-testing-playbook/  # The directory, review protocol and scenario files
+-- reading/                  # The question set, calibration and the verdict record
+-- residency/                # The kernel residency classification and record
`-- README.md
```

---

## 5. KEY FILES

| File | Responsibility |
|---|---|
| `validate_parity.py` | The shared parity gate. Seven exactly decidable checks plus the receipt check behind `--receipts` and the kernel review check behind `--reviews`, with a refusal for a declaration whose working copy differs from its committed revision |
| `systems.py` | The parity declaration. One block per system, pairs written down rather than derived, `unmirrored_sources` the deliberate exception list with the reason beside each entry, `adapted_pairs` the exact source lines a mirror leaves out by decision |
| `episode_control.py` | The control plane. The four verbs, the differ, the content keys and the worktree lifecycle. State files live in `episodes/` beside the declaration |
| `episode_selftest.py` | One acceptance test per entry in `SCENARIOS`, each able to run twice. A clean run exits 0, a caught injection exits 1, a wrongly accepted fault exits 2 |
| `prove_review_expiry.py` | Makes an expired review key fail on demand. Points a green record at a commit its source cannot be at and expects green, red, green |
| `prove_nested_history.py` | Proves the kernel-bump and review-due checks read the fleet repository when a system folder holds a repository of its own, as a public copy does, and ignore an outer repository that tracks nothing |
| `prove_kernel_restore.py` | Proves the kernel-bump check accepts a commit that restores the exact text its unchanged version was introduced with, lets that restore repair the edit it undoes, and still reports a near-copy, a return to a text the version carried after an earlier edit, and an older body under a new H1 |
| `prove_kernel_review.py` | Proves the kernel review check passes only a current review by a declared reviewer, reports an edit made after the review, a wrong version, an undeclared reviewer, a malformed line and a line outside the section, counts the versions a stale review is behind, and runs the writer's append and refusals |
| `write_receipt.py` | Renders the dated receipt line from the live package, verifies it with the gate's own checker and with `--append` adds it to the `SYNC.md` review notes |
| `write_review.py` | Renders the kernel review line for a declared reviewer from the kernel on disk, verifies it with the gate's own review check and with `--append` adds it through the receipt writer's append. Run it only after the named person has confirmed the review |
| `carrier_query.py` | The carrier query. Five indexes, a discovery pass and a walk that dispositions every mirror a commit range's authorities touched, keeping its per-pair state in `episodes/walk-state/` |
| `carrier_query_evidence.py` | The evidence suite. Four archived-tree replays, a current-tree check, two independence tests, a discovery check and an adapted-pairs check |
| `reading_brief.py` | Builds the reading brief for a commit range. Names each authority the range touched and every declared carrier it reaches |
| `verdict_store.py` | The tracked store of reading verdicts, keyed by the content each answer judged. A key that no longer matches expires the answer and returns the question to the queue |
| `run_episode.sh` | The reading episode runner. With `--range` it dispatches the brief as one isolated step and records unanswered questions as defers, with `--replay` it checks every recorded site |
| `residency_check.py` | Residency conformance. Every kernel section is owned by a row, every moved statement is in its declared home and no rule is lost from both places |
| `pair_divergence.py` | Compares matched anchors on the two sides of every declared pair and reports where one rule is stated two ways. The gate compares staleness and never content |
| `residency_report.py` | Regenerates `residency/counts.md` and `residency/backlog.md` from the declaration and without `--write` proves the record still matches it. Live kernel word counts are printed on every run and never part of the record |
| `record_claims.py` | Recomputes the packet record's counted claims from the declaration and from git. Every claim that disagrees is named |
| `run_residency.sh` | The invocation wrapper for `residency_check.py` |
| `run_packaging.sh` | Runs one packaging of one system in a scratch tree, asserts the isolation before any model is called and appends the retrieval line the Project side needs in a terminal |
| `check_criteria.sh` | Runs every completion criterion as one command and prints a row per criterion with the exit code behind it |
| `verification_backlog.py` | Reads every verification record's newest round and reports findings open at first priority, from the recap table and from the prose sections |
| `markdown_read.py` | The fence, table and region rules the record checks share, so one document parses one way |
| `repoint_rename.py` | Repoints every live reference from one document version to another, including the sites the declaration wraps across adjacent string literals |
| `reference_sites.py` | Walks the tree and lists every site that must be repointed when a knowledge document is renamed |
| `resync_statement.py` | Rewrites a declared residency statement after an intentional rule edit and recomputes its recorded key |
| `transforms.md` | The six transform classes the carrier query reads, with each row's confirmation status |
| `discover_exceptions.md` | The globs `discover` reads on every pass, each marking a document class as a deliberate exception |
| `runtime-register.md` | One row per claim the fleet makes about the Claude Project runtime, graded and dated |
| `validate-output-format.cjs` | Selects source or artifact mode for one registered system, masks non-prose spans, runs the artifact, punctuation, vocabulary, conciseness and prose-floor checks, and sets the exit status |
| `systems.cjs` | Names each format system's directory, skill directory, cards, statistics variable, enforcement set and phrase contracts, and resolves an id to absolute paths |
| `reference-parity.cjs` | Runs three cases through the reference validator and the shared core, compares exit status, standard output and standard error, and fails on any difference |
| `run_fixtures.sh` | Runs a system entry script over the fixture corpus and asserts exit status, required output and forbidden output for each case |
| `fixtures/` | 36 Markdown inputs, each a violation that must fire or a near miss that must stay silent |

---

## 6. BOUNDARIES AND FLOW

| Boundary | Rule |
|---|---|
| Imports | Python standard library, git and Node built-ins. No third-party code, no import from other fleet folders |
| Declaration | `systems.py` is read as source text and executed, never imported, so no stale bytecode cache can answer |
| Refusals | The parity gate and the residency check refuse a declaration whose working copy differs from its committed revision. A check that could not run reports that rather than a pass |
| Entrypoints | No importable API on the parity side, every entrypoint is a script run from the repository root |
| Exports | `validate-output-format.cjs` exports `main`, `sourcePerimeter` and `markdownFiles` for entry scripts to call. `systems.cjs` exports `SYSTEMS`, `resolve` and `ids` |
| Ownership | This folder owns the checks, the declaration, the format registry, the receipt writer, the episode control plane, the fixture corpus and the records. A `SYNC.md` owns its review notes. A generated `claude project/` package is evidence, never authority |
| Targets | Source mode lints the selected system's own instruction surface. Artifact mode lints only the explicit path arguments, which must be regular files |
| Formatting | `--write` rewrites the source perimeter in place, removing the divider after a Mark-as-done checkbox and, for a blocking system, the trailing full stop on bullet items. It is rejected together with explicit path arguments |
| Statistics | Setting the system's statistics variable to `1` prints the per-file statistics block after the run |

Main flow:

```text
╭──────────────────────────────────────────╮
│ Orchestrator                             │
╰──────────────────────────────────────────╯
                  │
                  ▼
┌──────────────────────────────────────────┐
│ open        pin declaration, range, tree │
└──────────────────────────────────────────┘
                  │
                  ▼
┌──────────────────────────────────────────┐
│ dispatch    worktree, runners, differ    │
└──────────────────────────────────────────┘
                  │
                  ▼
┌──────────────────────────────────────────┐
│ adjudicate  operator decides the split   │
└──────────────────────────────────────────┘
                  │
                  ▼
┌──────────────────────────────────────────┐
│ close       carriers checked, trees gone │
└──────────────────────────────────────────┘
```

Format flow:

```text
╭──────────────────────────────────────────╮
│ system id and optional file targets      │
╰──────────────────────────────────────────╯
                  │
                  ▼
┌──────────────────────────────────────────┐
│ resolve the system and its policy        │
└──────────────────────────────────────────┘
                  │
                  ▼
┌──────────────────────────────────────────┐
│ select source perimeter or artifacts     │
└──────────────────────────────────────────┘
                  │
                  ▼
┌──────────────────────────────────────────┐
│ analyse each file                        │
│ mask, then run the rule passes           │
└──────────────────────────────────────────┘
                  │
                  ▼
╭──────────────────────────────────────────╮
│ advisories, statistics, errors, status   │
╰──────────────────────────────────────────╯
```

---

## 7. ENTRYPOINTS

No importable API on the parity side. Every parity entrypoint is a script in this folder, run from the repository root when it is given with the folder path, which is how the per-system wrappers call them. Each system directory carries `benchmark/parity/` wrappers that call the shared gate with that system's id, for example `run_parity.sh`.

| Entrypoint | Type | Purpose |
|---|---|---|
| `python3 validate_parity.py <system-id> [--range BASE..HEAD] [--receipts] [--reviews]` | CLI | Runs the shared parity gate for one system |
| `python3 carrier_query.py index <bindings\|pointers\|fanout\|duplicates\|tokens> [--range BASE..HEAD]` | CLI | Prints one declared index as JSON |
| `python3 carrier_query.py walk --range BASE..HEAD` | CLI | Dispositions every mirror the range's authorities touched |
| `python3 carrier_query.py discover` | CLI | Reports markdown documents the declaration does not name |
| `python3 episode_control.py <open\|dispatch\|adjudicate\|close>` | CLI | Drives one episode through its four verbs |
| `python3 reading_brief.py --range BASE..HEAD` | CLI | Builds the reading brief for a range |
| `bash run_episode.sh --range BASE..HEAD` | CLI | Opens a reading episode and records its unanswered questions |
| `bash run_episode.sh --replay` | CLI | Checks every recorded site against the scope the brief generates |
| `python3 residency_check.py --all` | CLI | Runs the residency check over every declared system |
| `python3 pair_divergence.py --all` | CLI | Compares every declared pair for rule divergence |
| `python3 prove_review_expiry.py` | CLI | Runs the green, red, green proof of the review key |
| `python3 prove_nested_history.py` | CLI | Runs the nested-repository proof of the two history checks |
| `python3 prove_kernel_restore.py` | CLI | Runs the restore proof of the kernel-bump check |
| `python3 prove_kernel_review.py` | CLI | Runs the proof of the kernel review check and its writer |
| `python3 record_claims.py` | CLI | Checks the packet record's counted claims |
| `python3 verification_backlog.py [--quiet]` | CLI | Reports findings open at first priority |
| `python3 residency_report.py [--write]` | CLI | Proves the residency record current or rewrites it |
| `python3 write_receipt.py <system dir> [--append]` | CLI | Renders the receipt line and verifies it with the gate's checker |
| `python3 write_review.py <system dir> --reviewer NAME [--note TEXT] [--append]` | CLI | Renders the kernel review line and verifies it with the gate's review check |
| `python3 episode_selftest.py [--inject NAME]` | CLI | Runs one acceptance test per mechanism |
| `python3 carrier_query_evidence.py` | CLI | Runs the nine evidence checks |
| `bash run_packaging.sh <system dir> <skill\|project> <prompt>` | CLI | Runs one packaging in isolation |
| `bash check_criteria.sh` | CLI | Runs every completion criterion as one command |
| `validate-output-format.cjs --system <id>` | CLI | Lints the selected system's own source perimeter |
| `validate-output-format.cjs --system <id> <file>` | CLI | Lints explicit files as deliverables |
| `validate-output-format.cjs --system <id> --write` | CLI | Rewrites the source perimeter with the safe formatting fixes |
| `main(systemId, argv)` | Function | Runs one system's format validation and sets the process exit status |
| `sourcePerimeter(system)` | Function | Builds the source file list for a resolved system, leaving out the copies its entry declares as `vendoredShared` |
| `markdownFiles(directory)` | Function | Lists non-symlink Markdown files under a directory |
| `resolve(id)`, `ids()` | Functions | Resolves one configured format system, or lists the configured ids |
| `run_fixtures.sh <entry> <blocking\|advisory> [dir]` | Shell CLI | Runs the fixture corpus through an entry script |
| `reference-parity.cjs` | Node CLI | Compares the shared core with the reference validator |

Exit statuses for the parity checks are 0 for a pass, 1 for a finding and 2 for a refusal that ran nothing. The format validator exits 0 for a pass, 1 for findings, 64 for a usage error and 66 for a target that is missing or not a regular file.

---

## 8. VALIDATION

Run from the repository root unless noted.

```bash
python3 "AI Systems/z — Claude Project Sync Loop/carrier_query_evidence.py"
```

Expected result: exit 0 and `all checks PASS` at the end.

```bash
python3 "AI Systems/z — Claude Project Sync Loop/residency_check.py" --all
```

Expected result: exit 0 with `PASSED 8 system(s), every declared statement owned and placed`. While `systems.py` differs from its committed revision this refuses with exit 2, because the gate will not judge a declaration version control does not record.

```bash
python3 .opencode/skills/sk-code/sk-code-opencode/assets/scripts/verify_alignment_drift.py --root "AI Systems/z — Claude Project Sync Loop" --check-exact-headers --fail-on-warn
```

Expected result: no finding names a file directly in this folder.

```bash
node "AI Systems/z — Claude Project Sync Loop/validate-output-format.cjs" --system product-owner
```

Expected result: exit status 0 and a pass line naming the system and the number of source files.

```bash
node "AI Systems/z — Claude Project Sync Loop/validate-output-format.cjs" --system product-owner "AI Systems/z — Claude Project Sync Loop/fixtures/punctuation-violation.md"
```

Expected result: exit status 1 with one prose semicolon finding and two curly quote findings.

```bash
node "AI Systems/z — Claude Project Sync Loop/reference-parity.cjs"
```

Expected result: three `identical:` lines and `shared core is byte-identical to the reference implementation`, exit status 0. That closing line is the script's own wording and overstates what it measured, since the run compares exit status, stdout and stderr rather than source bytes.

```bash
bash "AI Systems/z — Claude Project Sync Loop/run_fixtures.sh" "AI Systems/Barter - Copywriter/benchmark/format/validate-output-format.cjs" advisory "AI Systems/Barter - Copywriter/benchmark/format/fixtures"
```

Expected result: `PASSED all format-validator fixtures`, exit status 0. The entry script resolves its own system, so the shared core cannot serve as the entry. Called directly it requires `--system` and exits 64 on the runner's fixture arguments.

```bash
bash "AI Systems/z — Claude Project Sync Loop/check_criteria.sh"
```

Expected result: one row per criterion, `ok` in each row, with a final line `every criterion check passed`.

```bash
find "AI Systems/z — Claude Project Sync Loop" -maxdepth 1 -type f -name '*.py' -exec python3 -m py_compile {} +
find "AI Systems/z — Claude Project Sync Loop" -maxdepth 1 -type f -name '*.sh' -exec bash -n {} +
find "AI Systems/z — Claude Project Sync Loop" -maxdepth 1 -type f -name '*.cjs' -exec node --check {} +
find "AI Systems/z — Claude Project Sync Loop" -maxdepth 1 -type f -name '*.sh' -exec shellcheck {} +
```

Expected result: exit 0 from the first three. ShellCheck reads the five scripts and reports the SC2164 warning on the `cd` line in `check_criteria.sh`, `run_episode.sh` and `run_residency.sh`, the SC2012 notes on the three `ls` counts and the SC2126 note on the `grep` count in `check_criteria.sh`, the SC2046 warning on the closing `exit` line of `check_criteria.sh`, and the four SC2001 style notes on the `sed` indentation pipes in `run_fixtures.sh`. The SC2164, SC2012, SC2126 and SC2046 findings stay in place because the scripts run without `set -e` and tolerate a non-zero probe on purpose. The SC2001 notes stay because the `${variable//search/replace}` substitution the check suggests would leave the first report line unindented, so the `sed` pipe is kept as the form that indents every line.

---

## 9. RELATED

- [`AGENTS.md`](../../AGENTS.md), the repository behavior contract
- [`ARCHITECTURE.md`](../../ARCHITECTURE.md)
- [`episodes/README.md`](episodes/README.md), the episode contract
- [`SYNC.md`](<../Barter - Blog Posts/SYNC.md>), one system's sync notes, stating the four parity rules
- [Product Owner reference validator](<../Product Owner/benchmark/format/validate-output-format.cjs>), the standalone implementation `reference-parity.cjs` compares against
