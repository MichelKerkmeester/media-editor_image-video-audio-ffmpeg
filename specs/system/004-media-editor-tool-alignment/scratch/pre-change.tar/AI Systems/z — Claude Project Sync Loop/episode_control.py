#!/usr/bin/env python3
# ───────────────────────────────────────────────────────────────
# COMPONENT: EPISODE CONTROL PLANE
# ───────────────────────────────────────────────────────────────
"""The episode control plane for agent steps that run outside the live tree.

An episode is one unit of work whose steps are dispatched to agents that are not
trusted. The orchestrator drives it through four verbs and nothing else.

    open        pin the input tuple: declaration revision, commit range, tree state
    dispatch    run one step in a worktree from the pinned commit, then run the differ
    adjudicate  record the operator's decision on a two-family disagreement
    close       check every carrier has a disposition, then remove the worktrees

The differ refuses a step that writes outside its worktree or touches a path it
did not declare. Every runner for a step runs before that comparison, so a
second family cannot move a path after the differ has passed. A refusal discards
the worktree in a finally block, so a crash cannot leave it registered. A
two-family disagreement stops the episode until an operator decides, and the
decision is keyed to the content the two families disagreed on. Every step
record carries a content key, and close recomputes all of them, so a record
whose content changed is void whatever its verdict. An empty agent output is a
failure, never a pass, because one family in the fleet fails silently on long
briefs.

State files live in `episodes/` beside the declaration and are ordinary tracked
JSON. Worktrees are created under the system temporary directory and removed by
close, or immediately when a step is refused.

Every verb holds an exclusive lock on the episode it touches, so two verbs
cannot load, change and write one record at once. Runner output is kept to one
mebibyte per stream, and a subprocess runner is killed and refused when it
reaches the runner deadline. A callable runner is unbounded, because it runs
inside this process where the control plane cannot interrupt it.

The control plane polices persistent writes inside the repository and the state
directory by an agent that writes where it should not, by mistake or by ignoring
its brief. A process that deliberately subverts the harness as the same user, by
rewriting and restoring a record inside one dispatch, by writing outside both
trees, or by re-signing a record between verbs, is outside what a userland check
can refuse and needs operating-system isolation. That is the stated boundary,
and every check here is read against it. A process that detaches from the
control plane's process tree escapes the sweep, and that is within the stated
boundary.
"""

# ───────────────────────────────────────────────────────────────
# 1. IMPORTS AND CONSTANTS
# ───────────────────────────────────────────────────────────────

from __future__ import annotations

import argparse
import codecs
import fcntl
import functools
import hashlib
import json
import os
import posixpath
import re
import shutil
import signal
import stat
import subprocess
import sys
import tempfile
import threading
import time
from datetime import datetime, timezone
from pathlib import Path

# The declaration and any state read from it are compiled from source text with
# bytecode disabled, for the same reason the shared gate does it: the interpreter
# can otherwise answer an import from a cache keyed by path and second outside
# the source tree, which makes an edit invisible.
sys.dont_write_bytecode = True

HERE = Path(__file__).resolve().parent
# HERE is the gate directory, so the repository root is two levels up rather
# than the systems root the shared gate calls its declaration parent.
DEFAULT_REPO = HERE.parent.parent
# The state directory holds nothing but records, because close refuses any
# other entry, and the tracked parent directory needs a README and room for
# history beside the records.
DEFAULT_STATE_DIR = HERE / "episodes" / "state"
DECLARATION = HERE / "systems.py"
STATE_SUFFIX = ".json"
# One mebibyte of each runner stream is kept. The head is kept whole, and the
# full text is named by its hash and byte length, so a runner that floods its
# streams cannot grow an episode record without bound.
RUNNER_OUTPUT_LIMIT = 1_048_576
# Every file hash reads in chunks of this size, so no walk holds a whole file.
HASH_CHUNK = 1_048_576
# A state record read whole into memory is capped at this size, so a very
# large file planted in the state directory is refused rather than held.
STATE_READ_LIMIT = 64 * 1024 * 1024
# One git stream is bounded at this many bytes. `git show` reads a blob of
# any size, so stdout and stderr are read while the child runs, and a stream
# past this limit kills the child and refuses the command with the limit
# named, rather than growing this process without bound.
GIT_OUTPUT_LIMIT = 64 * 1024 * 1024
# Every state record has to carry these fields with the type each consumer
# reads them as, so a record rekeyed by hand is refused before a verb reads a
# field it does not hold. The id is checked against the requested episode as
# well, so a record cannot be written back to another episode's path.
STATE_REQUIRED_FIELDS = (
    ("id", str),
    ("state_identity", list),
    ("state_root_mode", str),
    ("declaration", dict),
    ("commit_range", dict),
    ("live_head", (str, type(None))),
    ("tree_state", dict),
    ("authorities", list),
    ("authority_keys", dict),
    ("joins", list),
    ("steps", list),
    ("closed_at", (str, type(None))),
    ("closed_by", (str, type(None))),
)
# A runner that ignores its deadline can leave a pipe end open. This bounds how
# long the control plane waits for its reader threads after the process group
# is killed.
STREAM_READ_GRACE = 10
# A fingerprint walk refuses a tree deeper than this many directories below its
# root, so a deliberately deep tree cannot make the walk run without bound.
FINGERPRINT_DEPTH_LIMIT = 64
# One walk refuses past this many entries or this many hashed bytes, so a tree
# larger than the walk is allowed to read cannot make a verb run without bound.
FINGERPRINT_ENTRY_LIMIT = 200_000
FINGERPRINT_BYTE_LIMIT = 8 * 1024 * 1024 * 1024
# A link target larger than this is refused by the walk, because the target's
# size and modification time are not evidence of the bytes it leads to.
SYMLINK_TARGET_LIMIT = 256 * 1024 * 1024


# ───────────────────────────────────────────────────────────────
# 2. REFUSALS AND HASHES
# ───────────────────────────────────────────────────────────────

class EpisodeRefused(Exception):
    """A verb refused to proceed. `reason` is the durable finding."""

    def __init__(self, reason: str, evidence=None):
        super().__init__(reason)
        self.reason = reason
        self.evidence = evidence or {}


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).strftime("%Y-%m-%dT%H:%M:%SZ")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    """Hash one file by streaming it, never holding the whole file in memory.

    A tree can hold a file larger than the control plane's memory, so every
    file hash in a fingerprint walk reads fixed chunks and keeps only the
    digest. The path is read as a regular file from the caller's view.
    """
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        while True:
            chunk = handle.read(HASH_CHUNK)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


# ───────────────────────────────────────────────────────────────
# 3. BOUNDED OUTPUT AND CONTENT KEYS
# ───────────────────────────────────────────────────────────────

def bounded_output(head: bytes, digest: str, length: int, has_content: bool) -> dict:
    """One runner stream, keyed by the digest and length of the whole stream.

    The kept head is the first mebibyte of the stream, so a runner that floods
    a stream cannot grow the record or this process without bound. The digest
    and the length describe the whole stream, so a reader can see that the kept
    head is a truncation and can key the full output without holding it. The
    has_content flag is computed before the head is cut, so a stream whose
    first mebibyte is whitespace but which carries real content later is not
    mistaken for an empty one.
    """
    return {
        # A cut can land inside a character, so the tail byte is replaced
        # rather than kept as a fragment that no reader could decode.
        "text": bytes(head).decode("utf-8", "replace"),
        "sha256": digest,
        "bytes": length,
        "truncated": length > RUNNER_OUTPUT_LIMIT,
        "has_content": has_content,
    }


def bounded_text(text: str) -> dict:
    """The bounded form of a whole text the control plane already holds."""
    payload = text.encode("utf-8", "surrogateescape")
    return bounded_output(payload[:RUNNER_OUTPUT_LIMIT], sha256_bytes(payload), len(payload),
                          bool(text.strip()))


class _StreamReader(threading.Thread):
    """Read one subprocess stream in chunks, keeping only a bounded head.

    Every chunk is hashed, so the digest covers the whole stream even though
    only the first mebibyte is kept. The reader records whether any
    non-whitespace text arrived, whether before or after the head was cut,
    because the empty-output rule has to answer for the whole stream rather
    than the head. The answer goes through an incremental decoder, because a
    character whose bytes span two reads is one character and not the lone
    surrogate a single read would make of it. A reader is a daemon thread, so
    a stream that never ends cannot keep the control plane alive.
    """

    def __init__(self, stream):
        super().__init__(daemon=True)
        self._stream = stream
        self._lock = threading.Lock()
        self._digest = hashlib.sha256()
        self._head = bytearray()
        self._length = 0
        self._has_content = False
        # Carries the decoded text whose emptiness is not yet answered, so the
        # flag can wait for the whole stream without holding the whole stream.
        self._pending = ""
        self._decoder = codecs.getincrementaldecoder("utf-8")(errors="surrogateescape")
        self._error = None

    def run(self):
        try:
            while True:
                chunk = self._stream.read(HASH_CHUNK)
                if not chunk:
                    break
                with self._lock:
                    self._digest.update(chunk)
                    self._length += len(chunk)
                    room = RUNNER_OUTPUT_LIMIT - len(self._head)
                    if room > 0:
                        self._head.extend(chunk[:room])
                    if not self._has_content:
                        self._note_text(self._decoder.decode(chunk))
            # The stream is whole. Whatever the decoder still held, including
            # any final part character, answers the question now.
            if not self._has_content:
                with self._lock:
                    self._note_text(self._decoder.decode(b"", True))
        except OSError as exc:
            # A read that failed is not a short answer. The failure is kept
            # until the caller turns the stream into a refused step, so a
            # partial stream with a zero exit status cannot pass as a whole
            # one.
            with self._lock:
                self._error = exc
        except ValueError:
            # A stream closed from under a blocked read is the bounded escape
            # after the deadline, not a new failure.
            pass
        finally:
            self.close_stream()

    def read_error(self):
        with self._lock:
            return self._error

    def close_stream(self):
        try:
            self._stream.close()
        except OSError:
            pass

    def _note_text(self, text):
        """Fold one piece of decoded stream into the question still unanswered.

        Called with the reader lock held. The decoder returns whole
        characters, so a character whose bytes span two reads answers once, as
        itself, instead of as the lone surrogates one read decoded alone would
        have made of it. A lone surrogate is not whitespace, which is how a
        stream of nothing but whitespace once answered as content.
        """
        if self._has_content:
            return
        self._pending = (self._pending + text).strip()
        if self._pending:
            self._has_content = True
            self._pending = ""

    def snapshot(self) -> dict:
        with self._lock:
            return bounded_output(bytes(self._head), self._digest.hexdigest(), self._length,
                                  self._has_content)


def canonical_bytes(value) -> bytes:
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


def content_key(value) -> str:
    """The key of content judged, never of a timestamp.

    Any reader can recompute this from the content alone, which is what makes a
    carried key a check rather than a claim.
    """
    return sha256_bytes(canonical_bytes(value))


def record_root_key(record) -> str:
    """The key of the whole record, with any carried root key removed first."""
    copy = dict(record)
    copy.pop("root_key", None)
    return content_key(copy)


def record_content(entry) -> dict:
    """Everything one step record judged, apart from passages that change later.

    Close recomputes the key over these fields for every record, whatever its
    verdict, so no record kind is exempt from the key check. Worktree paths and
    timestamps are left out because the control plane changes them after the
    verdict was recorded and they are not content the step produced. The two
    output passages are included only when the entry carries them, so a record
    written before those fields existed recomputes to the key shape it was
    written with.
    """
    content = {
        "declared": entry.get("declared"),
        "permitted": entry.get("permitted"),
        "actual": entry.get("actual"),
        "undeclared": entry.get("undeclared"),
        "leaked": entry.get("leaked"),
        "output_sha256": entry.get("output_sha256"),
        "families": entry.get("families") or [],
        "verdict": entry.get("verdict"),
        "reason": entry.get("reason"),
    }
    for field in ("stdout", "stderr"):
        if field in entry:
            content[field] = entry.get(field)
    return content


# ───────────────────────────────────────────────────────────────
# 4. GIT ACCESS
# ───────────────────────────────────────────────────────────────

def git(repo: Path, *args: str) -> subprocess.CompletedProcess:
    """Run one git command with both streams held to a limit while it runs.

    Git is not trusted to answer with a small stream, because `git show`
    reads a blob of any size. Both pipes are read in chunks as they arrive,
    and a stream past the limit kills the child and refuses the command with
    the command and the limit named. The process object keeps the same
    stdout, stderr and returncode every caller already reads.
    """
    command = ["git", *args]
    proc = subprocess.Popen(command, cwd=str(repo), stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE)
    overflow = threading.Event()
    collected = {}
    failures = {}

    def collect(name, stream):
        kept = bytearray()
        try:
            while True:
                chunk = stream.read(HASH_CHUNK)
                if not chunk:
                    break
                kept.extend(chunk)
                if len(kept) > GIT_OUTPUT_LIMIT:
                    overflow.set()
                    proc.kill()
                    break
        except OSError as exc:
            # A read that failed is not a short answer. The failure is held
            # until the readers stop, and the caller refuses the command, so
            # an empty or partial stream cannot pass as what the command said.
            # A read stopped by the overflow kill is not recorded here because
            # the overflow refusal above already carries that outcome. The
            # child is killed here, because the caller waits on it before it
            # reads this state and a live child would leave that wait
            # unbounded.
            failures[name] = exc
            try:
                proc.kill()
            except ProcessLookupError:
                pass
        finally:
            stream.close()
            collected[name] = bytes(kept)

    readers = [threading.Thread(target=collect, args=(name, stream), daemon=True)
               for name, stream in (("stdout", proc.stdout), ("stderr", proc.stderr))]
    for reader in readers:
        reader.start()
    proc.wait()
    for reader in readers:
        reader.join()
    if overflow.is_set():
        raise EpisodeRefused(
            f"the git command {' '.join(command)} passed the {GIT_OUTPUT_LIMIT} byte "
            f"stream limit",
            {"command": command, "limit": GIT_OUTPUT_LIMIT},
        )
    if failures:
        name = sorted(failures)[0]
        exc = failures[name]
        raise EpisodeRefused(
            f"the {name} read of the git command {' '.join(command)} failed",
            {"command": command, "stream": name, "error": str(exc)},
        )
    return subprocess.CompletedProcess(command, proc.returncode,
                                       collected.get("stdout", b""),
                                       collected.get("stderr", b""))


def git_text(repo: Path, *args: str, required: bool = True) -> str:
    proc = git(repo, *args)
    text = proc.stdout.decode("utf-8", "surrogateescape")
    if required and proc.returncode != 0:
        raise EpisodeRefused(
            "git refused a command the control plane needs",
            {
                "args": list(args),
                "stderr": proc.stderr.decode("utf-8", "surrogateescape").strip(),
            },
        )
    return text.strip()


def git_bytes(repo: Path, *args: str) -> bytes:
    """The raw bytes of a read-only git command, for content the pin hashes."""
    proc = git(repo, *args)
    if proc.returncode != 0:
        raise EpisodeRefused(
            "git refused a command the control plane needs",
            {
                "args": list(args),
                "stderr": proc.stderr.decode("utf-8", "surrogateescape").strip(),
            },
        )
    return proc.stdout


def normalise_path(value: str, repo: Path) -> str:
    """One repo-relative form for every declared path."""
    text = str(value).replace("\\", "/")
    candidate = Path(text)
    if candidate.is_absolute():
        try:
            # Resolution answers containment only. The step's change lands at
            # the spelling's own path, so a declaration that names a link
            # keeps the link's own path instead of the target the resolution
            # finds, because the worktree walk keys the change at the link.
            resolved = candidate.resolve()
            resolved.relative_to(repo.resolve())
        except ValueError:
            raise EpisodeRefused(f"the declared path {text} is outside the repository")
        try:
            return Path(posixpath.normpath(text)).relative_to(repo).as_posix()
        except ValueError:
            # The spelling named the repository through another mount spelling,
            # so the lexical form cannot be stripped here, and the resolved
            # form names the same place.
            return resolved.relative_to(repo.resolve()).as_posix()
    normalised = posixpath.normpath(text)
    if normalised in ("..", "") or normalised.startswith("../"):
        raise EpisodeRefused(f"the declared path {text} escapes the repository")
    return normalised


def _inside(path: str, prefixes) -> bool:
    for prefix in prefixes:
        trimmed = prefix.rstrip("/")
        if path == trimmed or path.startswith(trimmed + "/"):
            return True
    return False


def _object_state(path: Path) -> str:
    """Which kind of object sits at a path: file, symlink, missing or not-a-file."""
    if path.is_symlink():
        return "symlink"
    if not path.exists():
        return "missing"
    if path.is_file():
        return "file"
    return "not-a-file"


def _authority_state(path: Path):
    """The object state of one authority, with link identity for a symlink.

    A symlink is keyed by the bytes of the file it resolves to, so retargeting
    it at a different file that holds the same bytes would leave the key
    still. The link text and the resolved target path are carried in the
    state a join compares, so that retarget still appends a join.
    """
    state = _object_state(path)
    if state != "symlink":
        return state
    return {
        "kind": "symlink",
        "link": os.readlink(path),
        "target": os.path.realpath(path),
    }


# ───────────────────────────────────────────────────────────────
# 5. FILESYSTEM FINGERPRINTS
# ───────────────────────────────────────────────────────────────

class _WalkBudget:
    """The aggregate limits one filesystem walk may spend.

    Entries and hashed bytes are counted as the walk goes, so a tree larger
    than the walk is allowed to read is refused rather than walked without
    bound. The counters travel with any directory the walk enters through a
    link, so the budget covers the whole walk and not one directory.
    """

    def __init__(self):
        self.entries = 0
        self.bytes = 0

    def spend_entry(self):
        self.entries += 1
        if self.entries > FINGERPRINT_ENTRY_LIMIT:
            raise EpisodeRefused(
                f"the filesystem walk passed its {FINGERPRINT_ENTRY_LIMIT} entry budget",
                {"entries": self.entries, "limit": FINGERPRINT_ENTRY_LIMIT},
            )

    def spend_bytes(self, amount: int):
        self.bytes += amount
        if self.bytes > FINGERPRINT_BYTE_LIMIT:
            raise EpisodeRefused(
                f"the filesystem walk passed its {FINGERPRINT_BYTE_LIMIT} byte budget "
                f"(8 gibibytes)",
                {"bytes": self.bytes, "limit": FINGERPRINT_BYTE_LIMIT},
            )


def symlink_fingerprint(path: Path, relative: str, _seen=None, _budget=None, _depth=0) -> dict:
    """One symlink, keyed by link text, target location and target bytes.

    A write through a link lands in the target, so a link keyed by its text
    alone would stay still while the bytes it points at changed elsewhere. The
    resolved target path is part of the key, and when that target is a regular
    file its bytes are hashed too, with the target's own mode and modification
    time riding in that key, because the target can sit outside the walked
    tree where no other entry of the fingerprint records them. A write through
    a link that points outside
    the walked tree therefore still moves the fingerprint, and a directory
    target is walked and hashed as well, on the same budget as the walk that
    found the link. A directory target that is already on the walk path, or
    that is the walk root or an ancestor of it, is keyed as a loop instead of
    walked, so a link cycle cannot spin the walk. A target larger than the
    link target limit is refused rather than keyed by its size and time,
    because metadata is not evidence of content. A target that is not there
    is keyed as absent by a word no content digest can equal, so a dangling
    link is recorded rather than refused and creating the target later moves
    the key from absent to present. The depth the target enters
    the walk at rides with the record, so a chain of linked directories spends
    the same depth budget as a nested tree and reaches the walk's depth
    refusal instead of the interpreter's recursion limit.
    """
    if _budget is None:
        _budget = _WalkBudget()
    try:
        link_stat = os.lstat(path)
    except OSError as exc:
        raise EpisodeRefused(
            "the filesystem walk could not stat a symlink it needs",
            {"link": str(path), "error": str(exc)},
        )
    text = os.readlink(path)
    payload = text.encode("utf-8", "surrogateescape")
    target = Path(os.path.realpath(path))
    target_key = None
    try:
        target_stat = os.lstat(target)
    except FileNotFoundError:
        # The link names a path that is not there. That absence is a fact the
        # walk can see, so it is recorded rather than refused: the key is a
        # word no content digest can equal, and creating the target later
        # moves the key from absent to the bytes that arrived. Any other
        # stat failure still means the walk could not see something that is
        # there, so it still refuses with the path and the reason.
        target_stat = None
    except OSError as exc:
        raise EpisodeRefused(
            "the filesystem walk could not stat a symlink target it needs",
            {"link": str(path), "target": str(target), "error": str(exc)},
        )
    if target_stat is None:
        target_key = "absent"
    elif stat.S_ISREG(target_stat.st_mode):
        if target_stat.st_size > SYMLINK_TARGET_LIMIT:
            raise EpisodeRefused(
                "a symlink target is larger than the link target limit, so the walk refuses "
                "rather than keying its size and modification time as content",
                {"link": str(path), "target": str(target), "bytes": target_stat.st_size,
                 "limit": SYMLINK_TARGET_LIMIT},
            )
        _budget.spend_bytes(target_stat.st_size)
        try:
            digest = sha256_file(target)
        except OSError as exc:
            raise EpisodeRefused(
                "the filesystem walk could not read a symlink target it needs",
                {"link": str(path), "target": str(target), "error": str(exc)},
            )
        # The target can sit outside the walked tree, where no other entry of
        # this fingerprint records its mode or its modification time, so a
        # write through the link that moved only metadata would leave the key
        # still. Both ride in the key beside the bytes.
        target_key = sha256_bytes(canonical_bytes({
            "sha256": digest,
            "mode": oct(target_stat.st_mode & 0o7777),
            "mtime_ns": target_stat.st_mtime_ns,
        }))
    elif stat.S_ISDIR(target_stat.st_mode):
        seen = _seen if _seen is not None else set()
        target_text = str(target)
        if target_text in seen or any(
            item == target_text or item.startswith(target_text.rstrip("/") + "/")
            for item in seen
        ):
            target_key = "loop"
        else:
            seen.add(target_text)
            target_key = filesystem_fingerprint(target, skip_git_metadata=False, _seen=seen,
                                                _budget=_budget, _depth=_depth)["key"]
    elif stat.S_ISLNK(target_stat.st_mode):
        # The target resolved to another link only when its chain is a cycle
        # this call cannot follow, so it is keyed the same way as a directory
        # target that is already on the walk path.
        target_key = "loop"
    else:
        target_key = "special:" + oct(target_stat.st_mode)
    identity = {
        "link_sha256": sha256_bytes(payload),
        "target": str(target),
        "target_sha256": target_key,
    }
    return {
        "path": relative,
        "kind": "symlink",
        "sha256": sha256_bytes(canonical_bytes(identity)),
        "link": text,
        "target": str(target),
        "target_sha256": target_key,
        "bytes": len(payload),
        "mtime_ns": link_stat.st_mtime_ns,
    }


def descendants(pid) -> set:
    """Every transitive child of pid, read from a single ps snapshot.

    The ps helper is itself a direct child while its snapshot is taken, so its
    own pid is left out.
    """
    helper = subprocess.Popen(["ps", "-A", "-o", "pid=,ppid="],
                              stdout=subprocess.PIPE, text=True)
    output, _ = helper.communicate()
    if helper.returncode != 0:
        # A snapshot that failed is not an empty process tree, so the sweep
        # refuses rather than reporting that a runner left nothing behind.
        raise EpisodeRefused(
            "the process snapshot the orphan sweep reads failed",
            {"command": "ps -A -o pid=,ppid=", "returncode": helper.returncode},
        )
    children = {}
    for line in output.splitlines():
        fields = line.split()
        if len(fields) != 2:
            continue
        try:
            child_pid = int(fields[0])
            parent_pid = int(fields[1])
        except ValueError:
            continue
        children.setdefault(parent_pid, []).append(child_pid)
    found = set()
    stack = [pid]
    while stack:
        current = stack.pop()
        for child_pid in children.get(current, ()):
            if child_pid in found or child_pid == helper.pid:
                continue
            found.add(child_pid)
            stack.append(child_pid)
    return found


def filesystem_fingerprint(root: Path, exclude=(), skip_git_metadata: bool = True, _seen=None,
                           _budget=None, _depth=0) -> dict:
    """Content key for every path under root, read from the filesystem alone.

    Every regular file is hashed by its bytes. Every symlink is hashed with its
    link text, the location it resolves to and the bytes of a regular file
    target, so a write through a link moves the key wherever it lands. Every
    directory is present as a path, so an empty directory created or removed is
    a difference. A removed path is a difference because the walk after it no
    longer lists it. Git is never consulted, so no index state, staged commit,
    clean filter or ignore rule can stand between the walk and the bytes. The
    root's own git directory is walked, except the paths the control plane's own
    worktree verbs churn, and a caller that walks a symlink target turns that
    skip off so the target is hashed whole. The walk counts entries and hashed
    bytes as it goes and refuses past the entry or byte budget, and it shares
    that budget with every directory it enters through a link. The walk's depth
    travels with a directory it enters through a link too, so a chain of linked
    directories reaches the depth bound instead of the interpreter's recursion
    limit.
    """
    root = Path(root)
    if _seen is None:
        _seen = {str(root.resolve())}
    if _budget is None:
        _budget = _WalkBudget()
    skip = [Path(item).resolve() for item in exclude]
    entries = []
    _budget.spend_entry()
    root_stat = os.lstat(root)
    if not stat.S_ISDIR(root_stat.st_mode):
        # Every walk records its root as a directory, so a link at the root
        # would put the link's own mode and modification time into the recorded
        # "directory" and an equivalent-directory swap would keep every
        # comparison still while the evidence moved under it. The state
        # directory, each worktree and each registration baseline start here,
        # so one check answers for all of them.
        raise EpisodeRefused(
            "the filesystem walk's root is not a directory",
            {"root": str(root), "mode": oct(root_stat.st_mode & 0o7777)},
        )
    entries.append({"path": ".", "kind": "directory",
                    "sha256": "directory", "bytes": None,
                    "mode": oct(root_stat.st_mode & 0o7777),
                    "mtime_ns": root_stat.st_mtime_ns})
    pending = [(root, _depth)]
    while pending:
        directory, depth = pending.pop()
        if depth > FINGERPRINT_DEPTH_LIMIT:
            raise EpisodeRefused(
                "the filesystem walk reached a directory deeper than the control plane bounds",
                {"directory": str(directory), "depth": depth,
                 "limit": FINGERPRINT_DEPTH_LIMIT},
            )
        try:
            children = []
            listed = 0
            for item in directory.iterdir():
                listed += 1
                if listed > FINGERPRINT_ENTRY_LIMIT:
                    raise EpisodeRefused(
                        f"the filesystem walk found a directory holding more than its "
                        f"{FINGERPRINT_ENTRY_LIMIT} entry budget",
                        {"directory": str(directory), "entries": listed,
                         "limit": FINGERPRINT_ENTRY_LIMIT},
                    )
                children.append(item)
            children.sort(key=lambda item: item.name)
        except OSError as exc:
            # A directory the walk cannot list is not an empty directory. It is
            # a hole in the evidence, so the walk fails closed and names the
            # directory it could not read.
            raise EpisodeRefused(
                "the filesystem walk could not list a directory it needs",
                {"directory": str(directory), "error": str(exc)},
            )
        for child in children:
            relative = child.relative_to(root).as_posix()
            try:
                child_stat = os.lstat(child)
            except OSError as exc:
                # A path the walk cannot stat is a hole in the evidence, like
                # a directory it cannot list, so the walk fails closed and
                # names the path it could not read.
                raise EpisodeRefused(
                    "the filesystem walk could not stat a path it needs",
                    {"path": str(child), "error": str(exc)},
                )
            # The object store is hashed like every other path. Hashing it costs
            # under a second per verb on this repository, and a same-size
            # overwrite is exactly the write this walk exists to see.
            if relative == ".git" or relative.startswith(".git/"):
                if skip_git_metadata:
                    if relative == ".git/worktrees" and stat.S_ISDIR(child_stat.st_mode):
                        # Git creates this directory on the first worktree add
                        # and removes it when prune finds it empty, so its own
                        # presence is churn the control plane causes. It still
                        # carries its mode and timestamp like any other
                        # directory, and the control plane refreshes those two
                        # fields in the pinned tree state after each of its own
                        # worktree verbs, so only a move the verbs did not make
                        # is a delta. Its children stay hashed, except this
                        # control plane's own registrations, which _excluded()
                        # already leaves out.
                        _budget.spend_entry()
                        entries.append({"path": relative, "kind": "directory",
                                        "sha256": "directory", "bytes": None,
                                        "mode": oct(child_stat.st_mode & 0o7777),
                                        "mtime_ns": child_stat.st_mtime_ns})
                        pending.append((child, depth + 1))
                        continue
                    if relative == ".git":
                        if stat.S_ISREG(child_stat.st_mode):
                            try:
                                _budget.spend_entry()
                                _budget.spend_bytes(child_stat.st_size)
                                digest = sha256_file(child)
                            except OSError as exc:
                                raise EpisodeRefused(
                                    "the filesystem walk could not read a git file it needs",
                                    {"path": str(child), "error": str(exc)},
                                )
                            entries.append({"path": relative, "kind": "gitfile",
                                            "sha256": digest, "bytes": child_stat.st_size,
                                            "mode": oct(child_stat.st_mode & 0o7777),
                                            "mtime_ns": child_stat.st_mtime_ns})
                        elif stat.S_ISDIR(child_stat.st_mode):
                            # The control plane's own worktree verbs create and
                            # remove the worktrees directory beneath this one,
                            # so this timestamp moves for work the control
                            # plane did. The entry still carries it, and the
                            # pinned tree state refreshes it after each verb,
                            # so only a move the verbs did not make is a
                            # delta.
                            _budget.spend_entry()
                            entries.append({"path": relative, "kind": "directory",
                                            "sha256": "directory", "bytes": None,
                                            "mode": oct(child_stat.st_mode & 0o7777),
                                            "mtime_ns": child_stat.st_mtime_ns})
                            pending.append((child, depth + 1))
                        continue
            # Exclusion is about where a path sits, not where it leads.
            own = Path(os.path.abspath(child))
            if any(own == item or item in own.parents for item in skip):
                continue
            if stat.S_ISLNK(child_stat.st_mode):
                _budget.spend_entry()
                # The target enters the walk one level below the directory the
                # link sits in, so a chain of links spends the depth budget.
                entries.append(symlink_fingerprint(child, relative, _seen, _budget, depth + 1))
            elif stat.S_ISDIR(child_stat.st_mode):
                _budget.spend_entry()
                entries.append({"path": relative, "kind": "directory",
                                "sha256": "directory", "bytes": None,
                                "mode": oct(child_stat.st_mode & 0o7777),
                                "mtime_ns": child_stat.st_mtime_ns})
                pending.append((child, depth + 1))
            elif stat.S_ISREG(child_stat.st_mode):
                # A timestamp that moves with nothing else in the tree still
                # marks a persistent write inside the tree, so a file entry
                # carries mtime_ns. The bytes are hashed in chunks, so the walk
                # never holds a whole file in memory, and they are counted
                # against the walk's byte budget.
                try:
                    _budget.spend_entry()
                    _budget.spend_bytes(child_stat.st_size)
                    digest = sha256_file(child)
                except OSError as exc:
                    raise EpisodeRefused(
                        "the filesystem walk could not read a file it needs",
                        {"path": str(child), "error": str(exc)},
                    )
                entries.append({"path": relative, "kind": "file",
                                "sha256": digest, "bytes": child_stat.st_size,
                                "mode": oct(child_stat.st_mode & 0o7777),
                                "mtime_ns": child_stat.st_mtime_ns})
            else:
                _budget.spend_entry()
                entries.append({"path": relative, "kind": "special",
                                "sha256": "special:" + oct(child_stat.st_mode),
                                "bytes": None,
                                "mode": oct(child_stat.st_mode & 0o7777),
                                "mtime_ns": child_stat.st_mtime_ns})
    entries.sort(key=lambda item: item["path"])
    return {"key": sha256_bytes(canonical_bytes(entries)), "entries": entries}


def fingerprint_delta(before, after, prefix="", attributed=None) -> list:
    """The difference between two fingerprints, path by path.

    A path present on one side only appeared or vanished. A path present on
    both sides whose key moved changed its bytes, its link or its kind. A
    directory created empty appears here as a new path even though it holds no
    file, and a directory removed appears as a vanished one. A directory's own
    timestamp is returned like every other difference. When the caller passes
    `attributed` as `(start_ns, end_ns, declared)`, a directory time change is
    dropped only when the directory itself is declared, or when a declared
    child appeared or vanished directly inside it in the step's own window and
    the change's own ordering holds: for an appeared child the directory's
    timestamp is not later than the child's write, and for a vanished child it
    is not earlier than the write the vanished entry still carries. A directory
    written after its child carries a timestamp later than every child that
    could explain it, so the change is kept and the declared-intent check
    refuses it unless the directory was declared. No final snapshot can tell a
    child's own creation apart from a write to the directory that copies the
    child's timestamp, so this ordering check is the strongest attribution a
    snapshot supports.
    """
    old = {item["path"]: item for item in before["entries"]}
    new = {item["path"]: item for item in after["entries"]}
    delta = []
    for path in sorted(set(old) | set(new)):
        if path not in old:
            delta.append({"path": prefix + path, "change": "appeared",
                          "after": new[path]["sha256"]})
        elif path not in new:
            delta.append({"path": prefix + path, "change": "vanished",
                          "before": old[path]["sha256"]})
        else:
            old_identity = (old[path]["kind"], old[path]["sha256"],
                            old[path].get("mode"), old[path].get("target"),
                            old[path].get("target_sha256"), old[path].get("mtime_ns"))
            new_identity = (new[path]["kind"], new[path]["sha256"],
                            new[path].get("mode"), new[path].get("target"),
                            new[path].get("target_sha256"), new[path].get("mtime_ns"))
            if old_identity != new_identity:
                fields = ("kind", "sha256", "mode", "target", "target_sha256", "mtime_ns")
                change = "changed"
                if (old_identity[0] == new_identity[0]
                        and old_identity[1] == new_identity[1]
                        and old_identity[3] == new_identity[3]
                        and old_identity[4] == new_identity[4]
                        and old_identity[5] == new_identity[5]):
                    change = "mode"
                elif (old_identity[0] == new_identity[0]
                        and old_identity[1] == new_identity[1]
                        and old_identity[2] == new_identity[2]
                        and old_identity[3] == new_identity[3]
                        and old_identity[4] == new_identity[4]):
                    change = "time"
                delta.append({"path": prefix + path, "change": change,
                              "before": dict(zip(fields, old_identity)),
                              "after": dict(zip(fields, new_identity))})
    if attributed is None:
        return delta
    start_ns, end_ns, declared = attributed
    window_low = start_ns - 2_000_000_000
    window_high = end_ns + 2_000_000_000
    kept = []
    for item in delta:
        if (item["change"] == "time"
                and (item["before"]["kind"] == "directory"
                     or item["after"]["kind"] == "directory")):
            own = item["path"]
            own_relative = own[len(prefix):] if prefix and own.startswith(prefix) else own
            mtime_ns = item["after"].get("mtime_ns")
            in_window = mtime_ns is not None and window_low <= mtime_ns <= window_high
            explained = in_window and own_relative in declared
            if not explained and in_window:
                parent = "" if own_relative == "." else own_relative
                for other in delta:
                    if other is item or other["change"] not in ("appeared", "vanished"):
                        continue
                    other_path = other["path"]
                    other_relative = (other_path[len(prefix):]
                                      if prefix and other_path.startswith(prefix)
                                      else other_path)
                    if posixpath.dirname(other_relative) != parent:
                        continue
                    if other_relative not in declared:
                        # The undeclared child already refuses the step, so the
                        # directory's own timestamp adds nothing beside it.
                        explained = True
                        break
                    # A vanished child's entry keeps the mtime of its last
                    # write, not of its deletion, and the deletion moves the
                    # parent at or after that write. The appearance ordering
                    # therefore reads the wrong way for a deletion, so each
                    # change tests its own direction: the parent's timestamp
                    # may not be later than an appeared child's write, and may
                    # not be earlier than a vanished child's.
                    if other["change"] == "appeared":
                        child = new.get(other_relative)
                        child_ns = child.get("mtime_ns") if child else None
                        if child_ns is not None and child_ns >= mtime_ns:
                            explained = True
                            break
                    else:
                        child = old.get(other_relative)
                        child_ns = child.get("mtime_ns") if child else None
                        if child_ns is not None and mtime_ns >= child_ns:
                            explained = True
                            break
            if explained:
                continue
        kept.append(item)
    return kept


# ───────────────────────────────────────────────────────────────
# 6. RANGE RESOLUTION
# ───────────────────────────────────────────────────────────────

def _resolve_commit(repo: Path, revision: str, original: str) -> str:
    """Resolve one side of a range to a full commit object name.

    `--end-of-options` makes the revision text a revision and nothing else, so
    option-like text cannot reach Git as an option, and `--verify` refuses a
    name that is not a commit. The answer has to be one full object name, so a
    partial or symbolic answer is refused rather than written into the record.
    """
    proc = git(repo, "rev-parse", "--verify", "--end-of-options", f"{revision}^{{commit}}")
    resolved = proc.stdout.decode("utf-8", "surrogateescape").strip()
    if proc.returncode != 0 or not re.fullmatch(r"[0-9a-f]{40}", resolved):
        raise EpisodeRefused(
            f"the commit range entry {original!r} does not name a commit",
            {"revision": original, "resolved": resolved,
             "stderr": proc.stderr.decode("utf-8", "surrogateescape").strip()},
        )
    return resolved


def resolve_range(repo: Path, rev_range: str) -> dict:
    if ".." in rev_range:
        base, head = rev_range.split("..", 1)
        base = base or "HEAD"
        head = head or "HEAD"
    else:
        base, head = rev_range, rev_range
    return {
        "range": rev_range,
        "base": _resolve_commit(repo, base, rev_range),
        "head": _resolve_commit(repo, head, rev_range),
    }


# ───────────────────────────────────────────────────────────────
# 7. RUNNER DESCRIPTION
# ───────────────────────────────────────────────────────────────

def describe_runner(runner) -> str:
    if callable(runner):
        return "callable " + getattr(runner, "__name__", "anonymous")
    if isinstance(runner, (list, tuple)):
        return " ".join(str(item) for item in runner)
    if isinstance(runner, str):
        return runner
    return repr(runner)


# ───────────────────────────────────────────────────────────────
# 8. EPISODE LOCKS
# ───────────────────────────────────────────────────────────────

class _EpisodeLock:
    """An exclusive lock on one episode, held for one whole verb.

    The lock file lives beside the record it guards. The kernel releases the
    lock when its descriptor closes, so a verb that crashes cannot leave the
    episode locked. A second verb that finds the lock held refuses rather than
    loading a record another verb is part way through changing. A lock file
    this context created is removed on an exceptional exit while it is still
    empty, still the object this context opened, and unpaired with a record of
    the same stem, so a verb that fails before it writes one leaves no orphan
    for a later close to trip over. A lock that paired with a record stays.
    """

    def __init__(self, path: Path, episode):
        self.path = path
        self.episode = episode
        self.descriptor = None
        self.created = False
        self.identity = None

    def __enter__(self):
        try:
            self.descriptor = os.open(
                self.path,
                os.O_RDWR | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW
                | getattr(os, "O_NONBLOCK", 0), 0o600)
            self.created = True
        except FileExistsError:
            try:
                self.descriptor = os.open(
                    self.path,
                    os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW
                    | getattr(os, "O_NONBLOCK", 0), 0o600)
                self.created = False
            except OSError as exc:
                raise EpisodeRefused(
                    f"episode {self.episode} has a lock path the control plane cannot use",
                    {"episode": str(self.episode), "lock": str(self.path), "error": str(exc)},
                )
        except OSError as exc:
            raise EpisodeRefused(
                f"episode {self.episode} has a lock path the control plane cannot use",
                {"episode": str(self.episode), "lock": str(self.path), "error": str(exc)},
            )
        info = os.fstat(self.descriptor)
        if not stat.S_ISREG(info.st_mode):
            os.close(self.descriptor)
            self.descriptor = None
            raise EpisodeRefused(
                f"episode {self.episode} has a lock path that is not a regular file, so it "
                f"cannot be held as a lock",
                {"episode": str(self.episode), "lock": str(self.path)},
            )
        self.identity = (info.st_dev, info.st_ino)
        try:
            fcntl.flock(self.descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            os.close(self.descriptor)
            self.descriptor = None
            raise EpisodeRefused(
                f"episode {self.episode} is held by another verb, so this one refused",
                {"episode": str(self.episode), "lock": str(self.path)},
            )
        return self

    def write_seal(self, state_dir: Path):
        """Record the state directory's metadata through the lock this verb holds.

        The record is written first and the seal second, so what the seal
        carries is the state directory as the record's own write left it.
        Writing the seal overwrites the lock's bytes and moves the lock's own
        timestamp, but it does not move the directory's timestamp, which is
        what lets close compare a later read of the directory with what the
        last write saw.
        """
        try:
            info = os.stat(state_dir)
        except OSError as exc:
            raise EpisodeRefused(
                f"the state directory at {state_dir} could not be read before it was sealed",
                {"state": str(state_dir), "error": str(exc)},
            )
        try:
            entries = sorted(os.listdir(state_dir))
        except OSError as exc:
            raise EpisodeRefused(
                f"the state directory at {state_dir} could not be listed before it was sealed",
                {"state": str(state_dir), "error": str(exc)},
            )
        if len(entries) > FINGERPRINT_ENTRY_LIMIT:
            raise EpisodeRefused(
                f"the state directory at {state_dir} holds more entries than the "
                f"{FINGERPRINT_ENTRY_LIMIT} entry budget, so it was refused rather than "
                f"sealed partially",
                {"state": str(state_dir), "entries": len(entries),
                 "limit": FINGERPRINT_ENTRY_LIMIT},
            )
        payload = json.dumps({
            "state": {
                "dev": info.st_dev,
                "ino": info.st_ino,
                "uid": info.st_uid,
                "gid": info.st_gid,
                "mtime_ns": info.st_mtime_ns,
            },
            "entries": entries,
        }, sort_keys=True).encode("utf-8")
        try:
            os.ftruncate(self.descriptor, 0)
            os.pwrite(self.descriptor, payload, 0)
        except OSError as exc:
            raise EpisodeRefused(
                f"the lock at {self.path} could not carry the state directory seal",
                {"lock": str(self.path), "error": str(exc)},
            )

    def _remove_orphan(self):
        """Remove a lock this context created when nothing paired with it.

        The path has to still be the object this context opened, it has to be
        empty, and no state record of the same stem may sit beside it. A lock
        someone else created, a lock that paired with a record, and a lock
        carrying bytes are all left in place.
        """
        if not self.created or self.identity is None:
            return
        beside = self.path.with_name(self.path.name[: -len(".lock")] + STATE_SUFFIX)
        if beside.exists() or beside.is_symlink():
            return
        try:
            orphan_stat = os.lstat(self.path)
        except OSError:
            return
        if (orphan_stat.st_dev, orphan_stat.st_ino) != self.identity or orphan_stat.st_size != 0:
            return
        try:
            self.path.unlink()
        except OSError:
            pass

    def __exit__(self, exc_type, exc_value, traceback):
        if self.descriptor is not None:
            try:
                fcntl.flock(self.descriptor, fcntl.LOCK_UN)
            finally:
                os.close(self.descriptor)
                self.descriptor = None
        if exc_type is not None:
            self._remove_orphan()
        return False


def locked_verb(method):
    """Hold the episode's exclusive lock around one whole verb.

    Every verb loads the record, changes it and writes it back. Two verbs at
    once could each write a record the other never saw, so the lock is taken
    before the first read and held until the last write. A verb that cannot
    take the lock refuses instead of proceeding without it.
    """

    @functools.wraps(method)
    def wrapper(self, episode, *args, **kwargs):
        with self._episode_lock(episode) as lock:
            # The verb's own writes seal the state directory through the lock
            # it holds, so the seal always describes the directory as the last
            # write of the verb left it.
            self._held_lock = lock
            try:
                return method(self, episode, *args, **kwargs)
            finally:
                self._held_lock = None

    return wrapper


# ───────────────────────────────────────────────────────────────
# 9. THE CONTROL PLANE
# ───────────────────────────────────────────────────────────────

class EpisodeControl:
    """Four verbs, their state beside the declaration, their worktrees in temp."""

    def __init__(self, repo=None, state_dir=None, worktree_root=None, declaration=None,
                 runner_timeout=3600):
        self.repo = Path(repo or DEFAULT_REPO).resolve()
        self._state_given = Path(state_dir or DEFAULT_STATE_DIR)
        if self._state_given.is_symlink():
            raise EpisodeRefused(
                "the state directory is not the one the control plane was given",
                {"state": str(self._state_given)},
            )
        self._state_realpath = os.path.realpath(self._state_given)
        self.state_dir = Path(self._state_realpath)
        self.worktree_root = Path(worktree_root or tempfile.gettempdir()).resolve()
        self.declaration = Path(declaration or DECLARATION).resolve()
        # A subprocess runner that reaches this deadline is killed by its
        # process group and refused with the deadline named. A callable runner
        # runs inside this process and carries no deadline.
        self.runner_timeout = runner_timeout
        self.state_dir.mkdir(parents=True, exist_ok=True)
        given_stat = os.stat(self._state_given)
        self._state_identity = (given_stat.st_dev, given_stat.st_ino)
        self._held_lock = None

    def _check_state_root(self):
        if (self._state_given.is_symlink()
                or os.path.realpath(self._state_given) != self._state_realpath):
            raise EpisodeRefused(
                "the state directory is not the one the control plane was given",
                {"state": str(self._state_given)},
            )
        root_stat = os.stat(self._state_given)
        if (root_stat.st_dev, root_stat.st_ino) != self._state_identity:
            raise EpisodeRefused(
                "the state directory is not the one the control plane was given",
                {"state": str(self._state_given)},
            )

    def _verify_lock_and_seal(self, record):
        """The lock this episode took, and the state directory its last write sealed.

        The lock is bound to the device, inode and mode it had when the
        episode took it, and the control plane never writes it, so close can
        require the path to still be that file. Its content is the seal the
        last record write left, which carries the state directory's own
        metadata as that write left it. Appending to the lock, replacing it,
        or touching the state directory between verbs moves something close
        compares, so the episode is refused rather than released over a state
        artifact that is no longer the one the record describes. A record that
        carries no lock binding cannot be confirmed and is refused the same
        way.
        """
        identity = record.get("lock_identity")
        mode = record.get("lock_mode")
        if identity is None or mode is None:
            raise EpisodeRefused(
                f"episode {record['id']} at {self._state_path(record['id'])} carries no lock "
                f"binding, so close cannot confirm the lock is the one this episode took",
                {"episode": str(record["id"]), "path": str(self._state_path(record["id"]))},
            )
        lock_path = self._lock_path(record["id"])
        try:
            lock_stat = os.lstat(lock_path)
        except OSError as exc:
            raise EpisodeRefused(
                f"the lock at {lock_path} could not be read, so close cannot confirm it is "
                f"the one this episode took",
                {"episode": str(record["id"]), "lock": str(lock_path), "error": str(exc)},
            )
        if not stat.S_ISREG(lock_stat.st_mode):
            raise EpisodeRefused(
                f"the lock at {lock_path} is not a regular file, so close cannot confirm "
                f"the state artifacts are the ones this episode took",
                {"episode": str(record["id"]), "lock": str(lock_path)},
            )
        if [lock_stat.st_dev, lock_stat.st_ino] != identity:
            raise EpisodeRefused(
                f"the lock at {lock_path} is not the file this episode took, so close refused "
                f"rather than release a state directory whose lock changed",
                {"episode": str(record["id"]), "lock": str(lock_path),
                 "taken": identity, "found": [lock_stat.st_dev, lock_stat.st_ino]},
            )
        current_mode = oct(lock_stat.st_mode & 0o7777)
        if current_mode != mode:
            raise EpisodeRefused(
                f"the lock at {lock_path} carries mode {current_mode} and was taken with "
                f"mode {mode}, so close refused",
                {"episode": str(record["id"]), "lock": str(lock_path)},
            )
        flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0)
        try:
            descriptor = os.open(str(lock_path), flags)
        except OSError as exc:
            raise EpisodeRefused(
                f"the lock at {lock_path} could not be opened as a regular file, so close "
                f"cannot read the seal it carries",
                {"episode": str(record["id"]), "lock": str(lock_path), "error": str(exc)},
            )
        try:
            info = os.fstat(descriptor)
            if not stat.S_ISREG(info.st_mode):
                raise EpisodeRefused(
                    f"the lock at {lock_path} is not a regular file, so close cannot read "
                    f"the seal it carries",
                    {"episode": str(record["id"]), "lock": str(lock_path)},
                )
            blocks, size = [], 0
            while True:
                block = os.read(descriptor, 1 << 20)
                if not block:
                    break
                size += len(block)
                if size > STATE_READ_LIMIT:
                    raise EpisodeRefused(
                        f"the lock at {lock_path} is larger than the "
                        f"{STATE_READ_LIMIT // (1 << 20)} MiB read limit, so the seal it "
                        f"carries was refused rather than held in memory",
                        {"episode": str(record["id"]), "lock": str(lock_path)},
                    )
                blocks.append(block)
        finally:
            os.close(descriptor)
        try:
            seal = json.loads(b"".join(blocks).decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise EpisodeRefused(
                f"the lock at {lock_path} does not carry the seal the last write left, so "
                f"close refused rather than trust a state directory that changed",
                {"episode": str(record["id"]), "lock": str(lock_path), "error": str(exc)},
            )
        expected = seal.get("state") if isinstance(seal, dict) else None
        sealed_entries = seal.get("entries") if isinstance(seal, dict) else None
        if not isinstance(expected, dict) or not isinstance(sealed_entries, list):
            raise EpisodeRefused(
                f"the lock at {lock_path} does not carry the seal the last write left, so "
                f"close refused rather than trust a state directory that changed",
                {"episode": str(record["id"]), "lock": str(lock_path)},
            )
        try:
            state_stat = os.stat(self.state_dir)
        except OSError as exc:
            raise EpisodeRefused(
                f"the state directory at {self.state_dir} could not be read, so close cannot "
                f"compare it with what the last write sealed",
                {"episode": str(record["id"]), "state": str(self.state_dir), "error": str(exc)},
            )
        found = {
            "dev": state_stat.st_dev,
            "ino": state_stat.st_ino,
            "uid": state_stat.st_uid,
            "gid": state_stat.st_gid,
            "mtime_ns": state_stat.st_mtime_ns,
        }
        if expected != found:
            # The state directory is shared. Another episode's record or lock
            # appearing, or a path an operator removed after an earlier close
            # refused on it, moves the directory's metadata for work that is
            # not this episode's. The write that moved it is explained only
            # when the entry set changed with it. With the entries unchanged,
            # the move is a write of the directory itself and close refuses.
            try:
                current_entries = sorted(os.listdir(self.state_dir))
            except OSError as exc:
                raise EpisodeRefused(
                    f"the state directory at {self.state_dir} could not be listed, so "
                    f"close cannot tell what moved its metadata",
                    {"episode": str(record["id"]), "state": str(self.state_dir),
                     "error": str(exc)},
                )
            if sealed_entries == current_entries:
                raise EpisodeRefused(
                    f"the state directory at {self.state_dir} is not the one the last write "
                    f"sealed and its entries did not change, so close refused rather than "
                    f"release an episode whose state directory was written",
                    {"episode": str(record["id"]), "expected": expected, "found": found},
                )

    # ───────────────────────────────────────────────────────────────
    # 10. THE FOUR VERBS
    # ───────────────────────────────────────────────────────────────

    @locked_verb
    def open(self, episode, commit_range="origin/main..HEAD", authorities=None, note=None):
        """Pin the input tuple a later dispatch is held to."""
        self._check_state_root()
        path = self._state_path(episode)
        if path.is_symlink():
            raise EpisodeRefused(
                f"episode {episode} has a state path that is a symlink, so the control plane "
                f"refused rather than writing through it",
                {"episode": str(episode), "path": str(path)},
            )
        if path.exists():
            raise EpisodeRefused(f"episode {episode} already has state at {path}")
        resolved = resolve_range(self.repo, commit_range)
        relative = self._declaration_relative()
        # Each authority is canonicalised once, here, to its repository
        # relative path, and the record keeps only that form. The pin reads it
        # from the commit, the join reads it from the live tree, and the
        # dispatched worktree is verified by joining the very same stored
        # path, so one spelling answers for all three. An absolute or parent
        # segment spelling of the same file would otherwise pin under one name
        # and then be verified under a spelling the dispatched worktree never
        # carries.
        authority_paths = [self._authority_relative(item) for item in
                           (authorities or [relative or str(self.declaration)])]
        # The authority keys are pinned from the commit the worktree is cut
        # from, never from the live tree, so a dirty working tree cannot move
        # what the episode recorded. Git reads a commit here, which makes this
        # a pin rather than a comparison against the working tree.
        authority_keys = self._pin_authorities(resolved["head"], authority_paths)
        # Each authority's state is recorded when the episode opens, so the
        # join compares the live object against the state this episode saw
        # rather than against a bare default, which reports a join for an
        # authority that never moved.
        authority_states = {}
        for item in authority_paths:
            absolute = Path(item) if Path(item).is_absolute() else (self.repo / item)
            authority_states[item] = _authority_state(absolute)
        state_stat = os.stat(self._state_given)
        # The lock is the artifact this episode took and the control plane
        # never writes. Its device, inode and mode are bound into the record
        # here, so a later close can require the path to still be that file.
        lock_path = self._lock_path(episode)
        try:
            lock_stat = os.lstat(lock_path)
        except OSError as exc:
            raise EpisodeRefused(
                f"episode {episode} has a lock path the control plane cannot read, so the "
                f"lock this episode took cannot be bound into the record",
                {"episode": str(episode), "lock": str(lock_path), "error": str(exc)},
            )
        record = {
            "id": episode,
            "opened_at": utc_now(),
            "repo": str(self.repo),
            "note": note,
            "state_identity": [state_stat.st_dev, state_stat.st_ino],
            "state_root_mode": oct(os.lstat(self.state_dir).st_mode & 0o7777),
            "lock_identity": [lock_stat.st_dev, lock_stat.st_ino],
            "lock_mode": oct(lock_stat.st_mode & 0o7777),
            # The pin comes from the commit the worktree is cut from, so the
            # declaration a dispatched step reads is the declaration the episode
            # recorded. A pin from any other revision would let the episode and
            # its worktree disagree about what was judged.
            "declaration": self._pin_declaration(resolved["head"]),
            "commit_range": resolved,
            # Reading HEAD is a pin read, not a content comparison.
            "live_head": git_text(self.repo, "rev-parse", "HEAD"),
            "tree_state": filesystem_fingerprint(self.repo, self._excluded()),
            "authorities": authority_paths,
            "authority_keys": authority_keys,
            "authority_states": authority_states,
            "joins": [],
            "steps": [],
            "closed_at": None,
            "closed_by": None,
        }
        self._write(record)
        return record

    @locked_verb
    def dispatch(self, episode, step, declared, run, families=None, permitted=None):
        """Run one step in an isolated worktree, then run the differ over it.

        Every runner for the step runs before the declared-intent comparison, so
        a family runner cannot write after the differ has passed. The comparison
        covers the worktree, the live tree and the live state directory. A step
        that leaks a write, touches a path it did not declare, leaves the
        permitted area or produces no output is refused. A refusal removes the
        worktree in a finally block, so a crash cannot leave it registered. Two
        families are optional. When they disagree the step is held, not refused,
        because a person still has to decide.
        """
        self._check_state_root()
        record = self._load(episode)
        self._refuse_closed(record)
        if any(item["step"] == step for item in record["steps"]):
            raise EpisodeRefused(f"step {step} already has a record in episode {episode}")
        families = list(families) if families else None
        if families is not None and len(families) != 2:
            raise EpisodeRefused("a two-family judgment needs exactly two families")
        joins_before = len(record.get("joins") or [])
        self._join_authorities(record)
        if len(record.get("joins") or []) > joins_before:
            # A join is evidence that an authority moved while the episode
            # stayed open. Writing it here means the tree-state refusal below
            # cannot discard it.
            self._write(record)

        before = filesystem_fingerprint(self.repo, self._excluded(record))
        if before["key"] != record["tree_state"]["key"]:
            raise EpisodeRefused(
                "the live tree moved since the episode opened, so the pinned tree state is gone",
                {"changed": self._state_delta(record["tree_state"], before)},
            )
        # Reading HEAD is a pin read, not a content comparison.
        live_head = git_text(self.repo, "rev-parse", "HEAD")
        if live_head != record.get("live_head"):
            raise EpisodeRefused(
                "the repository head moved since the episode opened",
                {"pinned_head": record.get("live_head"), "live_head": live_head},
            )

        declared_paths = sorted({normalise_path(item, self.repo) for item in declared})
        permitted_paths = [posixpath.normpath(str(item).replace("\\", "/")) for item in (permitted or [])]
        target = record["commit_range"]["head"]
        parent = Path(tempfile.mkdtemp(prefix=f"episode-{re.sub(r'[^A-Za-z0-9_-]', '-', str(episode))}-",
                                       dir=str(self.worktree_root)))
        worktree = parent / "worktree"
        entry = {
            "step": step,
            "at": utc_now(),
            "declared": declared_paths,
            "permitted": permitted_paths,
            "run": describe_runner(run),
            "output_sha256": None,
            "stdout": None,
            "stderr": None,
            "actual": [],
            "undeclared": [],
            "leaked": [],
            "families": [],
            "orphans": [],
            "verdict": None,
            "reason": None,
            "content_key": None,
            "disagreement_key": None,
            # The entry is appended before the declaration and authority checks
            # so a step those checks refuse still leaves a record. The refusal
            # placeholder is replaced on success and set to the refusal reason
            # when either check refuses.
            "disposition": {"decision": "refused", "why": None},
            "worktree": str(worktree),
            "worktree_parent": str(parent),
            "registration": None,
            "registration_baseline": None,
            "worktree_removed_at": None,
            "cleanup_failure": None,
        }
        record["steps"].append(entry)
        appended = True
        keep_worktree = False
        try:
            git_text(self.repo, "worktree", "add", "--detach", str(worktree), target)
            # The verb moved exactly the metadata the pinned tree state now
            # refreshes, so a step is not blamed for the control plane's own
            # setup change.
            self._refresh_git_metadata(record)
            # Git names its own metadata here, so this read is a pin and not a
            # comparison against the working tree.
            entry["registration"] = git_text(
                self.repo, "-C", str(worktree), "rev-parse", "--absolute-git-dir")
            # Git creates this registration while the step runs, so the
            # live-tree walk keeps the directory out of the pinned comparison.
            # The snapshot taken here, straight after `worktree add`, is the
            # baseline a later comparison uses to tell the entries git made
            # from an entry no part of the control plane created.
            entry["registration_baseline"] = filesystem_fingerprint(Path(entry["registration"]))
            try:
                self._verify_declaration(worktree, record)
                self._verify_authorities(worktree, record)
            except EpisodeRefused as exc:
                entry["verdict"] = "refused"
                entry["reason"] = exc.reason
                entry["disposition"] = {"decision": "refused", "why": exc.reason}
                entry["content_key"] = content_key(record_content(entry))
                raise
            entry["disposition"] = None
            worktree_before = filesystem_fingerprint(worktree)

            state_before = self._state_fingerprint()
            refusal = None
            output = None
            error = None
            failure = None
            orphan_reason = None
            started_ns = time.time_ns()
            try:
                output, error, failure, orphan_reason = self._run_swept(
                    run, worktree, "the step", entry)
            except EpisodeRefused as exc:
                refusal = exc.reason
            except Exception as exc:  # a step that crashes is a refused step
                refusal = f"the step raised {type(exc).__name__}: {exc}"
            if output is not None:
                entry["stdout"] = output
                entry["stderr"] = error
                if output["bytes"]:
                    entry["output_sha256"] = output["sha256"]
            if refusal is None and failure is not None:
                refusal = failure
            if refusal is None and orphan_reason is not None:
                refusal = orphan_reason
            if refusal is None and not (output or {}).get("has_content"):
                refusal = ("the step produced no output, and an empty result is a failure "
                           "rather than a pass")

            # Every runner that can write runs before the comparison. The
            # declared-intent check and the live-tree check both run after the
            # family runners, so neither can pass a step whose later runner
            # touched a path it should not have.
            if families is not None and refusal is None:
                for label, runner in zip(("family-a", "family-b"), families):
                    try:
                        answer, error, failure, orphan_reason = self._run_swept(
                            runner, worktree, label, entry)
                    except EpisodeRefused as exc:
                        refusal = exc.reason
                        break
                    except Exception as exc:
                        refusal = f"{label} raised {type(exc).__name__}: {exc}"
                        break
                    if failure is not None:
                        refusal = failure
                        break
                    if orphan_reason is not None:
                        refusal = orphan_reason
                        break
                    if not (answer or {}).get("has_content"):
                        refusal = (label + " returned no output, and an empty result is a failure "
                                   "rather than a pass")
                        break
                    entry["families"].append({
                        "family": label,
                        "sha256": answer["sha256"],
                        "bytes": answer["bytes"],
                        "truncated": answer["truncated"],
                        "text": answer["text"],
                        "stderr": error,
                    })

            # A directory timestamp is attributed to a declared child only
            # when the directory's own timestamp is not later than that
            # child's. A runner that creates a declared child and then writes
            # its parent leaves the parent's timestamp later than every child
            # that could explain it, so the directory stays in the delta and
            # the declared-intent check below refuses it unless the directory
            # itself is one of the declared paths.
            worktree_after = filesystem_fingerprint(worktree)
            changes = fingerprint_delta(worktree_before, worktree_after,
                                        attributed=(started_ns, time.time_ns(),
                                                    set(declared_paths)))
            entry["actual"] = changes
            actual_paths = sorted({item["path"] for item in changes})
            entry["undeclared"] = [item for item in actual_paths if item not in declared_paths]
            if refusal is None and entry["undeclared"]:
                refusal = ("the step touched " + str(len(entry["undeclared"])) +
                           " path(s) it did not declare: " + ", ".join(entry["undeclared"]))
            if refusal is None and permitted_paths:
                outside = [item for item in actual_paths if not _inside(item, permitted_paths)]
                if outside:
                    refusal = "the step touched path(s) outside the permitted area: " + ", ".join(outside)

            after = filesystem_fingerprint(self.repo, self._excluded(record))
            state_after = self._state_fingerprint()
            entry["leaked"] = self._state_delta(record["tree_state"], after)
            entry["leaked"].extend(self._fingerprint_delta(state_before, state_after))
            # A worktree link whose target sits outside the worktree carries
            # the step's write past every comparison this verdict makes: the
            # worktree walk keys the link by its target, yet the target itself
            # sits outside that walk, the live-tree walk never reaches it and
            # the state walk cannot either, so a declared link path was enough
            # to let a persistent write land unseen. Every changed link's
            # target is therefore classified here, where the worktree's own
            # resolved root is known, whatever the declared paths say about
            # the link itself. A vanished link keeps its last target, because
            # that is where the step's write went.
            worktree_root = worktree.resolve()
            links_after = {item["path"]: item for item in worktree_after["entries"]
                           if item["kind"] == "symlink"}
            links_before = {item["path"]: item for item in worktree_before["entries"]
                            if item["kind"] == "symlink"}
            for item in changes:
                link = links_after.get(item["path"]) or links_before.get(item["path"])
                if link is None:
                    continue
                target = Path(link["target"])
                if target == worktree_root or worktree_root in target.parents:
                    continue
                entry["leaked"].append({
                    "path": str(target),
                    "change": "target-outside",
                    "link": link["path"],
                })
            # Every live registration is compared with the baseline taken
            # straight after its own `worktree add`. An entry that was not there
            # at registration time was not created by any part of the control
            # plane, so it is a finding that names its path rather than a
            # subtree the pinned live-tree walk stays silent about. The control
            # plane makes no other change to a registration before this
            # comparison, so every delta counts and an existing entry whose
            # bytes, mode or timestamp moved is a finding too, not only one
            # that appeared or vanished.
            for item in record.get("steps", []):
                registration = item.get("registration")
                if not registration or item.get("worktree_removed_at") is not None:
                    continue
                registration = Path(registration)
                try:
                    prefix = registration.relative_to(self.repo).as_posix() + "/"
                except ValueError:
                    prefix = registration.as_posix() + "/"
                baseline = item.get("registration_baseline")
                if baseline is None:
                    # A record that predates the baseline carries no way to tell
                    # the entries git made from one the step made, so it is
                    # named rather than left unwatched.
                    entry["leaked"].append({
                        "path": prefix.rstrip("/"),
                        "change": "unbaselined",
                        "reason": "the live registration carries no baseline of what "
                                  "registration created, so an entry under it cannot be "
                                  "told from one the step made",
                    })
                    continue
                try:
                    delta = fingerprint_delta(
                        baseline, filesystem_fingerprint(registration), prefix=prefix)
                except (EpisodeRefused, OSError) as exc:
                    # A registration the control plane can no longer read is not
                    # an unchanged one, so it is named rather than skipped.
                    entry["leaked"].append({
                        "path": prefix.rstrip("/"),
                        "change": "unreadable",
                        "reason": str(getattr(exc, "reason", exc)),
                    })
                    continue
                entry["leaked"].extend(delta)
            if entry["leaked"] and refusal is None:
                refusal = ("the step wrote outside its worktree, so the live tree moved under "
                           "the episode: " + ", ".join(item["path"] for item in entry["leaked"]))

            if refusal is None:
                if families is not None:
                    verdict = ("agreed" if entry["families"][0]["sha256"] == entry["families"][1]["sha256"]
                               else "disagreement")
                else:
                    verdict = "accepted"
            else:
                verdict = "refused"
            entry["verdict"] = verdict
            entry["reason"] = refusal
            entry["content_key"] = content_key(record_content(entry))
            if verdict == "disagreement":
                entry["disagreement_key"] = content_key(entry["families"])
            keep_worktree = verdict != "refused"
        except BaseException as exc:
            # A failure anywhere in setup, the run or the fingerprint still
            # leaves a refused record with a key, so no persisted step carries
            # a null verdict and close has content to verify.
            if entry["verdict"] is None:
                reason = (f"the step was refused because dispatch raised "
                          f"{type(exc).__name__}: {exc}")
                entry["verdict"] = "refused"
                entry["reason"] = reason
                entry["disposition"] = {"decision": "refused", "why": reason}
                entry["content_key"] = content_key(record_content(entry))
            raise
        finally:
            persisted = False
            write_error = None
            try:
                if appended:
                    try:
                        self._write(record)
                        persisted = True
                    except BaseException as exc:
                        write_error = exc
                        raise
            finally:
                # The worktree goes on every path, including one where the
                # record could not be persisted. A write failure is reported
                # beside whatever cleanup found, and a refusal's removal is
                # recorded on its own step.
                if appended and not persisted:
                    try:
                        self._remove_worktree(entry)
                    except EpisodeRefused as cleanup_exc:
                        if isinstance(write_error, EpisodeRefused):
                            write_error.evidence["cleanup"] = cleanup_exc.reason
                    if isinstance(write_error, EpisodeRefused):
                        write_error.evidence["worktree"] = entry["worktree"]
                elif not keep_worktree:
                    try:
                        self._remove_worktree(entry)
                    except EpisodeRefused as exc:
                        entry["cleanup_failure"] = exc.reason
                        self._write(record)
                        raise
                    # The removal moved the same metadata, so the pinned tree
                    # state refreshes before it is written back.
                    self._refresh_git_metadata(record)
                    self._write(record)
        if entry["verdict"] == "refused":
            raise EpisodeRefused(entry["reason"] or "the step was refused", {"step": entry})
        return entry

    @locked_verb
    def adjudicate(self, episode, step, decision, why, operator=None):
        """Record the operator decision on a held disagreement."""
        self._check_state_root()
        record = self._load(episode)
        self._refuse_closed(record)
        entry = next((item for item in record["steps"] if item["step"] == step), None)
        if entry is None:
            raise EpisodeRefused(f"episode {episode} has no step named {step}")
        if entry["verdict"] != "disagreement":
            raise EpisodeRefused(f"step {step} is {entry['verdict']}, so there is nothing to adjudicate")
        if entry.get("disposition") is not None:
            raise EpisodeRefused(f"step {step} already carries a disposition")
        if not decision or not str(decision).strip():
            raise EpisodeRefused("an adjudication needs a decision")
        if not why or not str(why).strip():
            raise EpisodeRefused("an adjudication needs a durable reason")
        entry["disposition"] = {
            "at": utc_now(),
            "operator": operator,
            "decision": str(decision),
            "why": str(why),
            "key": content_key(entry["families"]),
        }
        self._write(record)
        return entry

    @locked_verb
    def close(self, episode, operator=None):
        """Recompute every record key, then release the worktrees.

        The state root's own timestamp is not compared at close because the
        control plane's record writes move it, and a step that moved it was
        already refused with the evidence recorded.
        """
        self._check_state_root()
        record = self._load(episode)
        self._refuse_closed(record)
        if not record["steps"]:
            raise EpisodeRefused(f"episode {episode} has no steps, so there is nothing to close")
        findings = []
        for entry in record["steps"]:
            if entry.get("content_key") is None:
                findings.append(f"step {entry['step']}: the record carries no content key, so "
                                f"there is nothing to recompute it from")
            elif content_key(record_content(entry)) != entry["content_key"]:
                findings.append(f"step {entry['step']}: the record's content key no longer "
                                f"recomputes, so the record is void")
            if entry.get("disagreement_key") is not None:
                if content_key(entry.get("families") or []) != entry["disagreement_key"]:
                    findings.append(f"step {entry['step']}: the disagreement key no longer "
                                    f"recomputes, so the answers it keyed changed")
            if entry["verdict"] == "disagreement":
                disposition = entry.get("disposition")
                if entry.get("disagreement_key") is None:
                    findings.append(f"step {entry['step']}: the disagreement carries no "
                                    f"disagreement key")
                if disposition is None:
                    findings.append(f"step {entry['step']}: a two-family disagreement carries no "
                                    f"disposition, so close is refused until an operator decides")
                elif content_key(entry["families"]) != disposition["key"]:
                    findings.append(f"step {entry['step']}: the disposition's content key no longer "
                                    f"recomputes, so the discussion it decided changed under it")
            elif entry["verdict"] not in ("accepted", "agreed", "refused"):
                findings.append(f"step {entry['step']}: verdict is {entry['verdict']}")
        if findings:
            raise EpisodeRefused("close refused: " + findings[0], {"findings": findings})
        fresh = filesystem_fingerprint(self.repo, self._excluded(record))
        if fresh["key"] != record["tree_state"]["key"]:
            raise EpisodeRefused(
                "close refused: the live tree moved since the episode opened",
                {"changed": self._state_delta(record["tree_state"], fresh)},
            )
        # Reading HEAD is a pin read, not a content comparison.
        live_head = git_text(self.repo, "rev-parse", "HEAD")
        if live_head != record.get("live_head"):
            raise EpisodeRefused(
                "the repository head moved since the episode opened",
                {"pinned_head": record.get("live_head"), "live_head": live_head},
            )
        state_names = []
        state_entries = 0
        for item in self.state_dir.iterdir():
            state_entries += 1
            if state_entries > FINGERPRINT_ENTRY_LIMIT:
                raise EpisodeRefused(
                    f"the state directory holds more entries than the "
                    f"{FINGERPRINT_ENTRY_LIMIT} entry budget",
                    {"directory": str(self.state_dir), "entries": state_entries,
                     "limit": FINGERPRINT_ENTRY_LIMIT},
                )
            state_names.append(item.name)
        state_names.sort()
        unexpected = []
        refused_paths = {}
        for name in state_names:
            item = self.state_dir / name
            # A lock file is the control plane's own artefact, and one per
            # episode stays beside its record by design. A regular lock file
            # that is not a link and has a record of the same stem beside it
            # belongs here; any other lock name, link, directory or path with
            # no record belongs to something else.
            if name.endswith(".lock"):
                beside = self.state_dir / (name[:-len(".lock")] + STATE_SUFFIX)
                if (not item.is_symlink() and item.is_file()
                        and not beside.is_symlink() and beside.is_file()):
                    continue
                unexpected.append(name)
                refused_paths[name] = "a lock path with no record of the same stem"
                continue
            if item.is_symlink() or not item.is_file() or not name.endswith(STATE_SUFFIX):
                unexpected.append(name)
                refused_paths[name] = "not a regular state record"
                continue
            try:
                # The file name carries the sanitized episode, so the id the
                # record holds can differ from the stem. The mapping back to
                # the record's own path below is the identity check here.
                parsed = self._load(name[: -len(STATE_SUFFIX)], expect_id=False)
                created = self._state_path(parsed.get("id")).name == name
            except (OSError, ValueError, TypeError, EpisodeRefused) as exc:
                created = False
                refused_paths[name] = str(exc)
            if not created:
                unexpected.append(name)
                refused_paths.setdefault(name, "the record does not map back to its own name")
        if unexpected:
            explained = []
            for name in unexpected:
                reason = refused_paths.get(name)
                explained.append(f"{name} ({reason})" if reason else name)
            # The refusal below names paths a previous close did not see. The
            # state directory is re-sealed here so the next close, after the
            # paths are removed, compares against the directory as it stands
            # now rather than refusing forever on the removal that moved it.
            if self._held_lock is not None:
                self._held_lock.write_seal(self.state_dir)
            raise EpisodeRefused(
                "close refused: the state directory holds a path the control plane did not "
                "create: " + ", ".join(explained),
                {"entries": state_names, "unexpected": unexpected,
                 "reasons": refused_paths},
            )
        current_root_mode = oct(os.lstat(self.state_dir).st_mode & 0o7777)
        if current_root_mode != record.get("state_root_mode"):
            raise EpisodeRefused(
                "close refused: the state directory's mode moved",
                {"opened_mode": record.get("state_root_mode"), "close_mode": current_root_mode},
            )
        # The lock this episode took and the seal its last write left are
        # compared here, before close makes any change of its own, so a lock
        # that changed or a state directory that was touched between verbs is
        # a refusal rather than a closed episode.
        self._verify_lock_and_seal(record)
        # A refused step records the state directory leaks it left behind. The
        # record is a carrier, so each still-present leak is checked against the
        # disk here rather than trusted to have been cleaned up.
        for entry in record["steps"]:
            if entry.get("verdict") != "refused":
                continue
            for item in entry.get("leaked") or []:
                leaked_path = item.get("path", "")
                if (not leaked_path.startswith("state dir/")
                        or leaked_path == "state dir/."):
                    continue
                if (self.state_dir / leaked_path[len("state dir/"):]).exists():
                    raise EpisodeRefused(
                        "close refused: a state directory leak is still present",
                        {"step": entry["step"], "path": leaked_path},
                    )
        alive = descendants(os.getpid())
        if alive:
            raise EpisodeRefused("a process from this episode is still running",
                                 {"pids": sorted(alive)})
        if any(t is not threading.main_thread() and t.is_alive()
               for t in threading.enumerate()):
            raise EpisodeRefused("a thread from this episode is still running")
        for entry in record["steps"]:
            self._remove_worktree(entry)
        # Every removal moved the same metadata, so the pinned tree state
        # refreshes before the closed record is written.
        self._refresh_git_metadata(record)
        for entry in record["steps"]:
            worktree = Path(entry["worktree"])
            if worktree.exists():
                raise EpisodeRefused(
                    "close refused: a worktree still exists on disk",
                    {"worktree": str(worktree)},
                )
            listed = git_text(self.repo, "worktree", "list", "--porcelain")
            for line in listed.splitlines():
                if line.startswith("worktree ") and line[len("worktree "):].strip() == str(worktree):
                    raise EpisodeRefused(
                        "close refused: a worktree still exists on disk",
                        {"worktree": str(worktree)},
                    )
        record["closed_at"] = utc_now()
        record["closed_by"] = operator
        self._write(record)
        return record

    # ───────────────────────────────────────────────────────────────
    # 11. INTERNALS
    # ───────────────────────────────────────────────────────────────

    def _kill_process_group(self, proc) -> None:
        try:
            os.killpg(proc.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass

    def _run(self, runner, worktree: Path, label: str):
        """Run one runner and return its two streams and a failure reason.

        The streams are the bounded heads of the full text, each carrying the
        hash and the byte length of the whole stream. A subprocess runner runs
        in its own session, so it can be killed by its process group when it
        reaches the runner deadline, and a non-zero exit is a failure. A
        callable runner is the selftest's in-process fixture: it runs without a
        deadline by design, because the control plane cannot interrupt code in
        its own process, and production steps use the subprocess forms.
        """
        if callable(runner):
            try:
                result = runner(worktree)
            except EpisodeRefused:
                raise
            except Exception as exc:  # a runner that crashes is a refused step
                return None, None, f"{label} raised {type(exc).__name__}: {exc}"
            return bounded_text("" if result is None else str(result)), None, None
        if isinstance(runner, (list, tuple)):
            argv = [str(item) for item in runner]
        elif isinstance(runner, str):
            argv = ["bash", "-lc", runner]
        else:
            return None, None, f"{label} runner has an unsupported type: {type(runner).__name__}"
        proc = subprocess.Popen(argv, cwd=str(worktree), stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, start_new_session=True)
        out_reader = _StreamReader(proc.stdout)
        err_reader = _StreamReader(proc.stderr)
        out_reader.start()
        err_reader.start()
        deadline = time.monotonic() + self.runner_timeout
        timed_out = False
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                timed_out = True
                self._kill_process_group(proc)
                break
            try:
                proc.wait(timeout=min(remaining, 0.25))
                break
            except subprocess.TimeoutExpired:
                continue
        if not timed_out:
            # The runner is gone, but a background grandchild may still hold a
            # pipe end open, so the whole process group is killed before the
            # reader threads can end.
            self._kill_process_group(proc)
        try:
            # Reap the runner, so the orphan sweep that follows does not see
            # the control plane's own killed child as a process left behind.
            proc.wait(timeout=STREAM_READ_GRACE)
        except subprocess.TimeoutExpired:
            pass
        for reader in (out_reader, err_reader):
            reader.join(timeout=STREAM_READ_GRACE)
        for reader in (out_reader, err_reader):
            if reader.is_alive():
                # A pipe end held open by a process outside the group would
                # otherwise keep the read unbounded. Closing the stream is the
                # bounded escape; a reader still alive is named as a thread
                # orphan by the sweep that follows.
                reader.close_stream()
        out = out_reader.snapshot()
        err = err_reader.snapshot()
        if timed_out:
            return (out, err,
                    f"{label} reached the {self.runner_timeout}s runner deadline, so its "
                    f"process group was killed")
        out_error = out_reader.read_error()
        err_error = err_reader.read_error()
        if out_error is not None or err_error is not None:
            failed = []
            if out_error is not None:
                failed.append(f"stdout: {out_error}")
            if err_error is not None:
                failed.append(f"stderr: {err_error}")
            return out, err, f"{label} output could not be read: " + ", ".join(failed)
        if proc.returncode != 0:
            return out, err, f"{label} exited {proc.returncode}: {err['text'].strip()[:300]}"
        return out, err, None

    def _run_swept(self, runner, worktree, label, entry):
        """Run one runner, then kill and name any process it leaves behind.

        The snapshot is taken immediately before the runner, so a process an
        earlier runner left is not blamed on this one.
        """
        procs_before = descendants(os.getpid())
        threads_before = {t.ident for t in threading.enumerate()}
        try:
            output, error, failure = self._run(runner, worktree, label)
        finally:
            orphans = descendants(os.getpid()) - procs_before
            for n in sorted(orphans):
                command = subprocess.run(
                    ["ps", "-o", "command=", "-p", str(n)],
                    capture_output=True, text=True).stdout.strip()
                entry["orphans"].append({"pid": n, "command": command})
                try:
                    os.kill(n, signal.SIGKILL)
                except ProcessLookupError:
                    pass
            # A thread cannot be killed from Python, so naming it is the whole
            # remedy this refusal can offer.
            threads = [t for t in threading.enumerate()
                       if t.ident not in threads_before and t.is_alive()]
            for t in threads:
                entry["orphans"].append({"thread": t.name})
            reasons = []
            if orphans:
                reasons.append(label + " left a process running: "
                               + ", ".join(str(n) for n in sorted(orphans)))
            if threads:
                reasons.append(label + " left a thread running: "
                               + ", ".join(t.name for t in threads))
            orphan_reason = ", ".join(reasons) if reasons else None
        return output, error, failure, orphan_reason

    def _state_delta(self, before, after):
        return fingerprint_delta(before, after)

    def _join_authorities(self, record):
        """Record later revisions of the pinned authorities and declaration.

        A join is evidence that the declaration or an authority moved on. It
        never replaces the declaration pin, because the pin names the revision
        the dispatched worktree carries and a later revision was not what the
        step read. Every join carries the object state that was seen, and the
        state is compared with the key, so a deletion followed by a different
        kind of object at the same path is durable evidence even though both
        objects key as null. For a symlink the state carries the link text and
        the resolved target path as well, so a retarget to a byte-identical
        file is still a join. The declaration itself is joined when it is
        missing or is not a regular file, not only when its bytes move. The
        latest key and state are kept for each path, so the next call does not
        append the same join again.
        """
        declaration_path = self._declaration_relative() or str(self.declaration)
        declaration_state = _object_state(self.declaration)
        declaration_key = sha256_file(self.declaration) if self.declaration.is_file() else None
        previous_key = record["declaration"].get("sha256")
        previous_state = record["declaration"].get("state", "file")
        for join in record.get("joins", []):
            if join.get("path") == declaration_path:
                previous_key = join.get("sha256")
                previous_state = join.get("state", previous_state)
        if declaration_key != previous_key or declaration_state != previous_state:
            record["joins"].append({
                "at": utc_now(),
                "path": declaration_path,
                "state": declaration_state,
                "previous_state": previous_state,
                "previous_sha256": previous_key,
                "sha256": declaration_key,
                "commit": git_text(self.repo, "rev-parse", "HEAD", required=False) or None,
            })
        for item in record.get("authorities", []):
            absolute = Path(item) if Path(item).is_absolute() else (self.repo / item)
            if absolute.resolve() == self.declaration.resolve():
                continue
            state = _authority_state(absolute)
            item_key = sha256_file(absolute) if absolute.is_file() else None
            previous_key = record.setdefault("authority_keys", {}).get(item)
            previous_state = record.setdefault("authority_states", {}).get(item, "file")
            if previous_key == item_key and previous_state == state:
                continue
            record["joins"].append({
                "at": utc_now(),
                "path": item,
                "state": state,
                "previous_state": previous_state,
                "previous_sha256": previous_key,
                "sha256": item_key,
                "commit": git_text(self.repo, "rev-parse", "HEAD", required=False) or None,
            })
            record["authority_keys"][item] = item_key
            record["authority_states"][item] = state

    def _refresh_git_metadata(self, record):
        """Fold the control plane's own `.git` metadata moves into the tree state.

        `worktree add` creates the registration directory and, on its first
        call, `.git/worktrees`, which moves the timestamps of `.git` and
        `.git/worktrees`. `worktree remove` and prune move the same two when
        the last registration goes. Those two paths are the whole setup and
        cleanup change the control plane makes inside the pinned tree, so
        their entries are refreshed from the filesystem after each of its own
        worktree verbs. Every other entry keeps the baseline it was pinned
        with, so a timestamp or mode move the verbs did not make still moves
        the key.
        """
        entries = record["tree_state"]["entries"]
        # The worktree registrations this control plane creates and removes
        # live under the git common directory. When the watched root is the
        # main checkout, that directory is `.git` here, so the verbs churn
        # `.git` and `.git/worktrees` and the pinned walk carries both. When
        # the watched root is itself a linked worktree, its `.git` is a file
        # naming its own registration under the main checkout, the common
        # directory sits outside the pinned walk, and the verbs move nothing
        # the pinned walk carries: the registration they change is already
        # compared against its own registration baseline.
        if not (self.repo / ".git").is_dir():
            return
        for path in (".git", ".git/worktrees"):
            try:
                info = os.lstat(self.repo / path)
            except FileNotFoundError:
                # The last registration was pruned, which is the cleanup
                # change itself, so the entries the walk no longer finds go
                # with the directory.
                entries = [item for item in entries
                           if item["path"] != path and not item["path"].startswith(path + "/")]
                record["tree_state"]["entries"] = entries
                continue
            except OSError as exc:
                raise EpisodeRefused(
                    "the control plane could not read the git metadata it changed",
                    {"path": str(self.repo / path), "error": str(exc)},
                )
            for item in entries:
                if item["path"] == path and item["kind"] == "directory":
                    item["mode"] = oct(info.st_mode & 0o7777)
                    item["mtime_ns"] = info.st_mtime_ns
                    break
            else:
                if path == ".git/worktrees" and stat.S_ISDIR(info.st_mode):
                    entries.append({"path": path, "kind": "directory",
                                    "sha256": "directory", "bytes": None,
                                    "mode": oct(info.st_mode & 0o7777),
                                    "mtime_ns": info.st_mtime_ns})
                    entries.sort(key=lambda item: item["path"])
        record["tree_state"]["key"] = sha256_bytes(canonical_bytes(entries))

    def _remove_worktree(self, entry):
        """Remove a worktree the control plane created, and fail loudly if it cannot.

        The removal runs from dispatch's finally block and from close, so an
        accepted, held or refused step never leaves a worktree registered. A
        removal failure is raised rather than swallowed, because a silent one
        would report a closed episode that still occupies a worktree.
        """
        if entry.get("worktree_removed_at"):
            return
        worktree = Path(entry["worktree"])
        parent = Path(entry["worktree_parent"])
        if worktree.exists():
            proc = git(self.repo, "worktree", "remove", "--force", str(worktree))
            if proc.returncode != 0:
                raise EpisodeRefused(
                    "the control plane could not remove its own worktree",
                    {"worktree": str(worktree),
                     "stderr": proc.stderr.decode("utf-8", "surrogateescape").strip()},
                )
        prune = git(self.repo, "worktree", "prune")
        if prune.returncode != 0:
            raise EpisodeRefused(
                "the control plane could not prune its worktree records",
                {"stderr": prune.stderr.decode("utf-8", "surrogateescape").strip()},
            )
        leftover = parent / "worktree"
        if leftover.exists():
            shutil.rmtree(leftover)
        if parent.exists():
            try:
                parent.rmdir()
            except OSError:
                raise EpisodeRefused(
                    "the control plane's temp parent holds files it did not create",
                    {"parent": str(parent),
                     "entries": sorted(p.name for p in parent.iterdir())},
                )
        entry["worktree_removed_at"] = utc_now()

    def _pin_declaration(self, commit: str) -> dict:
        """The declaration revision at the commit a worktree is cut from."""
        relative = self._declaration_relative()
        pinned = {
            "path": relative or str(self.declaration),
            "sha256": None,
            "git_blob": None,
            "commit": commit,
            "state": _object_state(self.declaration),
        }
        if relative:
            blob = git_text(self.repo, "rev-parse", f"{commit}:{relative}", required=False)
            if blob:
                pinned["git_blob"] = blob
                pinned["sha256"] = sha256_bytes(git_bytes(self.repo, "show", f"{commit}:{relative}"))
                pinned["state"] = "file"
                return pinned
        if self.declaration.is_file():
            pinned["sha256"] = sha256_file(self.declaration)
        return pinned

    def _authority_relative(self, item) -> str:
        """The one spelling an authority is stored under: repository relative.

        The same recorded path is later joined onto three different roots: the
        pinned commit, the live tree and the dispatched worktree. Only a
        repository relative spelling joins onto the worktree, because the
        worktree carries the repository's own layout, so an absolute or parent
        segment spelling is rewritten here, once, at open. An authority that
        resolves outside the repository is refused here, before any record is
        written, with the same finding the pin would have raised.
        """
        absolute = Path(item) if Path(item).is_absolute() else (self.repo / item)
        try:
            return absolute.resolve().relative_to(self.repo).as_posix()
        except ValueError:
            raise EpisodeRefused(
                f"the authority {item} is outside the repository, so no commit revision "
                f"can answer for it",
                {"authority": str(item), "repository": str(self.repo)},
            )

    def _pin_authorities(self, commit: str, authorities) -> dict:
        """The key of every authority at the commit a worktree is cut from.

        The bytes come from `git show <commit>:<path>`, so the pin names the
        revision the episode recorded rather than whatever the live tree holds
        while it may be dirty. An authority the commit cannot answer for is
        refused rather than skipped, because an episode whose authority carries
        no pin would run a step the record never covered. Git is read only
        here, which is what makes this a pin.
        """
        repo = self.repo.resolve()
        keys = {}
        for item in authorities:
            absolute = Path(item) if Path(item).is_absolute() else (repo / item)
            try:
                relative = absolute.resolve().relative_to(repo).as_posix()
            except ValueError:
                raise EpisodeRefused(
                    f"the authority {item} is outside the repository, so no commit revision "
                    f"can answer for it",
                    {"authority": str(item), "repository": str(repo), "commit": commit},
                )
            blob = git_text(self.repo, "rev-parse", f"{commit}:{relative}", required=False)
            if not blob:
                raise EpisodeRefused(
                    f"the authority {item} is absent from the commit {commit}, so it has no "
                    f"pinned revision",
                    {"authority": str(item), "commit": commit},
                )
            keys[item] = sha256_bytes(git_bytes(self.repo, "show", f"{commit}:{relative}"))
        return keys

    def _verify_authorities(self, worktree: Path, record) -> None:
        """Refuse a worktree whose authorities are not the pinned revisions.

        The pin came from the commit the worktree was cut from. Hashing the
        worktree bytes here proves the files the step is about to read are the
        ones the episode recorded, rather than a dirty live tree's revision.
        """
        pinned_keys = record.get("authority_keys") or {}
        for item in record.get("authorities", []):
            expected = pinned_keys.get(item)
            if not expected:
                raise EpisodeRefused(
                    f"the authority {item} has no pinned key stored, so the dispatched "
                    f"worktree cannot be verified against the episode",
                    {"authority": item},
                )
            candidate = Path(item)
            if candidate.is_absolute():
                raise EpisodeRefused(
                    "the pinned authority is outside the repository, so the dispatched "
                    "worktree cannot carry the revision this episode recorded",
                    {"authority": item},
                )
            path = worktree / item
            if not path.is_file():
                raise EpisodeRefused(
                    "an authority pinned at open is absent from the dispatched worktree",
                    {"authority": item, "worktree": str(worktree)},
                )
            actual = sha256_file(path)
            if actual != expected:
                raise EpisodeRefused(
                    "an authority in the dispatched worktree is not the pinned revision, so "
                    "the episode would run against an authority it never recorded",
                    {"authority": item, "pinned": expected, "worktree": actual},
                )

    def _verify_declaration(self, worktree: Path, record) -> None:
        """Refuse a worktree that does not carry the pinned declaration.

        The pin is taken from the commit the worktree is cut from, so a mismatch
        means the state and the worktree disagree about what the step read. A
        step against a revision the episode never recorded must not run.
        """
        pinned = record.get("declaration") or {}
        relative = pinned.get("path")
        expected = pinned.get("sha256")
        if not relative or not expected:
            return
        if Path(relative).is_absolute():
            raise EpisodeRefused(
                "the pinned declaration is outside the repository, so the dispatched worktree "
                "cannot carry the revision this episode recorded",
                {"declaration": relative},
            )
        path = worktree / relative
        if not path.is_file():
            raise EpisodeRefused(
                "the declaration pinned at open is absent from the dispatched worktree",
                {"declaration": relative, "worktree": str(worktree)},
            )
        actual = sha256_file(path)
        if actual != expected:
            raise EpisodeRefused(
                "the declaration in the dispatched worktree is not the pinned revision, so the "
                "episode would run against a declaration it never recorded",
                {"declaration": relative, "pinned": expected, "worktree": actual},
            )

    def _state_fingerprint(self) -> dict:
        """A content key for every path under the control plane's state directory.

        The live-tree state excludes this directory because the control plane
        writes its own records there. That exclusion covers the control plane,
        not the agent whose step produced a record, so dispatch fingerprints the
        directory before and after the runners and treats a move as a leak. The
        same walk runs here, so an empty directory left behind is a leak too.
        """
        return filesystem_fingerprint(self.state_dir)

    def _fingerprint_delta(self, before, after):
        return fingerprint_delta(before, after, prefix="state dir/")

    def _discard(self, episode):
        """Stop an open episode without the close check. Test cleanup only."""
        try:
            record = self._load(episode)
        except EpisodeRefused:
            return
        for entry in record["steps"]:
            self._remove_worktree(entry)
        self._state_path(episode).unlink(missing_ok=True)

    def _refuse_closed(self, record):
        if record.get("closed_at"):
            raise EpisodeRefused(f"episode {record['id']} was closed at {record['closed_at']}")

    def _declaration_relative(self):
        try:
            return self.declaration.relative_to(self.repo).as_posix()
        except ValueError:
            return None

    def _excluded(self, record=None):
        excluded = []
        try:
            self.state_dir.relative_to(self.repo)
            excluded.append(self.state_dir)
        except ValueError:
            pass
        # The registration path comes from git naming its own metadata, which is
        # a pin read.
        if record is not None:
            for entry in record.get("steps", []):
                registration = entry.get("registration")
                if registration and entry.get("worktree_removed_at") is None:
                    # A live registration is git metadata the control plane's own
                    # worktree verbs create and prune, so the pinned comparison
                    # leaves it and its contents out. Dispatch compares the same
                    # directory against the baseline taken straight after
                    # `worktree add`, so an entry no part of the control plane
                    # created there is still a finding.
                    excluded.append(Path(registration))
        return excluded

    def _state_path(self, episode):
        return self.state_dir / (self._episode_name(episode) + STATE_SUFFIX)

    def _lock_path(self, episode):
        return self.state_dir / (self._episode_name(episode) + ".lock")

    def _episode_name(self, episode):
        safe = re.sub(r"[^A-Za-z0-9._-]+", "-", str(episode)).strip("-")
        if not safe:
            raise EpisodeRefused("an episode needs an id usable as a filename")
        return safe

    def _episode_lock(self, episode):
        return _EpisodeLock(self._lock_path(episode), episode)

    def _load(self, episode, expect_id: bool = True):
        path = self._state_path(episode)
        if not path.exists():
            raise EpisodeRefused(f"episode {episode} has no state at {path}")
        if path.is_symlink():
            raise EpisodeRefused("the state directory holds a path the control plane did not create",
                                 {"path": str(path)})
        flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0)
        try:
            descriptor = os.open(str(path), flags)
        except OSError as exc:
            raise EpisodeRefused(
                f"episode {episode} state at {path} could not be opened",
                {"episode": str(episode), "path": str(path), "error": str(exc)},
            )
        try:
            if not stat.S_ISREG(os.fstat(descriptor).st_mode):
                raise EpisodeRefused(
                    f"episode {episode} state at {path} is not a regular file",
                    {"episode": str(episode), "path": str(path)},
                )
            blocks = []
            size = 0
            try:
                while True:
                    block = os.read(descriptor, 1 << 20)
                    if not block:
                        break
                    size += len(block)
                    if size > STATE_READ_LIMIT:
                        raise EpisodeRefused(
                            f"episode {episode} state at {path} is larger than the "
                            f"{STATE_READ_LIMIT // (1 << 20)} MiB read limit, so it was "
                            f"refused rather than held in memory",
                            {"episode": str(episode), "path": str(path)},
                        )
                    blocks.append(block)
            except OSError as exc:
                raise EpisodeRefused(
                    f"episode {episode} state at {path} could not be read as text",
                    {"episode": str(episode), "path": str(path), "error": str(exc)},
                )
        finally:
            os.close(descriptor)
        try:
            text = b"".join(blocks).decode("utf-8")
        except UnicodeDecodeError as exc:
            raise EpisodeRefused(
                f"episode {episode} state at {path} could not be read as text",
                {"episode": str(episode), "path": str(path), "error": str(exc)},
            )
        try:
            record = json.loads(text)
        except json.JSONDecodeError as exc:
            raise EpisodeRefused(
                f"episode {episode} state at {path} is not valid JSON",
                {"episode": str(episode), "path": str(path), "error": str(exc)},
            )
        except (RecursionError, OverflowError, ValueError) as exc:
            # A parser failure that is not a JSONDecodeError is a nesting or
            # size refusal, translated here so no verb sees an interpreter
            # exception from a state file.
            raise EpisodeRefused(
                f"episode {episode} state at {path} is JSON the parser could not finish: "
                f"{exc}",
                {"episode": str(episode), "path": str(path), "error": str(exc)},
            )
        if not isinstance(record, dict):
            raise EpisodeRefused(
                f"episode {episode} state at {path} is {type(record).__name__}, not a record",
                {"episode": str(episode), "path": str(path)},
            )
        try:
            root_key = record_root_key(record)
        except (UnicodeError, ValueError, TypeError) as exc:
            raise EpisodeRefused(
                f"episode {episode} state at {path} could not be keyed, so its root key "
                f"cannot be checked",
                {"episode": str(episode), "path": str(path), "error": str(exc)},
            )
        if record.get("root_key") != root_key:
            raise EpisodeRefused(
                "episode record root key does not match its content",
                {"episode": str(episode), "path": str(path)},
            )
        state_stat = os.stat(self._state_given)
        if [state_stat.st_dev, state_stat.st_ino] != record.get("state_identity"):
            raise EpisodeRefused(
                "the state directory is not the one this episode was opened in",
                {"episode": str(episode), "path": str(path)},
            )
        for field, kinds in STATE_REQUIRED_FIELDS:
            if not isinstance(record.get(field), kinds):
                raise EpisodeRefused(
                    f"episode {episode} state at {path} does not carry a {field} the "
                    f"control plane can read",
                    {"episode": str(episode), "path": str(path), "field": field},
                )
        # The name in the record has to be the episode that was asked for, so
        # every later write lands on this record's own path and never on the
        # path of an episode the record names instead. The close scan is the
        # one caller that asks with a file name rather than an episode, so it
        # turns the check off and maps the record's own id back to that name.
        if expect_id and record["id"] != episode:
            raise EpisodeRefused(
                f"episode {episode} state at {path} names the episode {record['id']!r}, "
                f"so it is not this episode's record",
                {"episode": str(episode), "path": str(path), "field": "id",
                 "record_id": record["id"]},
            )
        return record

    def _write(self, record):
        """Write the record through a unique temporary name in the same directory.

        The temporary name carries the episode, this process and random bytes,
        so the write can never land on a path another writer chose. A name
        that already exists is retried with fresh random bytes up to three
        times, because one accidental collision must not cost the record its
        durable copy; every write, including the write of a record that carries
        a refusal, goes through the same retry. Only three collisions in a row
        are refused, and the paths that caused them are named and left in
        place, because removing a path the control plane did not create is
        exactly what it must not do.
        """
        record["root_key"] = record_root_key(record)
        path = self._state_path(record["id"])
        attempted = []
        for _ in range(3):
            temp = path.with_name(f"{path.stem}.{os.getpid()}.{os.urandom(4).hex()}.tmp")
            attempted.append(str(temp))
            try:
                descriptor = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                                     0o600)
            except FileExistsError:
                continue
            except OSError as exc:
                raise EpisodeRefused(
                    f"the state record at {path} could not be written",
                    {"record": str(path), "temp": str(temp), "error": str(exc)},
                )
            try:
                with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
                    handle.write(json.dumps(record, indent=2, ensure_ascii=False) + "\n")
                os.replace(temp, path)
            except BaseException as exc:
                # The temporary file this write made goes with the failure, so
                # a refused write leaves no partial file beside the record.
                try:
                    temp.unlink(missing_ok=True)
                except OSError:
                    pass
                if isinstance(exc, OSError):
                    raise EpisodeRefused(
                        f"the state record at {path} could not be written",
                        {"record": str(path), "temp": str(temp), "error": str(exc)},
                    )
                raise
            if self._held_lock is not None:
                self._held_lock.write_seal(self.state_dir)
            return
        raise EpisodeRefused(
            "the state directory holds unexpected paths beside the record",
            {"paths": attempted, "record": str(path)},
        )


# ───────────────────────────────────────────────────────────────
# 12. CLI
# ───────────────────────────────────────────────────────────────

def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="The four-verb episode control plane.")
    parser.add_argument("--repo", default=str(DEFAULT_REPO))
    parser.add_argument("--state-dir", default=str(DEFAULT_STATE_DIR))
    parser.add_argument("--worktree-root", default=str(tempfile.gettempdir()))
    parser.add_argument("--runner-timeout", type=int, default=3600,
                        help="seconds a subprocess runner may run before its group is killed")
    sub = parser.add_subparsers(dest="verb", required=True)

    open_parser = sub.add_parser("open", help="pin the declaration revision, commit range and tree state")
    open_parser.add_argument("episode")
    open_parser.add_argument("--range", dest="commit_range", default="origin/main..HEAD")
    open_parser.add_argument("--authority", action="append", default=[])
    open_parser.add_argument("--note", default=None)

    dispatch_parser = sub.add_parser("dispatch", help="run one step in a worktree and differ it")
    dispatch_parser.add_argument("episode")
    dispatch_parser.add_argument("--step", required=True)
    dispatch_parser.add_argument("--declare", action="append", default=[])
    dispatch_parser.add_argument("--permit", action="append", default=[])
    dispatch_parser.add_argument("--run", required=True)
    dispatch_parser.add_argument("--family", action="append", default=[])

    adjudicate_parser = sub.add_parser("adjudicate", help="record the decision on a disagreement")
    adjudicate_parser.add_argument("episode")
    adjudicate_parser.add_argument("--step", required=True)
    adjudicate_parser.add_argument("--decision", required=True)
    adjudicate_parser.add_argument("--why", required=True)
    adjudicate_parser.add_argument("--operator", default=None)

    close_parser = sub.add_parser("close", help="check every carrier and release the worktrees")
    close_parser.add_argument("episode")
    close_parser.add_argument("--operator", default=None)

    args = parser.parse_args(argv)
    try:
        # Building the control plane raises the state root refusal, so the
        # construction waits behind the guard that answers it.
        control = EpisodeControl(repo=args.repo, state_dir=args.state_dir,
                                 worktree_root=args.worktree_root,
                                 runner_timeout=args.runner_timeout)
        if args.verb == "open":
            result = control.open(args.episode, args.commit_range, args.authority, args.note)
        elif args.verb == "dispatch":
            result = control.dispatch(args.episode, args.step, args.declare, args.run,
                                      families=args.family or None, permitted=args.permit)
        elif args.verb == "adjudicate":
            result = control.adjudicate(args.episode, args.step, args.decision, args.why,
                                        args.operator)
        else:
            result = control.close(args.episode, args.operator)
    except EpisodeRefused as exc:
        print(f"REFUSED: {exc.reason}", file=sys.stderr)
        if exc.evidence:
            print(json.dumps(exc.evidence, indent=2, ensure_ascii=False), file=sys.stderr)
        return 1
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
