---
title: "The four verbs: run record"
description: "Result of VERB-001 through VERB-006 as run on 2026-09-15"
version: 1.0.0.0
---

# The four verbs: run record

One episode, end to end, on the throwaway fixture at `/tmp/parity-playbook`, built once from the setup in `four-verbs/throwaway-episode.md` and left in place for the run. All six rows ran in order inside a single episode named `playbook-demo`, as the fixture setup and the fence below require.

The fence used for every row:

```
R=/tmp/parity-playbook/repo
C() { python3 "$R/AI Systems/z — Parity Gate/episode_control.py" --state-dir /tmp/parity-playbook/state --worktree-root /tmp/parity-playbook/wt "$@"; }
```

## VERB-001 open pins

Open pins the episode to a commit range and a declaration

| Field | Value |
|---|---|
| Command | `C open playbook-demo --range HEAD~1..HEAD` |
| Exit code | 0 |
| Expected line | Line 2 of the record: `  "id": "playbook-demo",` |
| Actual line | Line 2 of the record: `  "id": "playbook-demo",` |
| Verdict | PASS |
| Reason | Line 2 matches exactly and the exit code is 0 |
| Date | 2026-09-15 |

## VERB-002 dispatch accepts

Dispatch accepts a step that writes exactly its declared path

| Field | Value |
|---|---|
| Command | `C dispatch playbook-demo --step note --declare tracked.txt --run 'printf second pinned > tracked.txt; cat tracked.txt'` |
| Exit code | 0 |
| Expected line | The record carries `  "verdict": "accepted",` |
| Actual line | The record carries `  "verdict": "accepted",` |
| Verdict | PASS |
| Reason | The verdict line is present exactly as expected and the exit code is 0 |
| Date | 2026-09-15 |

## VERB-003 the refusal records

Dispatch refuses a step that produced no output

| Field | Value |
|---|---|
| Command | `C dispatch playbook-demo --step quiet --run 'printf second pinned > tracked.txt'` |
| Exit code | 1 |
| Expected line | stderr exactly `REFUSED: the step produced no output, and an empty result is a failure rather than a pass`, then the record carrying `  "verdict": "refused",` |
| Actual line | stderr carried exactly `REFUSED: the step produced no output, and an empty result is a failure rather than a pass` followed by the full record, which carries `  "verdict": "refused",` and names `tracked.txt` under `undeclared` |
| Verdict | PASS |
| Reason | The refusal text and the verdict field both match exactly and the exit code is 1 |
| Date | 2026-09-15 |

## VERB-004 the disagreement holds

A family disagreement holds the worktree open rather than closing it

| Field | Value |
|---|---|
| Command | `C dispatch playbook-demo --step pair --declare note.txt --run 'printf agreed > note.txt; cat note.txt' --family 'echo A' --family 'echo B'` |
| Exit code | 0 |
| Expected line | The record carries `  "verdict": "disagreement",` and `  "worktree_removed_at": null,` |
| Actual line | Both fields present exactly as expected |
| Verdict | PASS |
| Reason | Both expected fields match exactly and the exit code is 0 |
| Date | 2026-09-15 |

## VERB-005 the decision lands

Adjudicate records the operator's decision on the held disagreement

| Field | Value |
|---|---|
| Command | `C adjudicate playbook-demo --step pair --decision keep-first --why "the first wording is agreed" --operator playbook` |
| Exit code | 0 |
| Expected line | The disposition carries `    "decision": "keep-first",` |
| Actual line | The disposition carries `    "decision": "keep-first",` |
| Verdict | PASS |
| Reason | The decision field matches exactly and the exit code is 0 |
| Date | 2026-09-15 |

## VERB-006 close releases

Close releases the worktree and finalizes the record after the decision landed

| Field | Value |
|---|---|
| Command | Step 1: `C close playbook-demo --operator playbook`, step 2: `ls /tmp/parity-playbook/wt` |
| Exit code | Step 1: 0, step 2: 0 |
| Expected line | Step 1: the record carries `  "closed_by": "playbook",`, step 2: prints nothing |
| Actual line | Step 1: the record carries `  "closed_by": "playbook",`, step 2: printed nothing, the worktree root is empty |
| Verdict | PASS |
| Reason | Both signals match exactly, the worktree root is empty, and both exit codes are 0 |
| Date | 2026-09-15 |
