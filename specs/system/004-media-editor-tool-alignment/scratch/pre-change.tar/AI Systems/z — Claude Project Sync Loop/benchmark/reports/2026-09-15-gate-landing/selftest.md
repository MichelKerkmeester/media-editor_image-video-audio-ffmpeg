---
title: "The selftest wrapper: run record"
description: "Result of SELF-001 and SELF-002 as run on 2026-09-15"
version: 1.0.0.0
---

# The selftest wrapper: run record

Run strictly sequential, as precondition 3 requires, with no other proof-family run overlapping.

## SELF-001 every mechanism accepts the clean path

| Field | Value |
|---|---|
| Command | `python3 "AI Systems/z — Parity Gate/episode_selftest.py"` |
| Exit code | 0 |
| Expected line | One line per mechanism, then exactly `PASS: all 54 mechanisms accept the clean path`, about 80 seconds |
| Actual line | One line per mechanism (62 lines), then `PASS: all 62 mechanisms accept the clean path`, total wall time 1 minute 24.9 seconds |
| Verdict | FAIL |
| Reason | The exit code matched at 0 but the verdict line reports 62 mechanisms rather than the expected 54, so the last printed line does not match the expected line |
| Date | 2026-09-15 |

## SELF-002 the injected leak fault is caught

| Field | Value |
|---|---|
| Command | `python3 "AI Systems/z — Parity Gate/episode_selftest.py" --inject leak` |
| Exit code | 1 |
| Expected line | Ends `FAULT CAUGHT: the live tree moved outside the worktree, the step was refused and the worktree was discarded`, then `the injected leak fault was caught, so this run exits non-zero` |
| Actual line | `FAULT CAUGHT: the live tree moved outside the worktree, the step was refused and the worktree was discarded` followed by `the injected leak fault was caught, so this run exits non-zero` |
| Verdict | PASS |
| Reason | Both closing lines match the expected text exactly and the exit code is 1 |
| Date | 2026-09-15 |

## SELF-001 re-run after the expectation was corrected

The first run's FAIL was not a defect in the gate. The playbook's own note on this row already said the count tracks `SCENARIOS`, and the row then wrote a figure that went stale when the fourth review round added mechanisms. The expected line now states the rule instead of a number, and the scenario was run again.

| Field | Value |
|---|---|
| Command | `python3 "AI Systems/z — Parity Gate/episode_selftest.py"` |
| Exit code | 0 |
| Expected line | One line per mechanism, then exactly `PASS: all N mechanisms accept the clean path` where N is the number of entries in `SCENARIOS` |
| Entries in `SCENARIOS` | 62 |
| Actual line | 62 lines, one per mechanism, then `PASS: all 62 mechanisms accept the clean path`, 83 seconds |
| Verdict | PASS |
| Reason | The count printed equals the count the module declares, and the exit code is 0 |
| Date | 2026-09-15 |
