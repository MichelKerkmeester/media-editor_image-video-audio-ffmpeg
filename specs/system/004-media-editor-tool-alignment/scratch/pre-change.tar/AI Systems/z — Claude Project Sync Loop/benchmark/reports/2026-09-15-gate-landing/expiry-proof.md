---
title: "The expiry proof: run record"
description: "Result of EXP-001 as run on 2026-09-15"
version: 1.0.0.0
---

# The expiry proof: run record

Run alone, after both selftest runs completed, per precondition 3.

## EXP-001 review expiry proof

An expired recorded review key fails on demand even with timestamps agreeing

| Field | Value |
|---|---|
| Command | `python3 "AI Systems/z — Parity Gate/prove_review_expiry.py"` |
| Exit code | 0 |
| Expected line | `step 2  baseline, gate as declared: green`, `step 3  record repointed at cafebabe: red` with the finding ` - standards.md: a review was recorded at cafebabe and the source's latest commit is 3b38f2ff, so the recorded decision no longer covers it`, `step 5  after restore, gate as declared again: green`, then exactly `PASS green, red, green: the key comparison turned barter-copywriter red with the timestamp guard silent, and the restored declaration is green again` |
| Actual line | All five step lines, the finding, and the final PASS line matched the expected text exactly |
| Verdict | PASS |
| Reason | Every expected signal appeared exactly as stated and the exit code is 0 |
| Date | 2026-09-15 |

### Caveat

After the run finished, an untracked, empty lock file was left behind at `AI Systems/z — Parity Gate/systems.py.review-expiry.lock`. This is not one of the expected signals and is not covered by the pass or fail criteria, but it contradicts the playbook's own claim in section 2 that "nothing here is destructive: the proof restores". The declaration file itself was restored correctly and `git status` showed no tracked changes. The stray lock file carried no content and was removed after being recorded here, so it would not block a future run under precondition 3.
