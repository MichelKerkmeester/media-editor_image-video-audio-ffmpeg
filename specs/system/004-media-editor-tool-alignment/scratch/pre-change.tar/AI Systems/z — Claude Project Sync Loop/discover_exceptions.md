# Discovery exceptions

One glob per tracked line below, matched against the full repo-relative path
with `**` standing for zero or more path segments. `discover` reads this file
fresh on every pass and reports only a markdown document that matches no
declared pair, no declared unmirrored source, and no glob here. A document
that still matches nothing is a real gap, and `discover` still exits 1 on it.

No line here names a path under `z — Knowledge/` or a `references/`
directory. Those are knowledge or reference documents, and a gap there is a
finding, never an exception.

`carrier_query.py` reads only the fenced block below, one glob per line, so
prose above and below it is never mistaken for an entry.

```
**/README.md  # project and skill orientation, not a pair document
**/SKILL.md  # skill entrypoint read by the runtime, not a pair document
**/SYNC.md  # sync operating notes, not a pair document
**/SYNC-HISTORY.md  # dated sync notes moved out of SYNC.md, not a pair document
**/AGENTS.md  # agent operating notes, not a pair document
**/changelog/*.md  # dated changelog entries, not pair documents
**/benchmark/**/*.md  # benchmark notes, fixtures, grader assets and reports
```
