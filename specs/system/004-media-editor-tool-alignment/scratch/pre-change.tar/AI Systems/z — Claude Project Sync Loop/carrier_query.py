#!/usr/bin/env python3
# ───────────────────────────────────────────────────────────────
# COMPONENT: CARRIER QUERY
# ───────────────────────────────────────────────────────────────
"""Five index builders and a discovery pass over the parity gate's declared universe.

The declared universe is `systems.py`: a system id, its pairs (a Project mirror
filename mapped to the skill-relative source it renders), the deliberate
exceptions beside them, and each system's kernel, skill entrypoint and READMEs.
Every index here walks that same declaration rather than re-deriving one from
the filesystem, for the reason `systems.py` itself gives: a derived map that
silently matches nothing still passes, which is worse than no check at all.

A document is an authority the moment `systems.py` names it, whether or not it
has a Project mirror of its own: a pair's source, a pair's mirror, a
deliberately unmirrored source, or a system's `claude project/Custom
Instructions.md`, `SKILL.md` or README. Only a pair's source and mirror ever
carry a disposition, because only those have a second copy to compare. The
rest still feed the pointers, duplicates and tokens indexes, so a rule stated
in a kernel or a README still routes to every mirror that repeats it.

Each pair is identified the way `systems.py` already identifies it in
`reviewed_pairs`, `forked_shared_copies`, `unmirrored_sources` and
`adapted_pairs`: by its skill-relative source path. An index keyed by system
id and that pair identity lets a reader ask "what does this declaration say
about this one pair" without re-deriving anything.

The declaration is read as source text with bytecode disabled, the way the
shared gate reads it, so an edit in the same second as a stale cache cannot
answer from a `systems.py` that is no longer on disk. The content-key and
canonical-bytes helpers are the control plane's own, imported rather than
reimplemented, so a key computed here and a key computed by the control plane
agree on what "the same content" means.

Usage:
    python3 carrier_query.py index bindings
    python3 carrier_query.py index pointers
    python3 carrier_query.py index fanout
    python3 carrier_query.py index duplicates
    python3 carrier_query.py index tokens --range BASE..HEAD
    python3 carrier_query.py discover

Exit codes:
    0  the command printed its result (an index, or a discovery pass with
       nothing unnamed)
    1  discover found a markdown document the declaration does not name
"""

# ───────────────────────────────────────────────────────────────
# 1. IMPORTS AND CONSTANTS
# ───────────────────────────────────────────────────────────────

from __future__ import annotations

import argparse
import json
import os
import re
import sys
from dataclasses import dataclass
from pathlib import Path

HERE = Path(__file__).resolve().parent
SYSTEMS_ROOT = HERE.parent
REPO_ROOT = HERE.parent.parent
KNOWLEDGE_ROOT = SYSTEMS_ROOT / "z — Knowledge"
DECLARATION = HERE / "systems.py"

# ───────────────────────────────────────────────────────────────
# 2. DECLARATION LOADING
# ───────────────────────────────────────────────────────────────
# Read as source text below, never imported, for the reason `validate_parity.py`
# gives beside its own `sys.dont_write_bytecode = True`: an import can answer
# from bytecode cached by path and by a modification time truncated to the
# second, which makes an edit in that same second invisible.
sys.dont_write_bytecode = True
sys.path.insert(0, str(HERE))
import episode_control as ec  # noqa: E402  the import follows the sys.path change


def load_declaration(path: Path) -> dict:
    """Execute a declaration module from source text, never from cached bytecode."""
    namespace = {"__file__": str(path), "__name__": path.stem}
    exec(compile(path.read_text(encoding="utf-8"), str(path), "exec"), namespace)
    return namespace["SYSTEMS"]


SYSTEMS = load_declaration(DECLARATION)


def lexical_relative(path: Path) -> str:
    """A repo-relative path built from the join, never from a resolved symlink.

    `Path.resolve()` would follow a source that is itself a symlink to its
    target, which is the wrong answer here: the pair identity is the symlink's
    own location in the skill tree, not the shared card it points at.
    """
    return path.relative_to(REPO_ROOT).as_posix()


# The declaration's repo-relative path is fixed at import, because a walk can
# be redirected to an archived tree while the declaration itself still lives
# in the gate directory beside this module.
DECLARATION_REL = lexical_relative(DECLARATION)


def realpath_relative(path: Path) -> str | None:
    """A repo-relative path for a symlink target, with both sides resolved first.

    A temporary tree can sit behind a prefix that is itself a symlink, and
    resolving only the target would leave the two spellings of one location
    unable to meet. The lexical symlink is untouched; only a target's real
    location is compared, against the root's own real location.
    """
    try:
        return Path(os.path.realpath(path)).relative_to(Path(os.path.realpath(REPO_ROOT))).as_posix()
    except ValueError:
        return None


# ───────────────────────────────────────────────────────────────
# 3. PAIR AND AUTHORITY REFERENCES
# ───────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class PairRef:
    system_id: str
    display_name: str
    skill_rel: str
    mirror_name: str
    source: Path
    mirror: Path


MIRROR_VERSION_SUFFIX = re.compile(r"(.*) - v[\d.]+\.md$")


def resolve_mirror_path(knowledge_dir: Path, mirror_name: str) -> Path:
    """The declared mirror path, or, when that exact name is not on disk, the
    one file in the same directory that matches it on everything but a
    `- vN.N.N` version suffix.

    A version bump renames the mirror on disk in the same commit that bumps
    the declared name everywhere else. A replay of an older tree still
    carries the old name, and a live tree mid-rename can too, and neither is
    an absent mirror: it is the same document under the suffix it wore then.
    This runs the same way regardless of whether `knowledge_dir` is the live
    tree or an archived one, so a historical replay never reports `unmapped`
    for a rename either way.
    """
    declared = knowledge_dir / mirror_name
    if declared.is_file() or not knowledge_dir.is_dir():
        return declared
    declared_match = MIRROR_VERSION_SUFFIX.match(mirror_name)
    if not declared_match:
        return declared
    prefix = declared_match.group(1)
    candidates = [
        path for path in knowledge_dir.iterdir()
        if path.is_file() and (m := MIRROR_VERSION_SUFFIX.match(path.name)) and m.group(1) == prefix
    ]
    return candidates[0] if len(candidates) == 1 else declared


def iter_pairs():
    """Every declared pair, system by system, in the declaration's own order."""
    for system_id, decl in sorted(SYSTEMS.items()):
        system_dir = SYSTEMS_ROOT / decl["system_dir"]
        skill_root = system_dir / decl["skill_dir"]
        knowledge_dir = system_dir / "claude project" / "knowledge"
        for mirror_name, skill_rel in sorted(decl["pairs"].items()):
            yield PairRef(
                system_id=system_id,
                display_name=decl["display_name"],
                skill_rel=skill_rel,
                mirror_name=mirror_name,
                source=skill_root / skill_rel,
                mirror=resolve_mirror_path(knowledge_dir, mirror_name),
            )


def shared_card(ref: PairRef) -> Path | None:
    """The card in `z — Knowledge/` a pair source stands for, or None.

    A symlink names its card by where it points. A system that also ships as
    its own repository carries the card as a regular-file copy, because a link
    that climbs out of that repository resolves to nothing once it is cloned,
    and its declaration names the card in `vendored_shared_copies`. Both are
    shared in every sense this query uses. A copy nobody declared stays an
    owned source, because a source that only looks shared is exactly the case
    that must not be reported as reached.
    """
    if ref.source.is_symlink():
        return Path(os.path.realpath(ref.source))
    card = SYSTEMS[ref.system_id].get("vendored_shared_copies", {}).get(ref.skill_rel)
    return KNOWLEDGE_ROOT / card if card else None


def shared_card_relative(ref: PairRef) -> str | None:
    """The repo-relative path of a pair's shared card, or None."""
    card = shared_card(ref)
    return realpath_relative(card) if card is not None else None


def keyed(payload: dict) -> dict:
    """Attach the content key the brief requires, over the payload as it stands."""
    payload["content_key"] = ec.content_key(payload)
    return payload


@dataclass(frozen=True)
class AuthorityDoc:
    """One document `systems.py` declares as an authority.

    A pair's source and mirror carry a disposition. A deliberately unmirrored
    source, a system's kernel, its `SKILL.md` and its READMEs never do: they
    have no second copy to compare against. All of them still feed the
    pointers, duplicates and tokens indexes, so a rule stated only in one of
    them still reaches every mirror that repeats it.
    """
    system_id: str
    role: str
    doc_id: str
    path: Path
    pair_skill_rel: str


def system_authority_paths(decl: dict) -> dict:
    """The kernel, skill entrypoint and READMEs one system declares.

    Built the same way `iter_pairs` builds a pair's own paths: joined from
    `system_dir` and `skill_dir`, never derived by searching the tree, so a
    system with no README on disk yet is still named rather than silently
    skipped.
    """
    system_dir = SYSTEMS_ROOT / decl["system_dir"]
    skill_root = system_dir / decl["skill_dir"]
    return {
        "kernel": system_dir / "claude project" / "Custom Instructions.md",
        "skill-md": skill_root / "SKILL.md",
        "readme-system": system_dir / "README.md",
        "readme-skill": skill_root / "README.md",
        "readme-project": system_dir / "claude project" / "README.md",
    }


NON_PAIR_ROLES = ("unmirrored-source", "kernel", "skill-md", "readme-system", "readme-skill", "readme-project")
# A changed kernel, SKILL.md or README has no mirror of its own, but every
# pair beside it in the same system still reads it, so it routes that whole
# system's pairs as carriers.
SYSTEM_PAIR_ROLES = ("kernel", "skill-md", "readme-system", "readme-skill", "readme-project")


def iter_authority_docs():
    """Every document the declaration treats as an authority, pair and non-pair alike."""
    for ref in iter_pairs():
        yield AuthorityDoc(ref.system_id, "pair-source", f"source:{ref.skill_rel}", ref.source, ref.skill_rel)
        yield AuthorityDoc(ref.system_id, "pair-mirror", f"mirror:{ref.skill_rel}", ref.mirror, ref.skill_rel)
    for system_id, decl in sorted(SYSTEMS.items()):
        skill_root = SYSTEMS_ROOT / decl["system_dir"] / decl["skill_dir"]
        for rel in sorted(decl.get("unmirrored_sources", {})):
            yield AuthorityDoc(system_id, "unmirrored-source", f"unmirrored:{rel}", skill_root / rel, "")
        for role, path in system_authority_paths(decl).items():
            yield AuthorityDoc(system_id, role, role, path, "")


# ───────────────────────────────────────────────────────────────
# 4. BINDINGS
# ───────────────────────────────────────────────────────────────

def bindings(rev_range=None) -> dict:
    """Which mirror each source maps to, from the declaration's pairs."""
    systems: dict = {}
    for ref in iter_pairs():
        systems.setdefault(ref.system_id, {})[ref.skill_rel] = {
            "mirror": ref.mirror_name,
            "source_path": lexical_relative(ref.source),
            "mirror_path": lexical_relative(ref.mirror),
            "symlink": ref.source.is_symlink(),
            "shared": shared_card(ref) is not None,
        }
    return keyed({"kind": "bindings", "systems": systems})


# ───────────────────────────────────────────────────────────────
# 5. POINTERS
# ───────────────────────────────────────────────────────────────

FRONTMATTER_BLOCK = re.compile(r"^---\s*\n(.*?\n)---\s*\n", re.DOTALL)
FRONTMATTER_TITLE = re.compile(r"^\s*title\s*:\s*(.+?)\s*$", re.IGNORECASE | re.MULTILINE)
HEADING_LINE = re.compile(r"^#{1,2}\s+(.+?)\s*#*\s*$", re.MULTILINE)


def extract_frontmatter_title(text: str) -> str:
    """A YAML frontmatter `title:` field, read from the block alone, never
    from prose that happens to start a line the same way further down."""
    block = FRONTMATTER_BLOCK.match(text)
    if not block:
        return ""
    match = FRONTMATTER_TITLE.search(block.group(1))
    return match.group(1).strip("\"'") if match else ""


def extract_headings(text: str) -> list:
    """Every level-1 and level-2 heading, the levels a person names a
    document or a major section by, not the finer subsection numbering
    that would flood the title vocabulary with fragments."""
    return [match.group(1).strip() for match in HEADING_LINE.finditer(text)]


GENERIC_TITLES = {"readme", "skill", "sync", "agents"}


def declared_titles() -> dict:
    """Every declared document title, mapped to the pair(s) or shared card it names.

    A Project mirror's own filename, minus its extension, is the title a
    hand-authored cross-reference cites. Every declared document, a pair's
    source and mirror included, contributes its filename the same way, plus
    its own frontmatter title and its level-1 and level-2 headings, since a
    source title mentioned by another document must be a hit whether or not
    that document happens to be a pair. A shared card's canonical title is
    its filename under `z — Knowledge/`, which is what a source cites when
    the cross-reference carries no per-system prefix at all.

    A title this generic across the whole fleet, `README`, `SKILL`, `SYNC`,
    `AGENTS`, or a title shorter than three words, is not specific enough to
    be a pointer target: it names too little to say a citation of it means
    anything, and registering it would route nearly the entire fleet off one
    coincidental word.
    """
    titles: dict = {}

    def add(title: str, target: dict) -> None:
        if not title:
            return
        if title.strip().lower() in GENERIC_TITLES:
            return
        if len(title.split()) < 3:
            return
        titles.setdefault(title, []).append(target)

    for doc in iter_authority_docs():
        target = {"system": doc.system_id, "pair": doc.pair_skill_rel, "doc": doc.role, "doc_id": doc.doc_id}
        stem = doc.path.name[:-3] if doc.path.name.endswith(".md") else doc.path.name
        add(stem, target)
        if doc.path.is_file():
            text = doc.path.read_text(encoding="utf-8", errors="replace")
            add(extract_frontmatter_title(text), target)
            for heading in extract_headings(text):
                add(heading, target)
    if KNOWLEDGE_ROOT.is_dir():
        for path in sorted(KNOWLEDGE_ROOT.glob("*.md")):
            add(path.stem, {"knowledge": path.name})
    return titles


def declared_paths() -> dict:
    """Every declared repo path, mapped to the document it identifies."""
    paths: dict = {}

    def add(key: str, target: dict) -> None:
        if key:
            paths.setdefault(key, []).append(target)

    for doc in iter_authority_docs():
        target = {"system": doc.system_id, "pair": doc.pair_skill_rel, "doc": doc.role, "doc_id": doc.doc_id}
        if doc.role == "pair-source":
            add(doc.pair_skill_rel, target)
        add(lexical_relative(doc.path), target)
        if doc.role in NON_PAIR_ROLES:
            add(doc.path.name, target)
    return paths


MARKDOWN_LINK = re.compile(r"\[([^\]]*)\]\(\s*<?([^)\s>]+)>?\s*\)")


def markdown_link_destinations(text: str) -> list:
    """Every markdown link destination in a line, kept as written, so a
    comparison can see where a pointer points instead of only what it says."""
    return [match.group(2).strip() for match in MARKDOWN_LINK.finditer(text)]


def canonical_link_target(doc_rel: str, destination: str) -> str | None:
    """A markdown link destination resolved against the document that
    declares it, as a canonical repo-relative path, or `None`.

    A destination that names its target relatively points at the same
    document an absolute declared path names, so `./interactive-responses.md`
    inside a skill file and the declared path list's own entry for that file
    are one address. An external URL, a bare anchor and a destination that
    climbs above the repository root resolve to nothing.
    """
    target = destination.split("#", 1)[0].split("?", 1)[0].strip().strip("<>")
    if not target or "://" in target or target.startswith("mailto:"):
        return None
    if target.startswith("/"):
        joined = target.lstrip("/")
    elif "/" in doc_rel:
        joined = doc_rel.rsplit("/", 1)[0] + "/" + target
    else:
        joined = target
    segments = []
    for segment in joined.split("/"):
        if segment in ("", "."):
            continue
        if segment == "..":
            if not segments:
                return None
            segments.pop()
            continue
        segments.append(segment)
    return "/".join(segments) if segments else None


def title_boundary_pattern(title: str) -> re.Pattern:
    """A declared title matched only on a word boundary, never as a bare
    substring of a longer word or a longer title that happens to contain it."""
    return re.compile(r"(?<![A-Za-z0-9_])" + re.escape(title) + r"(?![A-Za-z0-9_])")


def pointers(rev_range=None) -> dict:
    """Every cross-reference from one declared document to another.

    Found by scanning every declared document's bytes, not only a pair's
    source and mirror, for every other declared title, on a word boundary,
    and repo path, as a literal substring, that document does not itself
    name, and for every markdown link destination resolved relative to the
    document that declares it, so a pointer written relatively reaches the
    same document its absolute declared path names. A title or path that
    matches more than one pair is reported with every candidate it names,
    since a citation shared by several systems' wording is real information,
    not noise to collapse.
    """
    titles = declared_titles()
    paths = declared_paths()
    title_keys = sorted(titles, key=len, reverse=True)
    title_patterns = {title: title_boundary_pattern(title) for title in title_keys}
    path_keys = sorted(paths, key=len, reverse=True)
    systems: dict = {}
    for doc in iter_authority_docs():
        entry = systems.setdefault(doc.system_id, {}).setdefault(doc.doc_id, {
            "role": doc.role, "pair": doc.pair_skill_rel, "path": lexical_relative(doc.path), "found": [],
        })
        if not doc.path.is_file():
            continue
        text = doc.path.read_text(encoding="utf-8", errors="replace")
        found = entry["found"]

        def other_targets(candidates: list) -> list:
            return [
                target for target in candidates
                if (target.get("system"), target.get("doc_id")) != (doc.system_id, doc.doc_id)
            ]

        for title in title_keys:
            if title_patterns[title].search(text):
                targets = other_targets(titles[title])
                if targets:
                    found.append({"match": "title", "text": title, "targets": targets})
        for path_str in path_keys:
            if len(path_str) >= 6 and path_str in text:
                targets = other_targets(paths[path_str])
                if targets:
                    found.append({"match": "path", "text": path_str, "targets": targets})
        doc_rel = lexical_relative(doc.path)
        already_found = {entry["text"] for entry in found if entry["match"] == "path"}
        for target_rel in sorted({
            resolved for raw in markdown_link_destinations(text)
            if (resolved := canonical_link_target(doc_rel, raw)) and resolved in paths
        } - already_found):
            targets = other_targets(paths[target_rel])
            if targets:
                found.append({"match": "path", "text": target_rel, "targets": targets})
    return keyed({"kind": "pointers", "systems": systems})


# ───────────────────────────────────────────────────────────────
# 6. FANOUT
# ───────────────────────────────────────────────────────────────

def fanout(rev_range=None) -> dict:
    """Every Project copy a change to a file under `z — Knowledge/` reaches.

    Found by following the symlink each declared pair's source names, never by
    matching filenames, because a source that only looks shared is exactly the
    case that must not be reported as reached.
    """
    knowledge_real = Path(os.path.realpath(KNOWLEDGE_ROOT))
    reached: dict = {}
    for ref in iter_pairs():
        card = shared_card(ref)
        if card is None:
            continue
        target = Path(os.path.realpath(card))
        try:
            target_rel = target.relative_to(knowledge_real).as_posix()
        except ValueError:
            continue
        reached.setdefault(target_rel, []).append({
            "system": ref.system_id,
            "pair": ref.skill_rel,
            "source_path": lexical_relative(ref.source),
            "mirror_path": lexical_relative(ref.mirror),
        })
    return keyed({"kind": "fanout", "knowledge": reached})


# ───────────────────────────────────────────────────────────────
# 7. DUPLICATES
# ───────────────────────────────────────────────────────────────

FRONTMATTER_END = re.compile(r"\n---\s*\n")
SENTENCE_SPLIT = re.compile(r"(?<=[.!?])\s+|\n+")
MARKUP = re.compile(r"[`*_>#]")
WHITESPACE = re.compile(r"\s+")
TABLE_RULE = re.compile(r"^\|?[\s:|-]+\|?$")
ALPHA = re.compile(r"[a-zA-Z]")
MIN_SENTENCE = 30
MIN_ALPHA = 15


def normalise_sentence(text: str) -> str:
    return WHITESPACE.sub(" ", MARKUP.sub("", text)).strip().lower()


def sentences_of(text: str):
    if text.startswith("---"):
        match = FRONTMATTER_END.search(text, 3)
        if match:
            text = text[match.end():]
    for raw in SENTENCE_SPLIT.split(text):
        # A markdown table's own rule row is punctuation, not a rule, and a
        # normalised sentence with too few letters is closer to a divider or a
        # tokenised value list than to a stated rule.
        if TABLE_RULE.match(raw.strip()):
            continue
        norm = normalise_sentence(raw)
        if len(norm) < MIN_SENTENCE or len(ALPHA.findall(norm)) < MIN_ALPHA:
            continue
        yield norm


def sentences_with_context(text: str):
    """Every stated sentence and the normalised non-empty line immediately
    above it, by the same split and gates `sentences_of` applies.

    A sentence alone is not enough to pair two documents: the same sentence
    under a different heading states a different rule. The line above it is
    the cheapest context that tells the two apart, and it is read from the
    same document text the sentence itself came from.
    """
    if text.startswith("---"):
        match = FRONTMATTER_END.search(text, 3)
        if match:
            text = text[match.end():]
    before = ""
    for line in text.splitlines():
        for raw in SENTENCE_SPLIT.split(line):
            # A markdown table's own rule row is punctuation, not a rule, and a
            # normalised sentence with too few letters is closer to a divider or a
            # tokenised value list than to a stated rule.
            if TABLE_RULE.match(raw.strip()):
                continue
            norm = normalise_sentence(raw)
            if len(norm) < MIN_SENTENCE or len(ALPHA.findall(norm)) < MIN_ALPHA:
                continue
            yield norm, before
        if line.strip():
            before = normalise_sentence(line)


def duplicates(rev_range=None) -> dict:
    """The same rule stated in more than one system, by normalised sentence match.

    A pair whose source is a symlink into `z — Knowledge/` is single-sourced on
    purpose, and its mirror is a declared byte-identical copy of that same
    source, so every sentence in either would match across every system that
    shares it without saying anything a person does not already know. Only
    owned pairs, the ones `validate_parity.py` calls owned for the same reason,
    are scanned from the pair set. A kernel, `SKILL.md`, README or deliberately
    unmirrored source carries no such exception and is scanned too, so a rule
    stated only there still surfaces as a duplicate of the pair that repeats it.
    """
    sites: dict = {}
    for ref in iter_pairs():
        if shared_card(ref) is not None:
            continue
        for doc_kind, doc_path in (("source", ref.source), ("mirror", ref.mirror)):
            if not doc_path.is_file() or doc_path.is_symlink():
                continue
            text = doc_path.read_text(encoding="utf-8", errors="replace")
            for sentence, before in sentences_with_context(text):
                sites.setdefault(sentence, []).append({
                    "system": ref.system_id,
                    "pair": ref.skill_rel,
                    "doc": doc_kind,
                    "path": lexical_relative(doc_path),
                    "before": before,
                })
    for doc in iter_authority_docs():
        if doc.role not in NON_PAIR_ROLES:
            continue
        if not doc.path.is_file() or doc.path.is_symlink():
            continue
        text = doc.path.read_text(encoding="utf-8", errors="replace")
        for sentence, before in sentences_with_context(text):
            sites.setdefault(sentence, []).append({
                "system": doc.system_id,
                "pair": doc.pair_skill_rel,
                "doc": doc.role,
                "path": lexical_relative(doc.path),
                "before": before,
            })
    found: dict = {}
    for sentence, site_list in sites.items():
        systems_seen = sorted({site["system"] for site in site_list})
        if len(systems_seen) < 2:
            continue
        digest = ec.sha256_bytes(sentence.encode("utf-8"))[:16]
        found[digest] = {"sentence": sentence, "systems": systems_seen, "sites": site_list}
    return keyed({"kind": "duplicates", "sentences": found})


# ───────────────────────────────────────────────────────────────
# 8. TOKENS
# ───────────────────────────────────────────────────────────────

# A digit group may repeat with a comma or a full stop in front of it, so
# 15,000 and the Dutch 15.000 both read as one value, and an optional
# trailing plus reads as part of the same value rather than being left
# beside it unmatched.
NUMERIC_TOKEN = re.compile(
    r"(?P<value>[<>]=?\s*\d+(?:[.,]\d+)*\+?(?:\s*-\s*\d+(?:[.,]\d+)*\+?)?%?"
    r"|\d+(?:[.,]\d+)*\+?(?:\s*-\s*\d+(?:[.,]\d+)*\+?)?%?)"
)
SEPARATOR = re.compile(r"[.,]")
# A genuine thousands separator is a comma or a full stop with exactly three
# digits after it and a digit before it. A separator followed by fewer digits
# is a decimal point and stays, so 1.5 and 15 never fold to the same value.
THOUSANDS_SEPARATOR = re.compile(r"(?<=\d)[.,](?=\d{3}(?!\d))")
LABEL_STRIP = re.compile(r"[`*_>#|]")
# A markdown ordered-list marker, "1. " or "2) ", or a numbered heading, "## 3.
# FOUNDING STORY", numbers the line or the section rather than stating a
# threshold, count or band, and every rewritten list or renumbered heading
# would otherwise report its own numbering as a moved token.
ORDINAL_MARKER = re.compile(r"^\s*#{0,6}\s*(\d+)[.)]\s")


def label_before(line: str, start: int) -> str:
    before = LABEL_STRIP.sub("", line[:start]).strip(" -:")
    return " ".join(before.split()[-6:]).lower()


def extract_tokens(diff_text: str, sign: str) -> list:
    found = []
    for line in diff_text.splitlines():
        if not line.startswith(sign) or line.startswith(sign * 3):
            continue
        content = line[1:]
        marker = ORDINAL_MARKER.match(content)
        for match in NUMERIC_TOKEN.finditer(content):
            if marker and (match.start(), match.end()) == (marker.start(1), marker.end(1)):
                continue
            found.append({
                "label": label_before(content, match.start()),
                "value": re.sub(r"\s+", "", match.group("value")),
                "line": content.strip(),
            })
    return found


STRUCTURAL_LINE = re.compile(r'^[\s\-*+>]*["\']?[A-Za-z][A-Za-z0-9_]{0,30}:\s')
CODE_LIKE_LINE = re.compile(r'==|!=|\+=|:=|\{\}|\(\)|^\s*(if|elif|else|return|def|class|for|while)\b')
HEADING_OR_COMMENT_LINE = re.compile(r'^\s*(#{1,6}\s|<!--)')


def is_structural_line(line: str) -> bool:
    """A frontmatter-style `key: value` line, a heading, an HTML comment, or
    a fragment of embedded code.

    None of those is a stated rule. A version stamp or a title field, in a
    heading or in a frontmatter line, is expected to read differently in a
    Project mirror than in its skill source, a source-only comment carries no
    reader-facing content at all, and a line of code reformatted across more
    or fewer lines is not the same as a line deleted. Treating any of them as
    a removed or added rule floods the checker with the kind of noise a
    corpus this size guarantees by coincidence.
    """
    return bool(
        STRUCTURAL_LINE.match(line) or CODE_LIKE_LINE.search(line) or HEADING_OR_COMMENT_LINE.match(line)
    )


def extract_sentences(diff_text: str, sign: str) -> list:
    """Every stated rule an added or removed diff line carries, by the same
    normalised-sentence rule `sentences_of` applies to a whole document."""
    found = []
    for line in diff_text.splitlines():
        if not line.startswith(sign) or line.startswith(sign * 3):
            continue
        content = line[1:]
        if is_structural_line(content):
            continue
        found.extend(sentences_of(content))
    return found


def digits_of(value: str) -> str:
    """A token's value with every genuine thousands separator removed, so
    15,000+ and the Dutch 15.000+ compare as the same digits. A separator a
    decimal point uses is kept, so 1.5 and 15 never compare equal.
    """
    return THOUSANDS_SEPARATOR.sub("", value)


def value_pattern(value: str) -> re.Pattern:
    """This token's value as a regex where each thousands separator reads as
    a comma or a full stop, so a search against a mirror written in the
    other convention still finds the digits this token carries.
    """
    groups = SEPARATOR.split(value)
    if len(groups) == 1:
        return re.compile(re.escape(value))
    return re.compile("[.,]".join(re.escape(group) for group in groups))


def pair_tokens(removed: list, added: list) -> dict:
    """Match a removed token against an added one by the label in front of it.

    A number a commit moved keeps its label, "conditional band" or "fail
    floor", while its value changes. A label seen on only one side of the diff
    is a token that appeared or disappeared, not one that moved. Values are
    compared by their digits alone, so a separator style rewritten without a
    digit changing is not reported as a moved value.
    """
    removed_by_label: dict = {}
    added_by_label: dict = {}
    for item in removed:
        removed_by_label.setdefault(item["label"], []).append(item)
    for item in added:
        added_by_label.setdefault(item["label"], []).append(item)
    moved, removed_only, added_only = [], [], []
    for label in sorted(set(removed_by_label) | set(added_by_label)):
        before_items = removed_by_label.get(label, [])
        after_items = added_by_label.get(label, [])
        for before_item, after_item in zip(before_items, after_items):
            if digits_of(before_item["value"]) != digits_of(after_item["value"]):
                moved.append({
                    "label": label,
                    "before": before_item["value"],
                    "after": after_item["value"],
                    "before_line": before_item["line"],
                    "after_line": after_item["line"],
                })
        removed_only.extend(before_items[len(after_items):])
        added_only.extend(after_items[len(before_items):])
    return {"moved": moved, "removed_only": removed_only, "added_only": added_only}


def all_declared_paths() -> list:
    """Every path the declaration treats as an authority: pair sources and
    mirrors, deliberately unmirrored sources, each system's kernel, `SKILL.md`
    and READMEs, and the shared card a symlinked source actually reads."""
    seen = set()
    for doc in iter_authority_docs():
        seen.add(lexical_relative(doc.path))
    for ref in iter_pairs():
        target_rel = shared_card_relative(ref)
        if target_rel:
            seen.add(target_rel)
    return sorted(seen)


def tokens(rev_range=None) -> dict:
    """Numbers, thresholds, bands, counts and labels a commit range moved.

    Found by diffing every path the declaration treats as an authority over the
    range, then extracting the numeric tokens each added or removed line
    carries and pairing them by the label in front of them.
    """
    if not rev_range:
        raise SystemExit("the tokens index needs --range BASE..HEAD")
    resolved = ec.resolve_range(REPO_ROOT, rev_range)
    base, head = resolved["base"], resolved["head"]
    files: dict = {}
    for path in all_declared_paths():
        diff = ec.git_text(REPO_ROOT, "diff", "--unified=0", base, head, "--", path, required=False)
        if not diff.strip():
            continue
        paired = pair_tokens(extract_tokens(diff, "-"), extract_tokens(diff, "+"))
        if paired["moved"] or paired["removed_only"] or paired["added_only"]:
            files[path] = paired
    return keyed({"kind": "tokens", "range": resolved, "files": files})


# ───────────────────────────────────────────────────────────────
# 9. DISCOVERY PASS
# ───────────────────────────────────────────────────────────────

DISCOVER_EXCEPTIONS_FILE = HERE / "discover_exceptions.md"
# The exception classes the tracked document permits: orientation and operating
# notes, dated changelog entries and benchmark fixtures. A glob outside this
# fixed list is refused by name rather than applied, so a pattern written to
# suppress the gap class it was listed for cannot suppress the class it names.
DISCOVER_EXCEPTION_ALLOWLIST = (
    "**/README.md",
    "**/SKILL.md",
    "**/SYNC.md",
    "**/SYNC-HISTORY.md",
    "**/AGENTS.md",
    "**/changelog/*.md",
    "**/benchmark/**/*.md",
)
# The document classes the tracked file states are findings and never
# exceptions: a knowledge directory and a references directory. A glob whose
# own segments can name one of these with a path segment below it is refused
# even when it sits on the allowlist, so widening an allowlisted entry cannot
# reach a knowledge card or a reference document. The check reads the
# pattern's segments, never a list of example filenames.
DISCOVER_EXCEPTION_FORBIDDEN = ("references", "knowledge", "z — Knowledge")


def glob_to_regex(pattern: str):
    """A repo-relative glob, `**` included, compiled to a full-path regex.

    `Path.match()` treats `**` as a single segment wildcard, not the recursive
    one the exception list needs, so the translation is written out here
    instead of leaning on a stdlib match that would silently under-match.
    """
    tokens = re.split(r"(\*\*/|\*\*|\*|\?)", pattern)
    parts = []
    for token in tokens:
        if token == "**/":
            parts.append(r"(?:.*/)?")
        elif token == "**":
            parts.append(r".*")
        elif token == "*":
            parts.append(r"[^/]*")
        elif token == "?":
            parts.append(r"[^/]")
        else:
            parts.append(re.escape(token))
    return re.compile("^" + "".join(parts) + "$")


def exception_refusal(pattern: str) -> str:
    """The rule one exception glob breaks, or an empty string when it breaks
    none.

    Two rules, both stated in the tracked document. A knowledge card or a
    reference document is a finding and never an exception, so a glob whose
    own segments can name a knowledge or references directory with a path
    below it is refused by testing the pattern. The permitted classes are a
    fixed list, so a glob outside it is refused.
    """
    segments = pattern.split("/")
    for index, segment in enumerate(segments):
        if not segment or segment == "**":
            continue
        matcher = glob_to_regex(segment)
        for name in DISCOVER_EXCEPTION_FORBIDDEN:
            if index < len(segments) - 1 and matcher.match(name):
                return (f"the exception glob {pattern!r} can name a {name!r} directory, and the "
                        f"document allows no exception under a knowledge or references directory")
    if pattern not in DISCOVER_EXCEPTION_ALLOWLIST:
        return (f"the exception glob {pattern!r} is not one of the exception classes the "
                f"tracked discovery document permits")
    return ""


def load_discover_exceptions(path: Path) -> list:
    """One glob and its one-line reason per line of the file's first fenced
    code block, read fresh from disk on every discovery pass. Prose outside
    the fence documents the list; it is never parsed as an entry. A glob the
    document does not permit is carried with the refusal that names it, and
    `discover` applies only the rest."""
    exceptions = []
    if not path.is_file():
        return exceptions
    in_fence = False
    for raw in path.read_text(encoding="utf-8").splitlines():
        if raw.strip().startswith("```"):
            if in_fence:
                break
            in_fence = True
            continue
        if not in_fence:
            continue
        line = raw.strip()
        if not line:
            continue
        glob_part, sep, reason = line.partition("  #")
        glob_part = glob_part.strip()
        if not glob_part:
            continue
        exceptions.append({
            "glob": glob_part,
            "reason": reason.strip() if sep else "",
            "pattern": glob_to_regex(glob_part),
            "refused": exception_refusal(glob_part),
        })
    return exceptions


def discover() -> dict:
    """Every markdown document under `AI Systems/*/` the declaration does not name.

    Named means every document the declaration treats as an authority, a
    pair's source or mirror, a deliberately unmirrored source, a system's
    kernel, `SKILL.md` or README, and a `z — Knowledge/` card a declared
    symlink actually resolves to. Anything else, a SYNC.md, a benchmark
    note, a card in `z — Knowledge/` no pair's symlink reaches, is reported
    so the declared universe cannot silently shrink to whatever the last
    edit happened to cover, unless the tracked exception list in
    `discover_exceptions.md` names the class it belongs to. A document that
    matches no declared authority, no reached card and no exception is a
    real gap and still reported.
    """
    named = set()
    for doc in iter_authority_docs():
        named.add(lexical_relative(doc.path))
    for ref in iter_pairs():
        target_rel = shared_card_relative(ref)
        if target_rel:
            named.add(target_rel)
    loaded = load_discover_exceptions(DISCOVER_EXCEPTIONS_FILE)
    exceptions = [exc for exc in loaded if not exc["refused"]]
    refused = [
        {"glob": exc["glob"], "reason": exc["refused"]}
        for exc in loaded if exc["refused"]
    ]
    all_md = sorted(lexical_relative(path) for path in SYSTEMS_ROOT.rglob("*.md"))
    # A knowledge card or a reference document is a finding and never an
    # exception, so no glob may suppress one even when it matches. The guard
    # is per path, because a wide glob such as **/README.md can reach a
    # forbidden directory without naming it.
    unnamed = [
        path for path in all_md
        if path not in named and (
            any(part in DISCOVER_EXCEPTION_FORBIDDEN for part in path.split("/")[:-1])
            or not any(exc["pattern"].match(path) for exc in exceptions)
        )
    ]
    return keyed({
        "kind": "discover",
        "unnamed": unnamed,
        "count": len(unnamed),
        "exceptions_applied": len(exceptions),
        "exceptions_refused": refused,
    })


# ───────────────────────────────────────────────────────────────
# 10. TRANSFORM TABLE
# ───────────────────────────────────────────────────────────────

DISPOSITIONS = (
    "conform", "finding", "routed-to-human", "skipped-unchanged", "unmapped", "deferred",
)
BLOCKING_DISPOSITIONS = ("finding", "unmapped", "deferred")

# The walk keeps its per-pair state apart from the control plane's episode
# records. Close refuses while the episode state folder holds any path the
# control plane did not create, so a walk writing there would block every close.
STATE_DIR = HERE / "episodes" / "walk-state"
TRANSFORMS_FILE = HERE / "transforms.md"
# One table row of exactly four cells: Class, Kind, Dated and Status. The
# anchor on both ends is what keeps a row carrying a fifth cell out of the
# parser rather than letting the extra cell run the row's meaning.
TRANSFORM_ROW = re.compile(
    r"^\|\s*([a-z][a-z-]*)\s*\|\s*(presentation|semantic)\s*\|\s*([^|]*?)\s*\|\s*([^|]*?)\s*\|$"
)
# A confirmed status token opens the row's Status cell, so `unconfirmed`,
# `not confirmed` and `overturned, previously confirmed` all read as
# unconfirmed rather than matching on the letters alone.
TRANSFORM_CONFIRMED = re.compile(r"^confirmed\b", re.IGNORECASE)
# A malformed or repeated row is refused rather than read: it grants no
# kind, and the refusals are carried under this key so the caller can name
# the rows it could not read instead of the table silently losing them. The
# value is a tuple so a caller may use the table as a hashable key.
TRANSFORM_REFUSALS = "__refused_rows__"
TRANSFORM_CLASS_CELL = re.compile(r"^[a-z][a-z-]*$")
# The four header cells the table opens with. Parsing starts after this row
# and stops at the first line that is not part of the table, so a four-cell
# row written in prose outside the table is never read as a class.
TRANSFORM_HEADER = re.compile(r"^\|\s*Class\s*\|\s*Kind\s*\|\s*Dated\s*\|\s*Status\s*\|$")


def parse_transform_row(line: str) -> dict | None:
    """One line of the transform table parsed into its four named cells, or
    `None` when the line is not a data row at all.

    A line that opens with a class cell but does not carry exactly the four
    cells the table declares comes back marked unreadable, so the caller can
    refuse it by name. A row with a fifth cell is never read as the class its
    first two cells happen to name, because a status written somewhere other
    than the Status column would then grant a conform the Status column did
    not.
    """
    stripped = line.strip()
    if not stripped.startswith("|"):
        return None
    cells = [cell.strip() for cell in stripped.strip("|").split("|")]
    if not cells or not TRANSFORM_CLASS_CELL.match(cells[0]):
        return None
    match = TRANSFORM_ROW.match(stripped)
    if not match:
        return {"class": cells[0], "kind": None, "dated": None, "status": "",
                "confirmed": False, "readable": False}
    return {"class": match.group(1), "kind": match.group(2), "dated": match.group(3),
            "status": match.group(4), "confirmed": bool(TRANSFORM_CONFIRMED.match(match.group(4))),
            "readable": True}


def load_transforms(path: Path) -> dict:
    """The transform classes the operator has confirmed, with their
    presentation/semantic kind, read from `transforms.md` and nowhere else,
    so the split lives in one file. A row whose Status column does not open
    with the `confirmed` token is read as undecided: the checker treats its
    class as semantic regardless of the Kind column, because a presentation
    label nobody confirmed yet has not earned the auto-conform it would
    otherwise grant. A malformed or repeated row is refused by name under
    `TRANSFORM_REFUSALS` and grants no kind, because a row the table cannot
    read whole is a row whose status nothing has established. Only the rows
    between the table's own header and the end of its contiguous run are
    read, so a four-cell example written in prose grants no kind.
    """
    kinds = {}
    refused = []
    if not path.is_file():
        return kinds
    lines = path.read_text(encoding="utf-8").splitlines()
    header = next((index for index, line in enumerate(lines) if TRANSFORM_HEADER.match(line.strip())), None)
    if header is None:
        kinds[TRANSFORM_REFUSALS] = (
            "transforms.md carries no Class/Kind/Dated/Status header, so no row is read as part of its table",
        )
        return kinds
    seen = set()
    for number, line in enumerate(lines[header + 1:], start=header + 2):
        if not line.strip().startswith("|"):
            break
        row = parse_transform_row(line)
        if row is None:
            continue
        if not row["readable"]:
            refused.append(
                f"transforms.md line {number} is not the four-cell row the table declares: {line.strip()!r}"
            )
            continue
        if row["class"] in seen:
            refused.append(
                f"transforms.md line {number} repeats the class {row['class']!r}, so its status is ambiguous"
            )
            kinds.pop(row["class"], None)
            continue
        seen.add(row["class"])
        if row["confirmed"]:
            kinds[row["class"]] = row["kind"]
    if refused:
        kinds[TRANSFORM_REFUSALS] = tuple(refused)
    return kinds


# ───────────────────────────────────────────────────────────────
# 11. DIFF CLASSIFICATION
# ───────────────────────────────────────────────────────────────

def strip_punctuation(text: str) -> str:
    return WHITESPACE.sub(" ", re.sub(r"[^\w\s]", "", text)).strip().lower()


def strip_markdown_refs(text: str) -> str:
    """Markdown links and code spans reduced to what a reader compares.

    A link's destination is part of what the line tells a reader, so it is
    dropped only when the visible label already names the same document the
    destination names, which is the one case `[Brand](brand.md)` written as
    `Brand` states the same rule. A destination the label does not name is
    kept in the folded text, so a pointer that starts pointing somewhere
    else never folds equal to the line it replaced. A fragment or a query
    keeps the whole destination in the fold even when the label names the
    document, because a fragment names a section of that document and a
    query can change which document is rendered, so neither is decoration
    the label stands in for.
    """

    def fold(match: re.Match) -> str:
        label, destination = match.group(1), match.group(2).strip()
        if "#" in destination or "?" in destination:
            return f"{label} {destination}"
        directory = destination.rsplit("/", 1)[0] if "/" in destination else ""
        stem = destination.rsplit("/", 1)[-1]
        if stem.lower().endswith(".md"):
            stem = stem[:-3]
        # The label must name the destination's directories as well as its
        # filename before the destination can be dropped, so a link that
        # moves from old/brand.md to new/brand.md keeps the directory in the
        # fold and never cancels as presentation.
        stem_words = set(re.findall(r"[a-z0-9]+", f"{directory} {stem}".lower()))
        label_words = set(re.findall(r"[a-z0-9]+", label.lower()))
        return label if stem_words and stem_words <= label_words else f"{label} {destination}"

    text = MARKDOWN_LINK.sub(fold, text)
    text = re.sub(r"`([^`]+)`", r"\1", text)
    return text.strip()


def presentation_normalise(text: str, transform_kinds: dict) -> str:
    """Text folded through every transform confirmed as presentation in
    `transforms.md`, so a comparison downstream cannot see a difference
    those transforms explain. An unconfirmed row grants no auto-conform, so
    a class not read back as `"presentation"` here leaves the text no more
    reduced than the same case-and-whitespace fold every normalised sentence
    already gets.
    """
    if transform_kinds.get("cross-reference-form") == "presentation":
        text = strip_markdown_refs(text)
    if transform_kinds.get("punctuation") == "presentation":
        return strip_punctuation(text)
    return normalise_sentence(text)


DELIVERY_VOCABULARY = {
    "ships", "delivers", "sends", "launches", "publishes", "releases", "posts", "goes",
}


COMPARISON_OR_SEPARATOR = re.compile(r"[<>]?=|!=|==|[<>]|[/\\]")


def operator_or_separator_only(before: str, after: str) -> bool:
    """True when two lines differ only in a comparison operator or a path
    separator.

    The punctuation fold erases both, so without this guard a `>=` rewritten
    as `=` or a `/` rewritten as `-` would read as the same line wearing a
    different punctuation mark, which is exactly the silent conform a
    semantic change must not get. Both are appended to the unclassified set
    instead, so a person reads the change.
    """
    if COMPARISON_OR_SEPARATOR.findall(before) == COMPARISON_OR_SEPARATOR.findall(after):
        return False
    plain_before = COMPARISON_OR_SEPARATOR.sub("", before)
    plain_after = COMPARISON_OR_SEPARATOR.sub("", after)
    return strip_punctuation(plain_before) == strip_punctuation(plain_after)


def classify_line_change(before: str, after: str) -> str:
    """One changed line, sorted into a transform class or left unclassified.

    Order matters: a comparison operator or a path separator is checked
    before punctuation so those two changes never fall into a presentation
    class, punctuation is checked before cross-reference form so a line that
    differs only in a trailing comma never falls through to a costlier
    comparison, and the four semantic checks run only once the two
    presentation checks have both failed to explain the difference.
    """
    if operator_or_separator_only(before, after):
        return ""
    if strip_punctuation(before) == strip_punctuation(after):
        return "punctuation"
    if strip_punctuation(strip_markdown_refs(before)) == strip_punctuation(strip_markdown_refs(after)):
        return "cross-reference-form"
    before_words = set(re.findall(r"[a-z]+", before.lower()))
    after_words = set(re.findall(r"[a-z]+", after.lower()))
    if before_words != after_words and (before_words & DELIVERY_VOCABULARY or after_words & DELIVERY_VOCABULARY):
        return "delivery-vocabulary"
    path_like = re.compile(r"(?:[\w.-]+/)+[\w.-]+\.\w+")
    if path_like.search(before) or path_like.search(after):
        return "filesystem-residue"
    before_key = re.match(r"^([A-Za-z0-9_-]+):", before.strip())
    after_key = re.match(r"^([A-Za-z0-9_-]+):", after.strip())
    if before_key and after_key and before_key.group(1) != after_key.group(1):
        return "yaml-identifier-rename"
    if before.strip().lower().startswith("description:") or after.strip().lower().startswith("description:"):
        return "description-promotion"
    return ""


def classify_diff(diff_text: str) -> dict:
    """Every removed/added line pair in one unified diff, classified by hunk.

    Lines are paired by position within a hunk's removed and added groups, the
    same pairing `pair_tokens` uses for a numbered value, because a diff does
    not itself say which new line replaces which old one.
    """
    classes_seen = set()
    unclassified = []
    removed, added = [], []

    def flush():
        paired = min(len(removed), len(added))
        for before, after in zip(removed[:paired], added[:paired]):
            cls = classify_line_change(before, after)
            if cls:
                classes_seen.add(cls)
            else:
                unclassified.append({"before": before, "after": after})
        # A line with no partner on the other side of the hunk is not a
        # presentation difference and must not disappear between the two
        # lists: an added rule with no removed counterpart is new content,
        # and a removed rule with no added counterpart is stale content.
        for before in removed[paired:]:
            unclassified.append({"before": before, "after": ""})
        for after in added[paired:]:
            unclassified.append({"before": "", "after": after})
        removed.clear()
        added.clear()

    for line in diff_text.splitlines():
        if line.startswith("@@"):
            flush()
        elif line.startswith("-") and not line.startswith("---"):
            removed.append(line[1:])
        elif line.startswith("+") and not line.startswith("+++"):
            added.append(line[1:])
    flush()
    return {"classes": sorted(classes_seen), "unclassified": unclassified}


# ───────────────────────────────────────────────────────────────
# 12. ROUTES
# ───────────────────────────────────────────────────────────────

def bindings_and_fanout_index(indexes: dict) -> dict:
    """Every path a pair's own binding or a shared card's fan-out names,
    mapped back to the pair(s) it reaches directly."""
    index: dict = {}

    def add(path: str, key) -> None:
        index.setdefault(path, set()).add(key)

    for system_id, pairs in indexes["bindings"]["systems"].items():
        for skill_rel, info in pairs.items():
            key = (system_id, skill_rel)
            add(info["source_path"], key)
            add(info["mirror_path"], key)
    knowledge_root_rel = lexical_relative(KNOWLEDGE_ROOT)
    for target_name, reached in indexes["fanout"]["knowledge"].items():
        target_path = f"{knowledge_root_rel}/{target_name}"
        for item in reached:
            add(target_path, (item["system"], item["pair"]))
    return index


def pointer_routes(indexes: dict) -> dict:
    """(system, doc id) of the document cited, mapped to every pair whose
    declared document names it.

    A document that cites a changed authority by title or path may now
    describe something that no longer matches, so its own pair routes for a
    human to read the two side by side.
    """
    routes: dict = {}
    for system_id, docs in indexes["pointers"]["systems"].items():
        for doc_id, doc in docs.items():
            citer_pair = doc["pair"]
            if not citer_pair:
                continue
            citer = (system_id, citer_pair)
            for found in doc["found"]:
                for candidate in found["targets"]:
                    cited_system = candidate.get("system")
                    cited_doc_id = candidate.get("doc_id")
                    if not cited_system or not cited_doc_id:
                        continue
                    if (cited_system, cited_doc_id) == (system_id, doc_id):
                        continue
                    routes.setdefault((cited_system, cited_doc_id), set()).add(citer)
    return routes


def duplicate_routes(indexes: dict, signals: dict) -> dict:
    """Touched authority path, mapped to every pair whose declared document
    shares a sentence the range added or removed there."""
    sentence_lookup = {entry["sentence"]: entry for entry in indexes["duplicates"]["sentences"].values()}
    routes: dict = {}
    for path, expected in signals.items():
        contexts = {**expected.get("removed_sentence_contexts", {}), **expected.get("added_sentence_contexts", {})}
        changed_sentences = set(expected["removed_sentences"]) | set(expected["added_sentences"])
        for sentence in changed_sentences:
            entry = sentence_lookup.get(sentence)
            if not entry:
                continue
            authority_before = contexts.get(sentence, "")
            for site in entry["sites"]:
                # The sentence alone does not pair two documents. The line
                # above it has to match too, normalised, or the same sentence
                # under a different heading would be read as the same rule.
                if site.get("before", "") != authority_before:
                    continue
                if site.get("pair"):
                    routes.setdefault(path, set()).add((site["system"], site["pair"]))
                elif site.get("doc") in ("kernel", "skill-md", "readme-system", "readme-skill", "readme-project"):
                    # A kernel, SKILL.md or README is an authority of its own
                    # and never a carrier, but a rule stated there in the
                    # range's changed words still reaches every pair beside it
                    # in that same system.
                    for skill_rel in indexes["bindings"]["systems"].get(site["system"], {}):
                        routes.setdefault(path, set()).add((site["system"], skill_rel))
    return routes


def token_routes(pair_lookup: dict, signals: dict) -> dict:
    """Touched authority path, mapped to every pair whose mirror currently
    holds a value the range moved or removed there, plus every pair of a
    system whose kernel, `SKILL.md` or README still carries the whole line a
    moved or removed token came from.

    A kernel or README is fleet-wide context for every pair beside it in its
    own system, not a second copy of any one of them, so it carries no
    disposition of its own. A moved token still sitting in one of those files
    returns that file as a carrier by routing the whole system's pairs for a
    human to check. Matched by the token's own line, gated the same way
    `line_signal` gates a lingering-token check on a mirror, never by the bare
    value alone: a short, common digit would otherwise match some unrelated
    line in nearly every system's kernel or README by coincidence.
    """
    routes: dict = {}
    mirror_cache: dict = {}
    mirror_line_cache: dict = {}
    authority_cache: dict = {}

    def mirror_text(ref: PairRef) -> str:
        key = (ref.system_id, ref.skill_rel)
        if key not in mirror_cache:
            mirror_cache[key] = (
                read_only_bytes(ref.mirror).decode("utf-8", errors="replace") if ref.mirror.is_file() else ""
            )
        return mirror_cache[key]

    def mirror_lines(ref: PairRef) -> set:
        key = (ref.system_id, ref.skill_rel)
        if key not in mirror_line_cache:
            mirror_line_cache[key] = {
                signal for line in mirror_text(ref).splitlines()
                if (signal := line_signal(line))
            }
        return mirror_line_cache[key]

    def authority_lines(system_id: str) -> set:
        if system_id not in authority_cache:
            lines = set()
            for path in system_authority_paths(SYSTEMS[system_id]).values():
                if not path.is_file():
                    continue
                text = read_only_bytes(path).decode("utf-8", errors="replace")
                lines.update(signal for line in text.splitlines() if (signal := line_signal(line)))
            authority_cache[system_id] = lines
        return authority_cache[system_id]

    pairs_by_system: dict = {}
    for system_id, skill_rel in pair_lookup:
        pairs_by_system.setdefault(system_id, []).append((system_id, skill_rel))

    for path, expected in signals.items():
        token_lines = {
            signal for t in expected["removed_tokens"]
            if (signal := line_signal(t["line"]))
        } | {
            signal for t in expected["moved_tokens"]
            if (signal := line_signal(t["before_line"]))
        }
        if token_lines:
            for ref in pair_lookup.values():
                if token_lines & mirror_lines(ref):
                    routes.setdefault(path, set()).add((ref.system_id, ref.skill_rel))

            for system_id in SYSTEMS:
                if token_lines & authority_lines(system_id):
                    routes.setdefault(path, set()).update(pairs_by_system.get(system_id, ()))
    return routes


# ───────────────────────────────────────────────────────────────
# 13. TOUCHED PAIRS AND EXPECTED SIDE
# ───────────────────────────────────────────────────────────────

def touched_pairs(
    resolved: dict, indexes: dict, pair_lookup: dict, transform_kinds: dict, signals: dict = None,
) -> dict:
    """Every declared pair a range's diff reaches, each with the set of
    authority paths from that diff it was reached through.

    A touched authority routes to its mirrors through bindings and fan-out, to
    every document whose pointers index names it, to every duplicate site of a
    sentence the range changed, and to every document holding a token the
    range moved. The union of the four is the mirror set.

    `--name-only` alone lets git quote a path holding a non-ASCII character,
    an em dash in `z — Knowledge` among them, as a C-style escaped string, and
    that quoted form matches no path this module ever computes. `-z` is the
    same list NUL-separated with quoting off, so a path here is always the
    same bytes `lexical_relative` would produce for it.
    """
    diff_z = ec.git_text(REPO_ROOT, "diff", "--name-only", "-z", resolved["base"], resolved["head"])
    changed = {path for path in diff_z.split("\0") if path}
    touched_authorities = sorted(changed & set(all_declared_paths()))

    direct_index = bindings_and_fanout_index(indexes)
    pointer_index = pointer_routes(indexes)
    path_to_doc_id = {
        entry["path"]: (system_id, doc_id)
        for system_id, docs in indexes["pointers"]["systems"].items()
        for doc_id, entry in docs.items()
    }
    if signals is None:
        signals = {}
    for path in touched_authorities:
        if path not in signals:
            signals[path] = expected_from_commit(REPO_ROOT, resolved, path, indexes["tokens"], transform_kinds)
    dup_index = duplicate_routes(indexes, signals)
    tok_index = token_routes(pair_lookup, signals)

    hits: dict = {}

    def add_hit(key, path: str) -> None:
        if key not in pair_lookup:
            return
        hits.setdefault(key, {"ref": pair_lookup[key], "authority_paths": set()})["authority_paths"].add(path)

    for path in touched_authorities:
        for key in direct_index.get(path, ()):
            add_hit(key, path)
        doc = path_to_doc_id.get(path)
        if doc is not None:
            authority_system, authority_doc_id = doc
            if authority_doc_id in SYSTEM_PAIR_ROLES:
                # A changed kernel, SKILL.md or README is an authority of its
                # own and never a mirror, but its system's pairs read it. Name
                # them as carriers so a replay still surfaces the authority
                # that moved rather than only the pair files beside it.
                for skill_rel in indexes["bindings"]["systems"].get(authority_system, {}):
                    add_hit((authority_system, skill_rel), path)
            for key in pointer_index.get(doc, ()):
                add_hit(key, path)
        for key in dup_index.get(path, ()):
            add_hit(key, path)
        for key in tok_index.get(path, ()):
            add_hit(key, path)
    return hits


def authority_path_choices(ref: PairRef, authority_paths: set) -> list:
    """Every path in this range's diff that can supply the expected value.

    A symlinked source's shared card, an owned source and a directly touched
    mirror are the pair's own authorities and come first, in that priority,
    exactly as the single pick ordered them. Every other path that reached
    the pair, a pointer, a duplicate sentence or a moved token, follows in
    sorted order, because a stale sentence one path would hide behind a
    clean own verdict must still surface.
    """
    own = None
    target_rel = shared_card_relative(ref)
    if target_rel and target_rel in authority_paths:
        own = (target_rel, "shared-card")
    # A symlinked source's own diff is its link text, a path rather than a
    # rule, so it never stands in for the card it points at. The card is the
    # authority above, and the gate already holds the mirror to it byte for byte.
    if own is None and not ref.source.is_symlink():
        source_rel = lexical_relative(ref.source)
        if source_rel in authority_paths:
            own = (source_rel, "source")
    if own is None:
        mirror_rel = lexical_relative(ref.mirror)
        if mirror_rel in authority_paths:
            own = (mirror_rel, "mirror-direct")
    # A symlink's own path and its target, and the pair's mirror, are never
    # routed references to another document: they are this pair's own paths
    # under whatever kind the priority above did or did not select.
    own_paths = {lexical_relative(ref.source), lexical_relative(ref.mirror)}
    target_rel = shared_card_relative(ref)
    if target_rel:
        own_paths.add(target_rel)
    choices = [own] if own else []
    choices.extend((path, "routed") for path in sorted(authority_paths - own_paths))
    return choices


def declared_fork_paths() -> set:
    """Every repo-relative document a declaration records as a permitted
    fork: the source, the mirror and the symlink target of each pair whose
    skill-relative path sits in its system's `forked_shared_copies`.

    A routed authority is permitted to differ only when the authority itself
    is one of those documents, not when the carrier reading it happens to be
    declared elsewhere. Comparing the paths, not the carrier, is what keeps
    a shared card or another system's hand-corrected copy from being judged
    by the carrier's own exemption.
    """
    paths = set()
    for ref in iter_pairs():
        if ref.skill_rel not in SYSTEMS[ref.system_id].get("forked_shared_copies", {}):
            continue
        paths.add(lexical_relative(ref.source))
        paths.add(lexical_relative(ref.mirror))
        target = shared_card_relative(ref) or realpath_relative(ref.source)
        if target:
            paths.add(target)
    return paths


def read_only_bytes(path: Path) -> bytes:
    """Read a file for comparison and never for writing, enforced by the flag
    rather than by convention: `O_RDONLY` cannot be made to write."""
    fd = os.open(path, os.O_RDONLY)
    try:
        return os.read(fd, os.fstat(fd).st_size)
    finally:
        os.close(fd)


def presentation_cancel(removed: list, added: list, transform_kinds: dict) -> tuple:
    """Two sentence lists, with any pair whose presentation-normalised form
    is shared between them stripped from both sides first.

    A removed sentence and an added sentence that fold to the same text
    under the confirmed presentation classes are the same sentence wearing
    the two ends of one punctuation or cross-reference-form edit, not a
    stale one and an unrelated new one. Cancelling them here, before either
    list is compared against a mirror, is what keeps a mirror that already
    carries the updated punctuation from reading as still holding the old
    sentence: after this cancellation, whatever a mirror shows for a
    presentation-only edit no longer changes the outcome.
    """
    removed_keys = {presentation_normalise(s, transform_kinds) for s in added}
    added_keys = {presentation_normalise(s, transform_kinds) for s in removed}
    removed_only = sorted({s for s in removed if presentation_normalise(s, transform_kinds) not in removed_keys})
    added_only = sorted({s for s in added if presentation_normalise(s, transform_kinds) not in added_keys})
    return removed_only, added_only


def expected_from_commit(
    repo: Path, resolved: dict, authority_path: str, tokens_index: dict, transform_kinds: dict,
) -> dict:
    """Everything the checker expects a mirror to show, built from the
    declaration's path list and the commit's diff alone. Takes no mirror path
    and reads no mirror bytes, so it cannot be the function this compares against.

    Carries four kinds of signal: tokens the range moved (a value changed
    under the same label), tokens the range removed outright (no matching
    added value), tokens the range added outright (no matching removed
    value), and sentences the range added or removed, by the same
    normalised-sentence rule the duplicates index uses, once a removed and
    an added sentence explained by a confirmed presentation class alone have
    cancelled each other out.

    Those lists are then read against the authority's own text at the range
    head, the final state the range left behind: a removed sentence or
    removed token whose line signal still appears whole there was moved or
    restored inside the range, not removed, and an added sentence or added
    token whose line signal is absent there was superseded by a later
    change, so a value changed twice inside the range is expected only at
    its final value.
    """
    diff_text = ec.git_text(
        repo, "diff", "--unified=0", resolved["base"], resolved["head"], "--", authority_path, required=False,
    )
    file_tokens = tokens_index.get("files", {}).get(authority_path, {})
    removed_sentences = extract_sentences(diff_text, "-")
    added_sentences = extract_sentences(diff_text, "+")
    removed_only_sentences, added_only_sentences = presentation_cancel(
        removed_sentences, added_sentences, transform_kinds)
    head_text = ec.git_text(
        repo, "show", f"{resolved['head']}:{authority_path}", required=False,
    )
    base_text = ec.git_text(
        repo, "show", f"{resolved['base']}:{authority_path}", required=False,
    )
    head_bounded = {
        normalise_sentence(line) for line in head_text.splitlines() if line.strip()
    } | set(sentences_of(head_text))
    base_context = {sentence: before for sentence, before in sentences_with_context(base_text)}
    head_context = {sentence: before for sentence, before in sentences_with_context(head_text)}
    removed_tokens = [
        token for token in file_tokens.get("removed_only", [])
        if not (line_signal(token["line"]) and line_signal(token["line"]) in head_bounded)
    ]
    added_tokens = [
        token for token in file_tokens.get("added_only", [])
        if line_signal(token["line"]) and line_signal(token["line"]) in head_bounded
    ]
    removed_sentences = [s for s in removed_only_sentences if s not in head_bounded]
    added_sentences = [s for s in added_only_sentences if s in head_bounded]
    return {
        "diff_text": diff_text,
        "moved_tokens": file_tokens.get("moved", []),
        "removed_tokens": removed_tokens,
        "added_tokens": added_tokens,
        "removed_sentences": removed_sentences,
        "added_sentences": added_sentences,
        "removed_sentence_contexts": {s: base_context.get(s, "") for s in removed_sentences},
        "added_sentence_contexts": {s: head_context.get(s, "") for s in added_sentences},
        "diff_classes": classify_diff(diff_text),
    }


# ───────────────────────────────────────────────────────────────
# 14. MIRROR COMPARISON
# ───────────────────────────────────────────────────────────────

MIN_LINE_SIGNAL = 12


def line_signal(line: str) -> str:
    """A removed or added token's own diff line, normalised the way a
    sentence is. A bare value like "3" or "35" recurs by coincidence across a
    corpus this size; the label and punctuation around it in the line it
    actually came from do not, so the line, not the value alone, is the
    presence test. A line too short to carry that context after
    normalisation, or a frontmatter field or code fragment rather than a
    stated rule, is not a reliable signal and is left out.
    """
    if is_structural_line(line):
        return ""
    normalised = normalise_sentence(line)
    return normalised if len(normalised) >= MIN_LINE_SIGNAL else ""


_MIRROR_ANALYSIS: dict = {}


def analyse_mirror(mirror_bytes: bytes, transform_kinds: dict) -> dict:
    """The mirror-side sets one comparison needs, keyed by the mirror's own
    content and the transform table in force, so one mirror document is not
    re-scanned once for every authority path that reached its pair.
    """
    key = (ec.sha256_bytes(mirror_bytes), tuple(sorted(transform_kinds.items())))
    cached = _MIRROR_ANALYSIS.get(key)
    if cached is not None:
        return cached
    mirror_raw = mirror_bytes.decode("utf-8", errors="replace")
    mirror_lines_basic = {normalise_sentence(line) for line in mirror_raw.splitlines() if line.strip()}
    mirror_sentences_basic = {normalise_sentence(s) for s in sentences_of(mirror_raw)}
    mirror_sentence_contexts: dict = {}
    for sentence, before in sentences_with_context(mirror_raw):
        mirror_sentence_contexts.setdefault(sentence, set()).add(before)
    mirror_lines_pres = {
        presentation_normalise(line, transform_kinds)
        for line in mirror_raw.splitlines() if line.strip()
    }
    mirror_sentences_pres = {presentation_normalise(s, transform_kinds) for s in sentences_of(mirror_raw)}
    analysis = {
        "raw": mirror_raw,
        "bounded_basic": mirror_lines_basic | mirror_sentences_basic,
        "bounded_pres": mirror_lines_pres | mirror_sentences_pres,
        "sentence_contexts": mirror_sentence_contexts,
    }
    _MIRROR_ANALYSIS[key] = analysis
    return analysis


FIELD_LINE = re.compile(r"^\s*>?\s*\*\*([A-Za-z][A-Za-z ]*):\*\*\s*(.*)$")
FIELD_WORD = re.compile(r"[a-z0-9']+")
# A run of four normalised words is the shortest phrase that still states a
# rule. A mirror line sharing less than that is a collocation with the field
# sentence, not the sentence carried as prose.
MIN_FIELD_RUN = 4
FIELD_ROUTE_REASON = "field line carried by the mirror, routed for review: "
ADAPTED_ROUTE_REASON = "declared adaptation of its source, source line(s) omitted by decision: "


def field_path_titles() -> dict:
    """Every declared skill-relative source path, mapped to the Project title
    it is uploaded as, extension removed.

    A field may name either form. Writing both as the title lets a path on
    the source side and the title on the Project side read as one address.
    """
    titles = {}
    for ref in iter_pairs():
        title = ref.mirror_name[:-3] if ref.mirror_name.endswith(".md") else ref.mirror_name
        titles[ref.skill_rel] = title
    return titles


def mirror_title(ref: PairRef) -> str:
    """The declared Project mirror name without its filename extension."""
    return ref.mirror_name[:-3] if ref.mirror_name.endswith(".md") else ref.mirror_name


def short_mirror_title(ref: PairRef) -> str:
    """The declared Project title without its system and version segments.

    The version is recognised by the same pattern the rest of this module
    reads a mirror name with, never by position. A name whose last segment
    is not a version keeps it, because dropping a trailing segment on the
    assumption that every mirror is versioned would silently discard real
    content from the identity two documents are compared by.
    """
    declared = MIRROR_VERSION_SUFFIX.match(ref.mirror_name)
    title = declared.group(1) if declared else mirror_title(ref)
    parts = title.split(" - ")
    return " - ".join(parts[1:]) if len(parts) > 1 else title


def resolve_declared_links(text: str, doc_rel: str) -> tuple:
    """Replace declared pair links with their full Project title.

    A destination outside the declared pair-source paths stays untouched, so
    a path that merely resembles a known document cannot inherit its title.
    The returned pair list supplies the title aliases for the mirror side of
    the same comparison.
    """
    source_paths: dict = {}
    for ref in iter_pairs():
        source_paths.setdefault(lexical_relative(ref.source), []).append(ref)
    found = []

    def replace(match: re.Match) -> str:
        target = canonical_link_target(doc_rel, match.group(2).strip())
        candidates = source_paths.get(target, ())
        if len(candidates) != 1:
            return match.group(0)
        ref = candidates[0]
        if ref not in found:
            found.append(ref)
        return mirror_title(ref)

    return MARKDOWN_LINK.sub(replace, text), tuple(found)


_AMBIGUOUS_TITLES: frozenset | None = None


def ambiguous_mirror_titles() -> frozenset:
    """Declared titles that sit inside another declared title.

    A word boundary cannot separate these two, because the longer title
    continues past the shorter one on a space rather than on a word
    character. Folding the shorter one would rewrite a sentence naming the
    longer document as though it named the shorter, which is a wrong
    comparison rather than a missed one, so such a title is never folded.
    """
    global _AMBIGUOUS_TITLES
    if _AMBIGUOUS_TITLES is None:
        titles = {mirror_title(ref) for ref in iter_pairs()}
        _AMBIGUOUS_TITLES = frozenset(
            title for title in titles
            if any(title != other and title in other for other in titles)
        )
    return _AMBIGUOUS_TITLES


def fold_declared_mirror_titles(text: str, refs: tuple) -> str:
    """Use the short declared title for either accepted Project title form.

    Matched on a word boundary, the way every other declared title in this
    module is matched, and never for a title another declared title
    contains. A pair whose title cannot be told apart from a longer one is
    compared without the alias, so it reports a difference a person reads
    instead of quietly comparing the wrong two sentences.
    """
    ambiguous = ambiguous_mirror_titles()
    for ref in sorted(refs, key=lambda item: len(mirror_title(item)), reverse=True):
        full = mirror_title(ref)
        short = short_mirror_title(ref)
        if full != short and full not in ambiguous:
            text = title_boundary_pattern(full).sub(short, text)
    return text


def addition_presentation(text: str, transform_kinds: dict, doc_rel: str = "") -> tuple:
    """Fold an addition through declared link identities and presentation rules."""
    if doc_rel:
        text, refs = resolve_declared_links(text, doc_rel)
    else:
        refs = ()
    text = fold_declared_mirror_titles(text, refs)
    return presentation_normalise(text, transform_kinds), refs


def field_words(text: str, transform_kinds: dict, path_titles: dict) -> list:
    """One line or field sentence as normalised words, with every declared
    source path written as the Project title that stands in for it."""
    for path, title in path_titles.items():
        text = text.replace(path, title)
    return FIELD_WORD.findall(presentation_normalise(text, transform_kinds))


def longest_shared_run(left: list, right: list) -> int:
    """The length of the longest run of adjacent words the two lists share."""
    positions: dict = {}
    for index, word in enumerate(right):
        positions.setdefault(word, []).append(index)
    best = 0
    for start, word in enumerate(left):
        for index in positions.get(word, ()):
            length = 0
            while (
                start + length < len(left)
                and index + length < len(right)
                and left[start + length] == right[index + length]
            ):
                length += 1
            best = max(best, length)
    return best


def field_carrying_line(field: list, mirror_lines: list):
    """The mirror line number whose words carry the field sentence, or None."""
    if len(field) < MIN_FIELD_RUN:
        return None
    best_line, best_run = None, 0
    for number, line in enumerate(mirror_lines, start=1):
        run = longest_shared_run(field, line)
        if run > best_run:
            best_line, best_run = number, run
    return best_line if best_run >= MIN_FIELD_RUN else None


def partition_field_additions(
    diff_text: str, missing: list, mirror_raw: str, transform_kinds: dict, missing_tokens: list = (),
) -> tuple:
    """The missing sentences and tokens a structured field line carries in
    the mirror, separated from the ones still missing.

    A field line is a form the source uses and the Project mirror does not.
    The addition's distinctive content is its words with the field label
    removed and every declared source path written as its Project title. A
    sentence or a token line outside that form, or one whose distinctive
    content the mirror does not carry, stays a missing addition. Returns the
    remaining sentences, the field label with the mirror line number for
    each carried one, and the tokens still missing.
    """
    remaining = set(missing)
    remaining_tokens = list(missing_tokens)
    carried = set()
    if not remaining and not remaining_tokens:
        return [], [], []
    path_titles = field_path_titles()
    mirror_lines = [field_words(line, transform_kinds, path_titles) for line in mirror_raw.splitlines()]
    for line in diff_text.splitlines():
        if not line.startswith("+") or line.startswith("+++"):
            continue
        body = line[1:]
        match = FIELD_LINE.match(body)
        if not match:
            continue
        label = match.group(1)
        field_sentences = set(sentences_of(body))
        for sentence in sorted(remaining & field_sentences):
            distinctive = sentence
            prefix = label.lower() + ":"
            if distinctive.startswith(prefix):
                distinctive = distinctive[len(prefix):].strip()
            number = field_carrying_line(
                field_words(distinctive, transform_kinds, path_titles), mirror_lines)
            if number is None:
                continue
            carried.add((label, number))
            remaining.discard(sentence)
        # A missing token whose own added line is the same structured field
        # is excused on the same terms as a missing sentence: the field form
        # is the source's and the mirror has no fields, so the token routes
        # to a human only when the mirror carries the line's content as prose.
        body_stripped = body.strip()
        for token in [t for t in remaining_tokens if t["line"] == body_stripped]:
            number = field_carrying_line(
                field_words(match.group(2), transform_kinds, path_titles), mirror_lines)
            if number is None:
                continue
            carried.add((label, number))
            remaining_tokens.remove(token)
    return sorted(remaining), sorted(carried), remaining_tokens


def declared_omissions(ref: PairRef) -> dict:
    """The source lines this pair's mirror is declared to leave out by
    decision, keyed by the identity an added line in the diff carries.

    `adapted_pairs` names exact source lines, and a line the range added is
    the declared one only when the two are the same line, so each declared
    line is keyed by its whole normalised text, the same fold the walk
    applies to every line it reads. The match is made on the addition's own
    line, never on the truncated site string the finding prints, because a
    site string cut at a hundred characters cannot carry the identity the
    declaration records.
    """
    lines = {}
    if ref is None:
        return lines
    row = SYSTEMS.get(ref.system_id, {}).get("adapted_pairs", {}).get(ref.skill_rel, {})
    for line in row.get("omits", ()):
        if isinstance(line, str) and line.strip():
            lines.setdefault(normalise_sentence(line), line)
    return lines


def compare_expected_observed(
    expected: dict, mirror_bytes: bytes, transform_kinds: dict, shared_only: bool = False,
    ref: PairRef = None, authority_path: str = "",
):
    """Expected value from `expected_from_commit`, observed value from the
    mirror's own bytes, compared here and only here. Returns (disposition, reason).

    `shared_only` narrows the comparison to what the two documents can
    genuinely share. A mirror reached only because a pointer, a duplicate
    sentence or a moved token names another authority is not a copy of that
    authority, so nothing the authority added can be missing from it; only
    the stale side, a value or a sentence that authority removed or changed
    and this mirror still shows, is a real signal. With `shared_only` true
    the stale token, lingering token and lingering sentence checks run as
    they always do and their finding, when one fires, is returned; the
    missing token check, the missing sentence check and the class branches
    do not run at all, and a clean run returns routed-to-human with a
    reference note rather than a class verdict, since the classes describe a
    copy relationship this pair does not have.

    A lingering sentence or token line a completed move already explains is
    dropped before the lingering checks judge it. When a residency row is
    marked moved, its home is the carrier document being judged, and its
    statement key is the statement's own SHA-256, the text left the
    authority because this document is where it now lives. The drop asks
    presence the way the residency check does, with the row's statement
    folded to one normalised text and the lingering sentence, or the removed
    token's line, looked for inside it. The record wraps and groups the same
    words differently from the diff's physical lines, so a substring over
    the folded statement is the identity this record certifies while a whole
    fragment match would call a completed move a deletion. The test is still
    the row's own statement, never the whole diff line, so a sentence merely
    sitting beside the moved text is not excused.

    Stale and missing content is ruled out on every diff before any
    transform class is consulted: a class explains a difference only when
    the mirror shows no stale or missing content. A moved token that still
    shows its old value and not its new one is a finding regardless, since
    the transform table classifies wording, not numeric values. A removed
    sentence and an added sentence that fold to the same
    presentation-normalised text have already cancelled each other out in
    `expected_from_commit`, before either list reached here, so they cannot
    appear below at all. A removed or added sentence counts as present only
    against a whole line or a whole sentence of the mirror, never a bare
    substring of a longer one. The lingering side, whether the mirror still
    shows what the range removed, is compared without folding through the
    presentation classes again: a mirror already carrying the range's own
    punctuation update is a different question from whether stale content
    survives, and re-folding here would make the two indistinguishable. The
    missing side, whether the mirror shows what the range added, still folds
    through the presentation classes, so a mirror that already phrases the
    addition in a different but presentation-equivalent form is not reported
    as lacking it. A missing sentence that came from a structured field line
    is not a finding when the mirror carries that sentence's distinctive
    content as prose, since the field form is the source's and the mirror has
    no fields. Such a sentence routes to a human naming the field and the
    mirror line, and a sentence the mirror does not carry stays a finding.
    A missing addition is set aside rather than reported only when every
    added line in the range's diff that carries it is itself a line the
    declaration's `adapted_pairs` records as deliberately omitted: the pair
    routes to a human naming the declared line, and the same sentence
    arriving on a line the declaration does not name still blocks, so the
    exemption stays precise to the lines the decision covered.
    A markdown link in an addition is resolved from the authority document's
    own path against declared pair sources. When it resolves, the declaration's
    Project title is the document identity, with its full and short forms
    treated as the same title. A destination that does not resolve to a
    declared pair source remains written content, as does a different declared
    mirror title on the observed side.
    Only once every stale and missing check has come back
    clean do the diff's transform classes speak: a diff the confirmed
    presentation classes fully explain conforms outright, and a diff the
    table fully explains but not as presentation alone routes to a human,
    because the table's own contract is that a semantic class is a person's
    decision, not a guess. `check_mirror` decides whether the declaration's
    own permitted-fork list caps a finding at routed-to-human; this function
    always reports what it found.
    """
    mirror_analysis = analyse_mirror(mirror_bytes, transform_kinds)
    mirror_raw = mirror_analysis["raw"]
    mirror_bounded_basic = mirror_analysis["bounded_basic"]
    declaring_doc = authority_path or (lexical_relative(ref.source) if ref is not None else "")

    stale = []
    missing_moved_tokens = []
    for token in expected["moved_tokens"]:
        # The token's own line is the presence test, the way the lingering
        # check compares line signals: the line names the label and the
        # value together, where a bare digit such as a version number or a
        # stand-alone count recurs by coincidence across a corpus this size.
        before_signal = line_signal(token["before_line"])
        after_signal = line_signal(token["after_line"])
        before_present = bool(before_signal) and before_signal in mirror_bounded_basic
        # The new value's presence is judged through the confirmed
        # presentation classes, the same way an added token's line is, so a
        # mirror that already carries the new value under the range's own
        # punctuation or cross-reference update is not reported as missing it.
        after_pres = presentation_normalise(token["after_line"], transform_kinds) if after_signal else ""
        after_present = bool(after_pres) and after_pres in mirror_analysis["bounded_pres"]
        # The new value must be present before a moved token reads as
        # reflected. A mirror that still shows the old line is stale, and a
        # mirror missing both is a lost value when the new line is one
        # `line_signal` can trust. A line it withholds, a version stamp or a
        # heading, stays uncheckable here rather than reported on a signal
        # the rest of the checker never trusted.
        if before_present and not after_present:
            stale.append(token)
        elif after_signal and not after_present:
            missing_moved_tokens.append(token)
    if stale:
        sites = ", ".join(f"{t['label'] or 'value'}: still {t['before']}, expected {t['after']}" for t in stale)
        return "finding", f"stale token(s): {sites}"

    # A whole line and a whole sentence of the mirror, basic and
    # presentation-normalised alike, so a removed prefix of a longer
    # surviving line or sentence is never mistaken for the line or sentence
    # itself, on either side of the lingering/missing asymmetry below.
    mirror_bounded_pres = mirror_analysis["bounded_pres"]

    # The record's own presence test folds whitespace before comparing, so
    # the statement is folded and normalised once here and the lingering
    # text is tested inside it, never by whole fragment equality against the
    # diff's own line breaks.
    moved_statement_texts = []
    if ref is not None:
        decl = SYSTEMS.get(ref.system_id, {})
        system_dir = SYSTEMS_ROOT / decl.get("system_dir", "")
        for row in decl.get("residency", ()):
            if not row.get("moved"):
                continue
            if ec.sha256_bytes(row["statement"].encode("utf-8")) != row.get("statement_key"):
                continue
            if lexical_relative(system_dir / row["home"]) != lexical_relative(ref.mirror):
                continue
            moved_statement_texts.append(
                normalise_sentence(" ".join(row["statement"].split()))
            )

    lingering_tokens = [
        t for t in expected["removed_tokens"]
        if line_signal(t["line"]) and line_signal(t["line"]) in mirror_bounded_basic
        and not any(
            normalise_sentence(t["line"]) in statement for statement in moved_statement_texts
        )
    ]
    if lingering_tokens:
        sites = ", ".join(f"{t['label'] or 'value'}: removed upstream, still {t['value']}" for t in lingering_tokens)
        return "finding", f"removed token(s) still present: {sites}"

    mirror_sentence_contexts = mirror_analysis["sentence_contexts"]
    removed_contexts = expected.get("removed_sentence_contexts", {})
    lingering_sentences = [
        s for s in expected["removed_sentences"]
        if s in mirror_bounded_basic
        and removed_contexts.get(s, "") in mirror_sentence_contexts.get(s, set())
        and not any(s in statement for statement in moved_statement_texts)
    ]
    if lingering_sentences:
        return "finding", f"removed sentence still present: {lingering_sentences[0][:100]}"

    if shared_only:
        return "routed-to-human", "shared reference, nothing stale in this mirror"

    # A moved token whose new line is one the declaration's `adapted_pairs`
    # records as deliberately omitted is set aside the way a declared added
    # line is, and joins that route below, so an undeclared addition on the
    # same pair still blocks.
    declared_lines = declared_omissions(ref)
    moved_set_aside = [
        declared_lines[normalise_sentence(t["after_line"])]
        for t in missing_moved_tokens
        if normalise_sentence(t["after_line"]) in declared_lines
    ]
    missing_moved_tokens = [
        t for t in missing_moved_tokens
        if normalise_sentence(t["after_line"]) not in declared_lines
    ]

    if missing_moved_tokens:
        # A moved token whose new line is a structured field line the mirror
        # carries as prose routes with the field additions rather than
        # blocking, the same way a missing added token on such a line does.
        field_tokens = [
            {"label": t["label"], "value": t["after"], "line": t["after_line"]}
            for t in missing_moved_tokens
        ]
        _, carried, still_missing = partition_field_additions(
            expected.get("diff_text", ""), [], mirror_raw, transform_kinds, field_tokens)
        if still_missing:
            sites = ", ".join(f"{t['label'] or 'value'}: {t['value']}" for t in still_missing)
            return "finding", f"moved token(s) missing from the mirror: {sites}"
        sites = ", ".join(f"{label} at line {number}" for label, number in carried)
        return "routed-to-human", FIELD_ROUTE_REASON + sites

    mirror_addition_cache = {}

    def mirror_addition_pres(refs: tuple) -> set:
        key = tuple((item.system_id, item.skill_rel) for item in refs)
        if key not in mirror_addition_cache:
            mirror_addition_cache[key] = {
                presentation_normalise(
                    fold_declared_mirror_titles(line, refs), transform_kinds
                )
                for line in mirror_raw.splitlines() if line.strip()
            } | {
                presentation_normalise(
                    fold_declared_mirror_titles(sentence, refs), transform_kinds
                )
                for sentence in sentences_of(mirror_raw)
            }
        return mirror_addition_cache[key]

    def addition_is_present(text: str) -> bool:
        normalised, refs = addition_presentation(text, transform_kinds, declaring_doc)
        if not normalised:
            return False
        observed = mirror_addition_pres(refs) if refs else mirror_bounded_pres
        return normalised in observed

    missing_tokens = [
        t for t in expected["added_tokens"]
        if line_signal(t["line"]) and not addition_is_present(t["line"])
    ]
    missing_sentences = [
        s for s in expected["added_sentences"]
        if not addition_is_present(s)
    ]
    if missing_tokens or missing_sentences or moved_set_aside:
        remaining, carried, remaining_tokens = partition_field_additions(
            expected.get("diff_text", ""), missing_sentences, mirror_raw, transform_kinds, missing_tokens)
        # A declared adaptation leaves named source lines out of its mirror on
        # purpose, so a missing addition is set aside for a person's call when
        # every added line in the range's diff that carries it is itself a
        # declared line. Whatever is left still blocks, which is what keeps
        # the exemption precise to the declared lines instead of pardoning
        # the whole pair.
        declared = declared_lines
        carriers = {}
        for diff_line in expected.get("diff_text", "").splitlines():
            if not diff_line.startswith("+") or diff_line.startswith("+++"):
                continue
            added_line = diff_line[1:]
            identity = normalise_sentence(added_line)
            for form in {identity} | set(sentences_of(added_line)):
                carriers.setdefault(form, set()).add(identity)
        set_aside = list(moved_set_aside)
        still_missing = []
        for sentence in remaining:
            carrying = carriers.get(sentence)
            if carrying and all(identity in declared for identity in carrying):
                set_aside += [declared[identity] for identity in sorted(carrying)]
            else:
                still_missing.append(sentence)
        remaining = still_missing
        set_aside += [
            declared[normalise_sentence(t["line"])]
            for t in remaining_tokens
            if normalise_sentence(t["line"]) in declared
        ]
        remaining_tokens = [
            t for t in remaining_tokens
            if normalise_sentence(t["line"]) not in declared
        ]
        if remaining_tokens or remaining:
            sites = [f"{t['label'] or 'value'}: {t['value']}" for t in remaining_tokens]
            sites += [s[:100] for s in remaining]
            return "finding", "addition(s) missing from the mirror: " + "; ".join(sites)
        if set_aside:
            return "routed-to-human", ADAPTED_ROUTE_REASON + "; ".join(dict.fromkeys(set_aside))
        sites = ", ".join(f"{label} at line {number}" for label, number in carried)
        return "routed-to-human", FIELD_ROUTE_REASON + sites

    classes = expected["diff_classes"]["classes"]
    unclassified = expected["diff_classes"]["unclassified"]
    presentation_only = bool(classes) and not unclassified and all(
        transform_kinds.get(name) == "presentation" for name in classes
    )
    semantic_hits = [name for name in classes if transform_kinds.get(name, "semantic") == "semantic"]

    if presentation_only:
        return "conform", "presentation-only diff (" + ", ".join(classes) + ")"
    if classes and not unclassified:
        return (
            "routed-to-human",
            "semantic-class change confirmed under the transform table: " + ", ".join(semantic_hits),
        )

    if unclassified:
        return "routed-to-human", "unclassified wording change"

    if not expected["diff_text"].strip():
        return "conform", "no authority diff for this range"
    if expected["moved_tokens"]:
        return "conform", "moved token(s) already reflected in the mirror"
    return "conform", "diff carries no numeric token, no sentence change, and no classified wording change"


# ───────────────────────────────────────────────────────────────
# 15. MIRROR CHECKS
# ───────────────────────────────────────────────────────────────

def check_mirror(
    repo: Path, resolved: dict, ref: PairRef, authority_paths: set, transform_kinds: dict, tokens_index: dict,
    forked_paths: set, signals: dict,
):
    """The checker. Its four prohibitions, held as the shape of the code
    above rather than as a comment beside it:

    1. Never opens a mirror document for writing - `read_only_bytes` is the
       only function here that touches mirror bytes, and it opens with
       `O_RDONLY`.
    2. Never emits replacement text - every return is a disposition word, a
       short reason string and a content key, never a document body.
    3. Treats no mirror document as authority - `expected_from_commit` takes
       no mirror path and reads no mirror bytes; only the diff and the
       declaration feed it.
    4. Never derives the expected value from the function that wrote the
       mirror - there is no writer imported or called anywhere in this
       module, so `expected_from_commit` has nothing of the kind to call.

    A finding from any authority path returns at once. When no path produced
    a finding, the routed result outranks the own-path result: a pair whose
    own authority shows nothing while a shared reference routed it in is a
    pair a person still looks at, so an own-path `conform` must not swallow
    that routing. Two exceptions apply. A field route returns the own
    result, because the pair's own authority added a field line the mirror
    already carries as prose and that result names the field and the mirror
    line ahead of the generic routed note. A declared adaptation keeps the
    routed result and adds the own-path adaptation to its reason, so the
    declared omission stays visible on the walk. The own-path result is
    returned only when no path routed the pair in.

    Returns (disposition, reason, expected_key). `expected_key` is `None`
    when no expected value was derived at all, so a later record cannot be
    mistaken for one that judged content it never read.
    """
    card = shared_card(ref)
    if card is not None and not Path(os.path.realpath(card)).is_file():
        return "deferred", f"shared card {card} is not a file, cannot derive expected value", None

    choices = authority_path_choices(ref, authority_paths)
    if not choices:
        return "deferred", "no declared authority path for this pair is present in the range's diff", None

    own_result = None
    routed_result = None
    for authority_path, kind in choices:
        if kind == "mirror-direct":
            result = (
                "routed-to-human",
                f"mirror touched directly at {authority_path}, no source-side change in range",
                None,
            )
            if own_result is None:
                own_result = result
            continue
        try:
            expected = signals.get(authority_path)
            if expected is None:
                expected = expected_from_commit(repo, resolved, authority_path, tokens_index, transform_kinds)
            mirror_bytes = read_only_bytes(ref.mirror)
        except OSError as exc:
            return "deferred", f"mirror bytes unreadable: {exc}", None
        expected_key = ec.content_key({"authority_path": authority_path, "kind": kind, **expected})
        disposition, reason = compare_expected_observed(
            expected, mirror_bytes, transform_kinds, shared_only=kind == "routed", ref=ref,
            authority_path=authority_path)
        if kind == "routed" and disposition == "finding":
            if authority_path in forked_paths:
                # The routed authority itself is declared a permitted fork,
                # so the divergence this comparison sees is the one the
                # declaration already decided. The authority, not the carrier
                # reading it, is what owns that record.
                disposition = "routed-to-human"
                reason = f"declared as a permitted fork at {authority_path}: {reason}"
            else:
                # This pair was reached only through a pointer, a duplicate
                # sentence or a moved token naming a document that is not its
                # own declared source or mirror, so only the stale side is
                # compared. The route stays named in the reason: a finding is
                # a finding however the pair was reached.
                reason = f"routed by a shared reference at {authority_path}, not this pair's own authority: {reason}"
        elif (
            disposition == "finding"
            and reason.startswith("addition(s) missing from the mirror:")
            and ref.skill_rel in SYSTEMS[ref.system_id].get("forked_shared_copies", {})
        ):
            # The declaration records this mirror as an adaptation of its
            # source rather than a copy: a hand-correction landed here in this
            # system's own phrasing. An addition the source gained but the
            # adaptation chose not to carry is a person's call, not a stale
            # copy, so it routes instead of blocking.
            disposition = "routed-to-human"
            reason = f"declared adaptation of its source, a missing addition is a person's call: {reason}"
        elif disposition == "finding" and authority_path in forked_paths:
            # The authority this finding came from is itself a declared
            # permitted fork, so the same divergence is already decided.
            disposition = "routed-to-human"
            reason = f"declared as a permitted fork at {authority_path}: {reason}"
        if disposition == "finding":
            return disposition, reason, expected_key
        if kind == "routed":
            routed_result = (disposition, reason, expected_key)
        elif own_result is None:
            own_result = (disposition, reason, expected_key)
    if routed_result is not None:
        if own_result is not None and own_result[1].startswith(FIELD_ROUTE_REASON):
            # The pair's own authority added a field line the mirror already
            # carries as prose, so this result names the field and the mirror
            # line instead of the generic note a routed reference returns.
            return own_result
        if own_result is not None and own_result[1].startswith(ADAPTED_ROUTE_REASON):
            # The pair's own authority declared a source line omitted on
            # purpose while a shared reference routed the pair in, so the
            # answer keeps the routed note and names the declared adaptation
            # beside it rather than hiding one behind the other.
            return routed_result[0], f"{routed_result[1]}; {own_result[1]}", routed_result[2]
        return routed_result
    return own_result


# ───────────────────────────────────────────────────────────────
# 16. STATE AND DISPOSITIONS
# ───────────────────────────────────────────────────────────────

def state_path(ref: PairRef) -> Path:
    slug = re.sub(r"[^a-zA-Z0-9_.-]+", "_", ref.skill_rel)
    return STATE_DIR / f"{ref.system_id}__{slug}{ec.STATE_SUFFIX}"


def load_state(ref: PairRef):
    path = state_path(ref)
    if not path.is_file():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None


def save_state(ref: PairRef, record: dict) -> None:
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    state_path(ref).write_text(
        json.dumps(record, indent=2, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8",
    )


def disposition_for(
    repo: Path, resolved: dict, ref: PairRef, authority_paths: set, transform_kinds: dict,
    tokens_index: dict, forked_paths: set, signals: dict,
) -> dict:
    """One disposition for one mirror document, and the state record that
    lets a later, unchanged run report `skipped-unchanged` without reopening it.

    The unchanged key is the tuple of the range's head, the expected value's
    own content key and the mirror's bytes. All three must match a prior
    record before that record is trusted: a new range or a new expected value
    reopens the mirror even when its bytes have not moved.
    """
    mirror_sha = ec.sha256_bytes(read_only_bytes(ref.mirror)) if ref.mirror.is_file() else None
    if mirror_sha is None:
        disposition, reason, expected_key = "unmapped", "declared mirror path is not on disk", None
    else:
        disposition, reason, expected_key = check_mirror(
            repo, resolved, ref, authority_paths, transform_kinds, tokens_index, forked_paths, signals)

    unchanged_key = [resolved["head"], expected_key, mirror_sha]
    if mirror_sha is not None:
        prior = load_state(ref)
        if (
            prior
            and prior.get("disposition") in ("conform", "routed-to-human")
            and prior.get("unchanged_key") == unchanged_key
        ):
            disposition = "skipped-unchanged"
            reason = f"content unchanged since {prior['disposition']} recorded at {prior.get('at')}"

    if disposition != "skipped-unchanged":
        save_state(ref, {
            "system": ref.system_id,
            "skill_rel": ref.skill_rel,
            "mirror_path": lexical_relative(ref.mirror),
            "mirror_sha256": mirror_sha,
            "disposition": disposition,
            "reason": reason,
            "at": ec.utc_now(),
            "range": resolved,
            "unchanged_key": unchanged_key,
        })
    return {
        "system": ref.system_id,
        "pair": ref.skill_rel,
        "mirror": lexical_relative(ref.mirror),
        "authority_paths": sorted(authority_paths),
        "disposition": disposition,
        "reason": reason,
        "content_key": mirror_sha,
    }


def declaration_in_range(resolved: dict) -> bool:
    """True when the range changed the declaration that names every pair.

    The declaration is the walk's own premise rather than one authority among
    many, so a change to it is never compared against a mirror and never
    asked to disappear into the silence of a universe it no longer names. The
    walk that reads a changed declaration fails closed and names it.
    """
    return bool(ec.git_text(
        REPO_ROOT, "diff", "--name-only", resolved["base"], resolved["head"],
        "--", DECLARATION_REL, required=False,
    ).strip())


# ───────────────────────────────────────────────────────────────
# 17. THE WALK
# ───────────────────────────────────────────────────────────────

def walk(rev_range: str) -> dict:
    """Every authority the range touched, the five indexes run over it, and
    one disposition per mirror document those authorities govern."""
    if not rev_range:
        raise SystemExit("walk needs --range BASE..HEAD")
    resolved = ec.resolve_range(REPO_ROOT, rev_range)
    indexes = {
        "bindings": bindings(),
        "pointers": pointers(),
        "fanout": fanout(),
        "duplicates": duplicates(),
        "tokens": tokens(rev_range),
    }
    pair_lookup = {(ref.system_id, ref.skill_rel): ref for ref in iter_pairs()}
    transform_kinds = load_transforms(TRANSFORMS_FILE)
    # A malformed or repeated transform row is refused by name here rather
    # than dropped: the walk still runs, with the refused class left semantic
    # because nothing confirmed it, and the refusal travels with the result
    # so a table the parser could not read does not read as a clean table.
    transform_refusals = list(transform_kinds.get(TRANSFORM_REFUSALS, ()))
    # A refused discovery exception is carried beside the walk the same way a
    # refused transform row is: a refusal the tool names and then passes is
    # worse than no refusal, so both fail the walk below.
    exceptions_refused = [
        {"glob": exc["glob"], "reason": exc["refused"]}
        for exc in load_discover_exceptions(DISCOVER_EXCEPTIONS_FILE)
        if exc["refused"]
    ]
    declaration_changed = declaration_in_range(resolved)
    forked_paths = declared_fork_paths()
    signals: dict = {}

    hits = touched_pairs(resolved, indexes, pair_lookup, transform_kinds, signals)
    mirrors = [
        disposition_for(
            REPO_ROOT, resolved, hits[key]["ref"], hits[key]["authority_paths"],
            transform_kinds, indexes["tokens"], forked_paths, signals,
        )
        for key in sorted(hits)
    ]
    counts = {name: sum(1 for m in mirrors if m["disposition"] == name) for name in DISPOSITIONS}
    return keyed({
        "kind": "walk",
        "range": resolved,
        "index_keys": {name: result["content_key"] for name, result in indexes.items()},
        "mirrors": mirrors,
        "counts": counts,
        "blocked": (
            declaration_changed
            or bool(transform_refusals)
            or bool(exceptions_refused)
            or any(counts[name] for name in BLOCKING_DISPOSITIONS)
        ),
        "transform_refusals": transform_refusals,
        "exceptions_refused": exceptions_refused,
        "declaration_changed": declaration_changed,
    })


# ───────────────────────────────────────────────────────────────
# 18. CLI
# ───────────────────────────────────────────────────────────────

INDEXES = {
    "bindings": bindings,
    "pointers": pointers,
    "fanout": fanout,
    "duplicates": duplicates,
    "tokens": tokens,
}


def main(argv) -> int:
    parser = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    sub = parser.add_subparsers(dest="command", required=True)

    index_parser = sub.add_parser("index", help="print one declared index as JSON")
    index_parser.add_argument("name", choices=sorted(INDEXES))
    index_parser.add_argument("--range", dest="rev_range", default=None)

    sub.add_parser("discover", help="report markdown documents the declaration does not name")

    walk_parser = sub.add_parser("walk", help="disposition every mirror a commit range's authorities touched")
    walk_parser.add_argument("--range", dest="rev_range", required=True)

    args = parser.parse_args(argv[1:])
    if args.command == "index":
        print(json.dumps(INDEXES[args.name](args.rev_range), indent=2, ensure_ascii=False))
        return 0

    if args.command == "walk":
        result = walk(args.rev_range)
        print(json.dumps(result, indent=2, ensure_ascii=False))
        return 1 if result["blocked"] else 0

    result = discover()
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 1 if result["count"] else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
