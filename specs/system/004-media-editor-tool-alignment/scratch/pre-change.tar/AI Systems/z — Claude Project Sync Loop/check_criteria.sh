#!/usr/bin/env bash
# ───────────────────────────────────────────────────────────────
# COMPONENT: COMPLETION CRITERIA CHECK
# ───────────────────────────────────────────────────────────────
# Every completion criterion of the skill to Project sync work, as one command.
#
# The packet's own record is a file a reader has to trust. This script is the
# part that needs no trust: it runs the checks the criteria name and prints a
# row per criterion with the exit code behind it. A criterion whose evidence
# depends on something outside the thing it measures is the failure this packet
# kept finding, so every row here runs a tool rather than reading a claim.
set -uo pipefail

# ───────────────────────────────────────────────────────────────
# 1. CONFIGURATION
# ───────────────────────────────────────────────────────────────

cd "$(dirname "$0")/../.."
GATE="AI Systems/z — Claude Project Sync Loop"
fail=0

# ───────────────────────────────────────────────────────────────
# 2. HELPERS
# ───────────────────────────────────────────────────────────────

row() { printf '  %-58s %s\n' "$1" "$2"; [ "$2" = ok ] || fail=$((fail+1)); }
verdict() { [ "$1" = 0 ] && echo ok || echo "FAILED exit $1"; }

# ───────────────────────────────────────────────────────────────
# 3. CRITERION CHECKS
# ───────────────────────────────────────────────────────────────

python3 "$GATE/episode_selftest.py" >/dev/null 2>&1; clean=$?
miss=0
for n in $(python3 "$GATE/episode_selftest.py" --inject NOTAREALNAME 2>&1 \
           | sed -n "s/.*choose from \(.*\))/\1/p" | tr ',' '\n' \
           | sed -n "s/.*'\([^']*\)'.*/\1/p" | sort -u); do
  python3 "$GATE/episode_selftest.py" --inject "$n" >/dev/null 2>&1
  [ "$?" = 1 ] || miss=$((miss+1))
done
gates=0
for s in $(python3 "$GATE/validate_parity.py" --list 2>/dev/null); do
  python3 "$GATE/validate_parity.py" "$s" >/dev/null 2>&1 || gates=$((gates+1))
done
row "2 selftest green clean, red on every injection, gates 0" \
    "$([ "$clean" = 0 ] && [ "$miss" = 0 ] && [ "$gates" = 0 ] && echo ok || echo "FAILED clean=$clean not-red=$miss gates-failing=$gates")"

python3 "$GATE/carrier_query_evidence.py" >/dev/null 2>&1; suite=$?
python3 "$GATE/episode_selftest.py" --inject two-family >/dev/null 2>&1; dis=$?
row "3 carrier query suite green, injected disagreement stops it" \
    "$([ "$suite" = 0 ] && [ "$dis" = 1 ] && echo ok || echo "FAILED suite=$suite disagreement=$dis")"

bash "$GATE/run_episode.sh" --replay >/dev/null 2>&1; row "4 the replay covers every recorded site" "$(verdict $?)"

python3 "$GATE/residency_check.py" --all >/dev/null 2>&1; a=$?
python3 "$GATE/residency_report.py" >/dev/null 2>&1; b=$?
row "5 residency owned and placed, its record matching" \
    "$([ "$a" = 0 ] && [ "$b" = 0 ] && echo ok || echo "FAILED check=$a report=$b")"

python3 "$GATE/prove_review_expiry.py" >/dev/null 2>&1; row "the expiry proof runs green, red, green" "$(verdict $?)"
python3 "$GATE/pair_divergence.py" --all >/dev/null 2>&1; row "no declared pair states one rule two ways" "$(verdict $?)"

n=$(ls -d "AI Systems"/*/sk-*/manual-testing-playbook/manual-testing-playbook.md 2>/dev/null | wc -l | tr -d ' ')
h=$(grep -rhE "^- Playbook ID: (SID|PID)-001" "AI Systems"/*/sk-*/manual-testing-playbook 2>/dev/null | wc -l | tr -d ' ')
# The skills tree is an untracked link, so a checkout without it, an
# unprovisioned worktree among them, reports the missing validator rather
# than counting every package invalid.
validator=".skilled/skills/sk-doc/sk-create-manual-testing-playbook/scripts/validate-playbook-package.cjs"
bad=0
if [ -f "$validator" ]; then
  for pkg in "AI Systems"/*/sk-*/manual-testing-playbook; do
    node "$validator" --repo-root "$PWD" --package "$pkg" >/dev/null 2>&1 || bad=$((bad+1))
  done
else
  bad="validator-missing-provision-this-checkout"
fi
# Seven live packages since Barter - Blog Posts was retired on 2026-09-20. The
# verdict records below stay at eight, because they are the history of the
# review and the retired system's record is part of it.
row "8 seven packages, fourteen handovers, every validator green" \
    "$([ "$n" = 7 ] && [ "$h" = 14 ] && [ "$bad" = 0 ] && echo ok || echo "FAILED packages=$n handovers=$h invalid=$bad")"

V="$GATE/episodes/playbook-verification"
r1=$(ls "$V"/*/verdict.md 2>/dev/null | wc -l | tr -d ' ')
r2=$(ls "$V"/*/verdict-round-two.md 2>/dev/null | wc -l | tr -d ' ')
fam=$(grep -h "^- Written by:\|^- Verified by:" "$V"/*/verdict.md 2>/dev/null | wc -l | tr -d ' ')
open_detail=$(python3 "$GATE/verification_backlog.py" --quiet 2>&1); open=$?
[ "$open" = 0 ] || printf '%s\n' "$open_detail" | sed 's/^/      /'
row "9 eight records both rounds, two families each, none open" \
    "$([ "$r1" = 8 ] && [ "$r2" = 8 ] && [ "$fam" = 16 ] && [ "$open" = 0 ] && echo ok || echo "FAILED one=$r1 two=$r2 families=$fam open-findings=$open")"

python3 "$GATE/record_claims.py" >/dev/null 2>&1; row "10 every counted claim in the record agrees with the tree" "$(verdict $?)"

# ───────────────────────────────────────────────────────────────
# 4. RESULT
# ───────────────────────────────────────────────────────────────

echo
[ "$fail" = 0 ] && echo "every criterion check passed" || echo "$fail criterion check(s) failed"
exit $([ "$fail" = 0 ] && echo 0 || echo 1)
